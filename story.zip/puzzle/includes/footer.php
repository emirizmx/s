    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Dijital Hediye. Tüm hakları saklıdır.</p>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
    <script src="/puzzle/assets/js/puzzle.js"></script>
</body>
</html> 