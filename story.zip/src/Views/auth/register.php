<?php require 'includes/header.php'; ?>

<div class="container auth-container">
    <div class="auth-box">
        <h2>Kayıt Ol</h2>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?php 
                echo htmlspecialchars($_SESSION['error']);
                unset($_SESSION['error']);
                ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="/register" class="auth-form">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="form-group">
                <label for="username">Kullanıcı Adı</label>
                <input type="text" 
                       id="username" 
                       name="username" 
                       required 
                       class="form-control"
                       value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                       pattern="[a-zA-Z0-9_]{3,20}"
                       title="3-20 karakter arası, sadece harf, rakam ve alt çizgi kullanabilirsiniz">
            </div>
            
            <div class="form-group">
                <label for="email">E-posta</label>
                <input type="email" 
                       id="email" 
                       name="email" 
                       required 
                       class="form-control"
                       value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
            </div>
            
            <div style="margin-bottom: 1.5rem;">
                <label for="phone" style="display: block; margin-bottom: 0.5rem; color: var(--text-color);">
                    Telefon Numarası
                </label>
                <input type="tel" 
                       id="phone" 
                       name="phone" 
                       required 
                       style="
                           width: 100%;
                           padding: 0.8rem;
                           border: 1px solid var(--border-color);
                           border-radius: 10px;
                           font-size: 1rem;
                           background: white;
                       "
                       placeholder="05XX XXX XX XX"
                >
            </div>
            
            <div class="form-group">
                <label for="password">Şifre</label>
                <input type="password" 
                       id="password" 
                       name="password" 
                       required 
                       class="form-control"
                       minlength="6"
                       pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}"
                       title="En az 6 karakter, 1 büyük harf, 1 küçük harf ve 1 rakam içermelidir">
            </div>
            
            <div class="form-group">
                <label for="password_confirm">Şifre Tekrar</label>
                <input type="password" 
                       id="password_confirm" 
                       name="password_confirm" 
                       required 
                       class="form-control">
            </div>
            
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" 
                           name="terms" 
                           required> 
                    <a href="/terms" target="_blank">Kullanım Şartları</a>'nı okudum ve kabul ediyorum
                </label>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block">Kayıt Ol</button>
        </form>
        
        <div class="auth-links">
            <p>Zaten hesabınız var mı? <a href="/login">Giriş Yap</a></p>
        </div>
    </div>
</div>

<script>
document.querySelector('.auth-form').addEventListener('submit', function(e) {
    var password = document.getElementById('password');
    var confirm = document.getElementById('password_confirm');
    
    if (password.value !== confirm.value) {
        e.preventDefault();
        alert('Şifreler eşleşmiyor!');
    }
});
</script>

<?php require 'includes/footer.php'; ?> 