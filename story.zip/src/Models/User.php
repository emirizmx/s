<?php
class User {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function register($username, $email, $password, $phone) {
        try {
            // Ana site veritabanına kaydet
            $stmt = $this->db->prepare("
                INSERT INTO dh_users (username, email, password_hash, phone, created_at) 
                VALUES (?, ?, ?, ?, NOW())
            ");
            
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt->execute([
                $username,
                $email,
                $hashedPassword,
                $phone
            ]);
            
            $userId = $this->db->lastInsertId();
            
            // Puzzle veritabanına da kaydet
            $puzzleDb = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=dijitzwc_hediye",
                DB_USER,
                DB_PASS
            );
            
            $stmt = $puzzleDb->prepare("
                INSERT INTO users (username, email, password_hash, main_user_id) 
                VALUES (:username, :email, :password, :main_id)
            ");
            
            $stmt->execute([
                ':username' => $username,
                ':email' => $email,
                ':password' => password_hash($password, PASSWORD_DEFAULT),
                ':main_id' => $userId
            ]);
            
            return $userId;
        } catch (PDOException $e) {
            throw new Exception('Kayıt işlemi başarısız: ' . $e->getMessage());
        }
    }
    
    public function getUserByEmail($email) {
        try {
            $stmt = $this->db->prepare("
                SELECT id, username, email, password_hash, credits, is_admin, is_active 
                FROM dh_users 
                WHERE email = ?
            ");
            
            $stmt->execute([$email]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            error_log($e->getMessage());
            return null;
        }
    }
    
    public function login($email, $password) {
        $stmt = $this->db->prepare("
            SELECT id, password_hash 
            FROM dh_users 
            WHERE email = ?
        ");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password_hash'])) {
            return true;
        }
        
        return false;
    }
    
    private function syncPuzzleSession($mainUserId) {
        try {
            $puzzleDb = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=dijitzwc_hediye",
                DB_USER,
                DB_PASS
            );
            
            $stmt = $puzzleDb->prepare("
                SELECT id, username FROM users WHERE main_user_id = :main_id
            ");
            
            $stmt->execute([':main_id' => $mainUserId]);
            $puzzleUser = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($puzzleUser) {
                $_SESSION['puzzle_user_id'] = $puzzleUser['id'];
            }
        } catch (PDOException $e) {
            error_log('Puzzle session sync error: ' . $e->getMessage());
        }
    }
    
    public function updateCredits($userId, $amount) {
        $stmt = $this->db->prepare("
            UPDATE dh_users 
            SET credits = credits + :amount 
            WHERE id = :user_id
        ");
        
        return $stmt->execute([
            ':amount' => $amount,
            ':user_id' => $userId
        ]);
    }
    
    public function getProfile($userId) {
        $stmt = $this->db->prepare("
            SELECT id, username, email, credits, created_at
            FROM dh_users 
            WHERE id = :user_id
        ");
        
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
} 