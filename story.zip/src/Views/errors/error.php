<?php require 'includes/header.php'; ?>

<div class="container error-container">
    <div class="error-content">
        <h1>Hata</h1>
        <p><?php echo htmlspecialchars($error_message ?? 'Bir hata oluştu.'); ?></p>
        <a href="/" class="btn btn-primary">Ana Sayfaya Dön</a>
    </div>
</div>

<?php require 'includes/footer.php'; ?> 