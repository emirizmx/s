<?php require 'includes/header.php'; ?>

<div class="container payment-container">
    <div class="payment-box">
        <h2>Ödeme</h2>
        
        <div class="payment-details">
            <div class="package-info">
                <h3><?php echo htmlspecialchars($selectedPackage['name']); ?></h3>
                <div class="credits"><?php echo number_format($selectedPackage['credits']); ?> Kredi</div>
                <div class="price"><?php echo number_format($selectedPackage['price'], 2); ?> TL</div>
            </div>
            
            <form action="<?php echo $paymentForm['action']; ?>" method="post" id="payment-form">
                <?php foreach ($paymentForm['params'] as $key => $value): ?>
                    <input type="hidden" name="<?php echo $key; ?>" value="<?php echo $value; ?>">
                <?php endforeach; ?>
                
                <button type="submit" class="btn btn-primary btn-block">Ödemeye Geç</button>
            </form>
            
            <div class="payment-info">
                <p><i class="fas fa-lock"></i> Güvenli ödeme için PayTR altyapısı kullanılmaktadır.</p>
            </div>
        </div>
    </div>
</div>

<?php require 'includes/footer.php'; ?> 