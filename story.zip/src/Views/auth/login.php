<?php require 'includes/header.php'; ?>

<div class="container">
    <div class="auth-container">
        <div class="auth-box">
            <h2>Giriş Yap</h2>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php 
                    echo htmlspecialchars($_SESSION['error']);
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                    echo htmlspecialchars($_SESSION['success']);
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="/login" class="auth-form">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                
                <div class="form-group">
                    <label for="email">E-posta veya Kullanıcı Adı</label>
                    <input type="text" name="email" id="email" class="form-control" placeholder="E-posta adresiniz veya kullanıcı adınız" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Şifre</label>
                    <input type="password" name="password" id="password" class="form-control" required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Giriş Yap</button>
            </form>
            
            <div class="auth-links">
                <p>Hesabınız yok mu? <a href="/register">Kayıt Ol</a></p>
            </div>
        </div>
    </div>
</div>

<?php require 'includes/footer.php'; ?> 