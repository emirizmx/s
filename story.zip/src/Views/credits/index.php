<?php 
header('Content-Type: text/html; charset=utf-8');
require 'includes/header.php'; 
?>

<div class="container" style="margin-top: var(--header-height); padding-top: 2rem;">
    <h1 style="text-align: center; margin-bottom: 2rem; font-size: 2.5rem; color: var(--text-color);">Kredi Yükle</h1>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-error">
            <?php 
            echo htmlspecialchars($_SESSION['error']);
            unset($_SESSION['error']);
            ?>
        </div>
    <?php endif; ?>
<?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success" style="
            background: #dcfce7;
            border: 1px solid #22c55e;
            color: #166534;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            text-align: center;
        ">
            <?php 
            echo htmlspecialchars($_SESSION['success']);
            unset($_SESSION['success']);
            ?>
        </div>
    <?php endif; ?>
    
    <h2 style="margin: 3rem 0 2rem; color: var(--text-color); text-align: center;">Hazır Paketler</h2>
    <div class="credits-wrapper">
        <div class="credits-grid" style="display: flex; flex-wrap: wrap; justify-content: center; gap: 2rem;">
            <?php foreach ($packages as $package): ?>
                <div class="credit-package" style="
                    flex: 0 1 250px;
                    background: var(--surface-color);
                    border-radius: 15px;
                    padding: 1.5rem;
                    text-align: center;
                    box-shadow: var(--card-shadow);
                    transition: var(--smooth-transition);
                ">
                    <h3 style="font-size: 1.3rem; font-weight: 600; color: var(--text-color); margin-bottom: 1rem;">
                        <?php echo htmlspecialchars($package['name']); ?>
                    </h3>
                    <div style="font-size: 1.2rem; color: var(--text-light); margin-bottom: 0.5rem;">
                        <?php echo number_format($package['credits']); ?> Kredi
                    </div>
                    <div style="font-size: 1.5rem; font-weight: 600; color: var(--primary-color); margin-bottom: 1rem;">
                        <?php echo number_format($package['price'], 2); ?> TL
                    </div>
                    <?php if ($package['discount_percentage'] > 0): ?>
                        <div style="color: #2ecc71; font-size: 0.9rem; margin-bottom: 0.5rem;">
                            %<?php echo $package['discount_percentage']; ?> İndirim
                        </div>
                        <div style="color: var(--text-light); font-size: 0.9rem; margin-bottom: 1rem;">
                            Birim Fiyat: <?php echo number_format($package['price'] / $package['credits'], 3); ?> TL/Kredi
                        </div>
                    <?php endif; ?>
                    
                    <!-- Kredi Kartı ile Ödeme -->
                    <form method="POST" action="/credits/process" style="margin-bottom: 0.5rem;">
                        <input type="hidden" name="package_id" value="<?php echo $package['id']; ?>">
                        <button type="submit" class="btn btn-primary" style="
                            width: 100%;
                            padding: 0.8rem;
                            font-size: 1rem;
                            border-radius: 10px;
                            background: var(--primary-color);
                            color: white;
                            border: none;
                            cursor: pointer;
                            transition: var(--smooth-transition);
                            margin-bottom: 0.5rem;
                        ">
                            Kredi Kartı ile Öde
                        </button>
                    </form>

                    <!-- Banka/Havale ile Ödeme -->
                    <form method="POST" action="/credits/manual-process" style="margin-bottom: 0.5rem;">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                        <input type="hidden" name="package_id" value="<?php echo $package['id']; ?>">
                        <input type="hidden" name="payment_method" value="bank_transfer">
                        <input type="hidden" name="credit_amount" value="<?php echo $package['price']; ?>">
                        <button type="submit" class="btn btn-secondary" style="
                            width: 100%;
                            padding: 0.8rem;
                            font-size: 1rem;
                            border-radius: 10px;
                            background: var(--surface-color);
                            color: var(--text-color);
                            border: 1px solid var(--border-color);
                            cursor: pointer;
                            transition: var(--smooth-transition);
                        ">
                            Banka/Havale ile Öde
                        </button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Manuel Kredi Yükleme Formu -->
    <div class="manual-credit-section" style="
        background: var(--surface-color);
        border-radius: 15px;
        padding: 2rem;
        margin-top: 3rem;
        box-shadow: var(--card-shadow);
        margin-bottom: 3rem;
    ">
        <h2 style="margin-bottom: 1.5rem; color: var(--text-color); text-align: center;">Manuel Kredi Yükle</h2>
        <form method="POST" action="/credits/manual-process" style="max-width: 500px; margin: 0 auto;">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            
            <div style="margin-bottom: 1.5rem;">
                <label for="credit_amount" style="display: block; margin-bottom: 0.5rem; color: var(--text-color);">
                    Yüklenecek Tutar (TL)
                </label>
                <input type="number" 
                       id="credit_amount" 
                       name="credit_amount" 
                       min="20"
                       required 
                       style="
                           width: 100%;
                           padding: 0.8rem;
                           border: 1px solid var(--border-color);
                           border-radius: 10px;
                           font-size: 1rem;
                       "
                       placeholder="Minimum 20 TL"
                >
                <small style="display: block; margin-top: 0.5rem; color: var(--text-light); font-size: 0.9rem;">
                    * Manuel yüklemede 1 TL = 1 Kredi olarak hesaplanır.
                </small>
            </div>

            <div style="margin-bottom: 1.5rem;">
                <label for="payment_method" style="display: block; margin-bottom: 0.5rem; color: var(--text-color);">
                    Ödeme Yöntemi
                </label>
                <select id="payment_method" 
                        name="payment_method" 
                        required 
                        style="
                            width: 100%;
                            padding: 0.8rem;
                            border: 1px solid var(--border-color);
                            border-radius: 10px;
                            font-size: 1rem;
                            background-color: white;
                        "
                >
                    <option value="">Ödeme yöntemi seçin</option>
                    <option value="credit_card">Kredi Kartı (PayTR)</option>
                    <option value="bank_transfer">Banka Havalesi/EFT</option>
                </select>
            </div>

            <button type="submit" 
                    class="btn btn-primary" 
                    style="
                        width: 100%;
                        padding: 1rem;
                        font-size: 1.1rem;
                        border-radius: 10px;
                        background: var(--primary-color);
                        color: white;
                        border: none;
                        cursor: pointer;
                        transition: var(--smooth-transition);
                    "
            >
                Devam Et
            </button>
        </form>
    </div>
</div>

<?php require 'includes/footer.php'; ?> 