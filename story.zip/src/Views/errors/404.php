<?php require 'includes/header.php'; ?>

<div class="container error-container">
    <div class="error-content">
        <h1>404</h1>
        <h2>Sayfa Bulunamadı</h2>
        <p>Aradığınız sayfa bulunamadı veya taşınmış olabilir.</p>
        <a href="/" class="btn btn-primary">Ana Sayfaya Dön</a>
    </div>
</div>

<?php require 'includes/footer.php'; ?> 