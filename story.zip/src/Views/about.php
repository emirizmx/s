<?php require_once 'includes/header.php'; ?>

<div class="main-content">
    <div class="container">
        <!-- Hero Section -->
        <section class="about-hero">
            <div class="hero-content">
                <div class="hero-icon">
                    <i class="fas fa-gift-card fa-3x"></i>
                </div>
                <h1>Dijital Hediye Nedir?</h1>
                <p class="hero-description">
                    İnsanların sevdiklerine özel kişiye özel dijital hediyeler, oyunlar oluşturabileceği 
                    kredi sistemiyle anlık olarak çalışan bir Dijital hediye oluşturma platformudur.
                </p>
            </div>
        </section>

        <!-- Features Section -->
        <section class="features section-spacing">
            <div class="section-title">
                <h2>Özelliklerimiz</h2>
                <div class="title-underline"></div>
            </div>
            <div class="feature-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-gift"></i>
                    </div>
                    <h3>Kişiye Özel Hediyeler</h3>
                    <p>Sevdikleriniz için tamamen size ve onlara özel, benzersiz dijital hediyeler oluşturun.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-gamepad"></i>
                    </div>
                    <h3>Eğlenceli Oyunlar</h3>
                    <p>Puzzle ve benzeri eğlenceli oyunlarla hediyelerinizi daha da özel hale getirin.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <h3>Anlık Erişim</h3>
                    <p>Kredi sistemi sayesinde anında hediye oluşturun ve paylaşın.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-heart"></i>
                    </div>
                    <h3>Özel Anlar</h3>
                    <p>Doğum günleri, yıldönümleri ve özel günler için unutulmaz sürprizler yaratın.</p>
                </div>
            </div>
        </section>

        <!-- How It Works Section -->
        <section class="how-it-works section-spacing alternate-bg">
            <div class="section-title">
                <h2>Nasıl Çalışır?</h2>
                <div class="title-underline"></div>
            </div>
            <div class="steps">
                <div class="step">
                    <div class="step-number">1</div>
                    <h3>Hesap Oluşturun</h3>
                    <p>Ücretsiz hesabınızı oluşturun ve kredi yükleyin.</p>
                </div>
                <div class="step">
                    <div class="step-number">2</div>
                    <h3>Hediyenizi Tasarlayın</h3>
                    <p>Puzzle veya diğer oyun türlerinden birini seçin ve kişiselleştirin.</p>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <h3>Paylaşın</h3>
                    <p>Oluşturduğunuz hediyeyi sevdiklerinizle paylaşın.</p>
                </div>
            </div>
        </section>
    </div>
</div>

<style>
/* Genel Section Stilleri */
.section-spacing {
    padding: 5rem 0;
    margin: 2rem 0;
    border-radius: var(--border-radius);
}

.section-title {
    text-align: center;
    margin-bottom: 3rem;
    position: relative;
}

.section-title h2 {
    color: var(--heading-color);
    font-size: 2.2rem;
    margin-bottom: 1rem;
}

.title-underline {
    width: 80px;
    height: 4px;
    background: var(--primary-color);
    margin: 0 auto;
    border-radius: 2px;
}

/* Hero Section */
.about-hero {
    text-align: center;
    padding: 5rem 0;
    background: var(--primary-gradient);
    border-radius: var(--border-radius);
    margin: 2rem 0;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.hero-icon {
    margin-bottom: 1.5rem;
    color: var(--card-bg);
}

.hero-content {
    max-width: 800px;
    margin: 0 auto;
    padding: 0 1rem;
}

.hero-content h1 {
    font-size: 2.5rem;
    margin-bottom: 1.5rem;
    color: var(--card-bg);
}

.hero-description {
    font-size: 1.2rem;
    line-height: 1.6;
    color: var(--card-bg);
    opacity: 0.95;
}

/* Features Section */
.feature-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.feature-card {
    background: var(--card-bg);
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    text-align: center;
    transition: all 0.3s ease;
    border: 1px solid rgba(0, 0, 0, 0.05);
}

.feature-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
}

.feature-icon {
    font-size: 2.5rem;
    color: var(--primary-color);
    margin-bottom: 1.5rem;
}

.feature-card h3 {
    color: var(--heading-color);
    margin-bottom: 1rem;
}

/* How It Works Section */
.alternate-bg {
    background: var(--section-bg, #f8f9fa);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
}

.how-it-works .section-title h2 {
    color: var(--primary-color);
}

.steps {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    position: relative;
}

.step {
    background: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
    position: relative;
    transition: transform 0.3s ease;
    border: 1px solid rgba(0, 0, 0, 0.05);
}

.step:hover {
    transform: translateY(-3px);
}

.step-number {
    width: 50px;
    height: 50px;
    background: var(--primary-gradient);
    color: #323232;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    font-weight: bold;
    margin: 0 auto 1.5rem;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.step h3 {
    color: var(--primary-color);
    margin-bottom: 1rem;
    font-size: 1.3rem;
    font-weight: 600;
}

.step p {
    color: var(--text-color);
    line-height: 1.6;
    margin: 0;
    opacity: 0.9;
}

/* Responsive Design - Sadece mobil için özel düzenlemeler */
@media (max-width: 768px) {
    .section-spacing {
        padding: 3rem 0;
        margin: 1rem 0;
    }

    .section-title h2 {
        font-size: 1.8rem;
    }

    .title-underline {
        width: 60px;
        height: 3px;
    }

    .step-number {
        width: 40px;
        height: 40px;
        font-size: 1.25rem;
    }
}

@media (max-width: 480px) {
    .about-hero {
        padding: 2rem 1rem;
    }

    .hero-content h1 {
        font-size: 1.6rem;
    }

    .hero-description {
        font-size: 0.95rem;
    }

    .feature-card {
        padding: 1.25rem;
    }

    .feature-icon {
        font-size: 2rem;
    }

    .step-number {
        width: 35px;
        height: 35px;
        font-size: 1.1rem;
    }
}

/* Container genişliği kontrolü */
@media (min-width: 1200px) {
    .container {
        max-width: 1140px;
        margin: 0 auto;
    }
}
</style>

<?php require_once 'includes/footer.php'; ?> 