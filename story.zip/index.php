<?php
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'config/paytr.php';
require_once 'config/autoload.php';
require_once 'src/Middleware/AuthMiddleware.php';

// Base Controller
require_once 'src/Controllers/BaseController.php';

// Controllers
require_once 'src/Controllers/AuthController.php';
require_once 'src/Controllers/HomeController.php';
require_once 'src/Controllers/CreditController.php';
require_once 'src/Controllers/GameController.php';
require_once 'src/Controllers/ProfileController.php';
require_once 'src/Controllers/AboutController.php';
require_once 'src/Controllers/StoryController.php';

// Oyunların aktiflik durumunu kontrol eden fonksiyon
function isGameActive($route) {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("SELECT is_active FROM dh_games WHERE route = ?");
    $stmt->execute([$route]);
    $game = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return ($game && $game['is_active'] == 1);
}

// Giriş gerektirmeyen rotalar
$publicRoutes = [
    'login', 
    'register', 
    'logout',
    'home',
    'about',  // About sayfası için eklendi
    'credits/notify',  // PayTR notify URL'i
    'credits/success', // İsterseniz success ve failed URL'lerini de ekleyebilirsiniz
    'credits/failed',
    'story/share'  // Paylaşılan hikayeler için eklendi
];

// Route'u al ve paylaşılan hikaye kontrolü yap
$requestUri = $_SERVER['REQUEST_URI'];
if (strpos($requestUri, '/story/share/') === 0) {
    $token = substr($requestUri, strlen('/story/share/'));
    if (!empty($token)) {
        require_once 'story/src/Controllers/StoryController.php';
        $controller = new StoryController();
        $controller->viewShared($token);
        exit;
    }
}

$route = $_GET['route'] ?? 'home';

// Mevcut switch-case yapısından önce eklenecek kontrol
if ($route == 'puzzle' && !isGameActive('puzzle')) {
    require 'includes/inactive.php';
    exit;
}

if ($route == 'story/list' && !isGameActive('story/list')) {
    require 'includes/inactive.php';
    exit;
}

// Eğer public route değilse auth kontrolü yap
if (!in_array($route, $publicRoutes)) {
    AuthMiddleware::isLoggedIn();
}

// Her istekte session'ı kontrol et (public routelar hariç)
if (!in_array($route, $publicRoutes) && isset($_SESSION['user_id'])) {
    AuthMiddleware::validateUserSession();
}

// Routing işlemleri
try {
    switch($route) {
        case 'home':
            $controller = new HomeController();
            $controller->index();
            break;
            
        case 'login':
            $controller = new AuthController();
            $controller->login();
            break;
            
        case 'register':
            $controller = new AuthController();
            $controller->register();
            break;
            
        case 'logout':
            $controller = new AuthController();
            $controller->logout();
            break;
            
        case 'credits':
            $controller = new CreditController();
            $controller->index();
            break;
            
        case 'credits/process':
            $controller = new CreditController();
            $controller->processPayment();
            break;
            
        case 'credits/callback':
            $controller = new CreditController();
            $controller->callback();
            break;
            
        case 'credits/manual-process':
            $controller = new CreditController();
            $controller->manualProcess();
            break;
            
        case 'credits/success':
            $controller = new CreditController();
            $controller->paymentSuccess();
            break;
            
        case 'credits/failed':
            $controller = new CreditController();
            $controller->paymentFailed();
            break;
            
        case 'credits/notify':
            $controller = new CreditController();
            $controller->paymentNotify();
            break;
            
        case 'credits/manual-purchase':
            $controller = new CreditController();
            $controller->manualPurchase();
            break;
            
        case 'credits/notify-payment':
            $controller = new CreditController();
            $controller->notifyPayment();
            break;
            
        case 'puzzle':
            $controller = new GameController();
            $controller->redirectToPuzzle();
            break;
            
        case 'profile':
            $controller = new ProfileController();
            $controller->edit();
            break;
            
        case 'profile/update':
            $controller = new ProfileController();
            $controller->update();
            break;
            
        case 'about':
            $controller = new AboutController();
            $controller->index();
            break;
            
        case 'story/share':
            $token = $_GET['token'] ?? null;
            if ($token) {
                $controller = new StoryController();
                $controller->viewShared($token);
            } else {
                header('Location: /');
            }
            break;
            
        case 'story':
            $controller = new StoryController();
            $controller->redirectToStory();
            break;
            
        default:
            http_response_code(404);
            require 'src/Views/errors/404.php';
            break;
    }
} catch (Exception $e) {
    error_log($e->getMessage());
    $_SESSION['error'] = 'Bir hata oluştu';
    header('Location: /');
    exit;
} 