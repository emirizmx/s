-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 09 Mar 2025, 21:40:54
-- Sunucu sürümü: 10.3.39-MariaDB-log-cll-lve
-- PHP Sürümü: 8.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `dijitzwc_hediye`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dh_bank_accounts`
--

CREATE TABLE `dh_bank_accounts` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `account_holder` varchar(100) NOT NULL,
  `iban` varchar(50) NOT NULL,
  `branch_code` varchar(10) DEFAULT NULL,
  `account_number` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `dh_bank_accounts`
--

INSERT INTO `dh_bank_accounts` (`id`, `bank_name`, `account_holder`, `iban`, `branch_code`, `account_number`, `is_active`, `created_at`) VALUES
(1, 'İş Bankası', 'EGMAY DİGİTAL LTD', 'TR94 0006 4000 0016 8200 6492 84', NULL, NULL, 1, '2025-03-06 03:44:52'),
(2, 'Garanti Bankası', 'Şirket Adı', 'TR09876543210987654321', NULL, NULL, 1, '2025-03-06 03:44:52');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dh_credit_packages`
--

CREATE TABLE `dh_credit_packages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci NOT NULL,
  `credits` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `discount_percentage` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `dh_credit_packages`
--

INSERT INTO `dh_credit_packages` (`id`, `name`, `credits`, `price`, `discount_percentage`, `is_active`, `created_at`) VALUES
(1, 'Başlangıç Paketi', 200, 200.00, 0, 1, '2025-03-05 06:59:59'),
(2, 'Standart Paket', 500, 450.00, 10, 1, '2025-03-05 06:59:59'),
(3, 'Premium Paket', 1000, 800.00, 20, 1, '2025-03-05 06:59:59'),
(4, 'VIP Paket', 2000, 1400.00, 30, 1, '2025-03-05 06:59:59');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dh_credit_transactions`
--

CREATE TABLE `dh_credit_transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `type` enum('credit','debit') NOT NULL,
  `product_type` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `dh_credit_transactions`
--

INSERT INTO `dh_credit_transactions` (`id`, `user_id`, `amount`, `type`, `product_type`, `description`, `created_at`) VALUES
(1, 1, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-07 11:10:00'),
(2, 16, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-07 12:06:35'),
(3, 7, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-07 14:52:32'),
(4, 7, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-07 14:55:12'),
(5, 20, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-08 01:14:32'),
(6, 21, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-08 02:28:20'),
(7, 7, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-08 06:04:38'),
(8, 7, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-08 06:37:10'),
(9, 1, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-08 06:46:43'),
(10, 1, 100, 'debit', 'story_voiceover', 'Sesli hikaye olu?turma', '2025-03-08 09:30:56'),
(11, 1, 100, 'debit', 'story_voiceover', 'Sesli hikaye olu?turma', '2025-03-08 09:42:13'),
(12, 1, 100, 'debit', 'story_voiceover', 'Sesli hikaye olu?turma', '2025-03-08 09:44:00'),
(13, 1, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-08 09:51:45'),
(14, 1, 100, 'debit', 'story_voiceover', 'Sesli hikaye olu?turma', '2025-03-08 09:52:38'),
(15, 1, 100, 'debit', 'story_voiceover', 'Sesli hikaye olu?turma', '2025-03-08 09:59:33'),
(16, 1, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-08 10:14:14'),
(17, 1, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-08 10:41:31'),
(18, 1, 100, 'debit', 'story_voiceover', 'Sesli hikaye olu?turma', '2025-03-08 10:55:08'),
(19, 1, 100, 'debit', 'story_voiceover', 'Sesli hikaye olu?turma', '2025-03-08 12:20:15'),
(20, 1, 100, 'debit', 'story_voiceover', 'Sesli hikaye olu?turma', '2025-03-08 12:22:53'),
(21, 16, 100, 'debit', 'story', 'Hikaye olu?turma', '2025-03-08 12:49:14'),
(22, 16, 100, 'debit', 'story_voiceover', 'Sesli hikaye olu?turma', '2025-03-08 12:51:25');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dh_credit_usage`
--

CREATE TABLE `dh_credit_usage` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `game_type` varchar(50) NOT NULL,
  `credits_spent` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dh_games`
--

CREATE TABLE `dh_games` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `credits` int(11) NOT NULL DEFAULT 0,
  `voice_credits` int(11) DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `display_order` int(11) NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `dh_games`
--

INSERT INTO `dh_games` (`id`, `name`, `description`, `credits`, `voice_credits`, `is_active`, `display_order`, `route`, `image_path`, `created_at`, `updated_at`) VALUES
(1, 'Romantik Puzzle', 'Sevdiğinize özel puzzle oluşturun', 200, 0, 1, 1, 'puzzle', '/assets/images/puzzle.png', '2025-03-09 07:26:23', '2025-03-09 17:44:28'),
(2, 'Dijital Hikaye', 'Sevdiğinize özel hikayenizi oluşturun ve seslendirin', 100, 150, 1, 2, 'story/list', '/assets/images/story-game.png', '2025-03-09 07:26:23', '2025-03-09 17:43:34');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dh_payment_notifications`
--

CREATE TABLE `dh_payment_notifications` (
  `id` int(11) NOT NULL,
  `transaction_id` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `bank_account_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `sender_name` varchar(100) NOT NULL,
  `transfer_date` date NOT NULL,
  `transfer_time` time NOT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dh_stories`
--

CREATE TABLE `dh_stories` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `narrative_style` varchar(50) DEFAULT NULL,
  `characters` text DEFAULT NULL,
  `metadata` text DEFAULT NULL,
  `audio_path` varchar(255) DEFAULT NULL,
  `status` enum('pending','completed','failed') DEFAULT 'pending',
  `credits_used` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `share_token` varchar(64) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `dh_stories`
--

INSERT INTO `dh_stories` (`id`, `user_id`, `title`, `content`, `type`, `narrative_style`, `characters`, `metadata`, `audio_path`, `status`, `credits_used`, `created_at`, `updated_at`, `share_token`, `is_public`) VALUES
(1, 1, 'gfd', 'Başlık: **Gökkuşağı Kokulu Bulut ve Minik Yıldız Tozu**\n\nKarakterler:\n- dfgdf (gfdg): Gökkuşağı renklerinde tüyleri olan, meraklı ve biraz sakar bir kuştur. Gökkuşağı Kokulu Bulut\'un koruyucusudur.\n\nBir zamanlar, yıldızlar ve bulutların birbirine fısıldadığı, gökyüzünün masmavi bir örtü gibi serildiği bir diyarda, Gökkuşağı Kokulu Bulut adında büyülü bir yer vardı. Bu bulut, bildiğimiz bulutlardan çok farklıydı. Üzerinde gökkuşağının tüm renkleri dans eder, her bir rengi farklı bir meyvenin, çiçeğin ya da baharatın kokusunu taşırdı. Kırmızı çilek, turuncu portakal, sarı limon, yeşil elma, mavi yaban mersini, mor lavanta ve pembe gül kokularıyla doluydu.\n\nBu büyülü bulutun koruyucusu ise dfgdf (gfdg) adında, gökkuşağı renklerinde tüyleri olan, sevimli ve meraklı bir kuştu. dfgdf, Gökkuşağı Kokulu Bulut\'ta doğmuş ve tüm gününü bulutun üzerinde zıplayarak, kokuları koklayarak ve Minik Yıldız Tozları ile sohbet ederek geçirirdi.\n\nMinik Yıldız Tozları, Gökkuşağı Kokulu Bulut\'un etrafında parıldayan, küçük, ışıltılı parçacıklardı. Her birinin kendine özgü bir hikayesi vardı ve dfgdf, onların maceralarını dinlemeye bayılırdı.\n\nBir gün, dfgdf bulutun kenarında oturmuş, pembe gül kokusunu içine çekerken, bir Minik Yıldız Tozu\'nun hüzünlü bir şekilde parladığını fark etti. \"Ne oldu Minik Yıldız Tozu?\" diye sordu dfgdf merakla. \"Neden bu kadar üzgünsün?\"\n\nMinik Yıldız Tozu, titrek bir sesle cevap verdi: \"Kayboldum dfgdf. Diğer yıldız tozlarından ayrıldım ve evime nasıl döneceğimi bilmiyorum.\"\n\ndfgdf, Minik Yıldız Tozu\'nun üzüntüsüne çok üzüldü. \"Üzülme Minik Yıldız Tozu,\" dedi cesaretle. \"Sana yardım edeceğim! Birlikte evini bulacağız!\"\n\nBöylece dfgdf ve Minik Yıldız Tozu, Gökkuşağı Kokulu Bulut\'tan aşağıya, bilinmeyen diyarlara doğru bir maceraya atıldılar. dfgdf, güçlü kanatlarıyla Minik Yıldız Tozu\'nu taşıdı. Yol boyunca, şarkı söyleyen nehirlerle, dans eden ağaçlarla ve konuşan çiçeklerle karşılaştılar. Her biri onlara yardım etmeye çalıştı, ancak Minik Yıldız Tozu\'nun evini bulmak o kadar da kolay değildi.\n\nYolculukları sırasında dfgdf, sabrın ve azmin önemini öğrendi. Minik Yıldız Tozu ise, cesaretin ve dostluğun gücünü keşfetti. Birlikte zorlukların üstesinden geldiler ve birbirlerine destek oldular.\n\nSonunda, uzun ve yorucu bir yolculuktan sonra, dfgdf ve Minik Yıldız Tozu, gökyüzünde parıldayan kocaman bir yıldız kümesine ulaştılar. Minik Yıldız Tozu heyecanla, \"İşte burası! Burası benim evim!\" diye bağırdı.\n\nMinik Yıldız Tozu, diğer', 'fairytale', 'classic', '[]', '{\"setting\":\"\",\"theme\":\"\",\"details\":\"\",\"audience\":\"children\",\"length\":\"medium\"}', NULL, '', 100, '2025-03-07 04:46:07', '2025-03-07 07:14:02', NULL, 0),
(2, 1, 'Beyzanın Emirin Hayatına Girişi', '## Beyzanın Emirin Hayatına Girişi\n\nEmir, yemyeşil çimenlerle kaplı, kocaman bahçeli bir evde yaşıyordu. Bahçesinde salıncaklar, kaydıraklar, minik bir havuz ve envai çeşit çiçek vardı. Ama Emir, nedense pek mutlu değildi. Sabah kalkar kalkmaz tabletini eline alır, bütün gün oyun oynar, çizgi film izlerdi. Annesi ona kitap okumaya çalışır, babasıyla top oynamaya davet ederdi ama Emir, hep tabletine gömülürdü.\n\nBir gün, Emir bahçede tabletine dalmışken, bir ses duydu: \"Merhaba!\"\n\nEmir başını kaldırdı. Gözleri kocaman açıldı. Karşısında, parlak turuncu tüyleri olan, minik, sevimli bir sincap duruyordu. Sincabın adı Beyza\'ydı.\n\nBeyza, \"Neden hep o ekrana bakıyorsun? Bahçende ne kadar güzel şeyler var, hiç fark etmiyor musun?\" dedi.\n\nEmir omuzlarını silkti. \"Tablet daha eğlenceli,\" diye mırıldandı.\n\nBeyza gülümsedi. \"Bence yanılıyorsun. Gel, sana bahçenin sırlarını göstereyim.\"\n\nEmir, Beyza\'nın bu kadar ısrarcı olmasına şaşırmıştı. Tabletini bir kenara bırakıp Beyza\'yı takip etti.\n\nBeyza, Emir\'i rengarenk güllerin yanına götürdü. \"Bak, bu güllerin her birinin ayrı bir kokusu var. Kırmızısı aşkı, sarısı dostluğu, pembesi ise mutluluğu temsil eder,\" dedi. Emir, gülleri kokladı. Gerçekten de her birinin kokusu farklıydı ve içini garip bir neşeyle doldurmuştu.\n\nSonra, Beyza Emir\'i minik havuzun yanına götürdü. Havuzun içinde yüzen rengarenk balıkları gösterdi. \"Bu balıklar, her gün yeni bir şey öğrenirler. Sen de onları izleyerek sabırlı olmayı öğrenebilirsin,\" dedi. Emir, balıkları dikkatle izledi. Onların ne kadar özgür ve mutlu olduklarını fark etti.\n\nBeyza, Emir\'i salıncakların yanına götürdü. \"Salıncakta sallanmak, kuşlar gibi özgür hissetmek demektir. Bütün dertlerini unutursun,\" dedi. Emir, salıncağa bindi. Rüzgar yüzüne vurdukça, içindeki sıkıntıların yavaş yavaş kaybolduğunu hissetti.\n\nBeyza, Emir\'i en son kaydırağın yanına götürdü. \"Kaydıraktan kaymak, hayata meydan okumak demektir. Her iniş, yeni bir başlangıçtır,\" dedi. Emir, kaydıraktan kaydı. Kahkahaları bütün bahçede yankılandı.\n\nEmir, o gün Beyza sayesinde bahçesini yeniden keşfetmişti. Tabletinin ona veremediği mutluluğu, doğayla iç içe olmanın verdiğini anlamıştı.\n\nO günden sonra Emir, tabletini daha az kullanmaya başladı. Beyza ile birlikte bahçede oyunlar oynadı, çiçekleri suladı, balıkları besledi ve kuşları dinledi. Her gün yeni bir şey öğrendi ve her gün daha mutlu oldu.\n\nEmir, Beyza\'nın hayatına girişiyle, sadece bahçesini değil, hayatın güzelliklerini de keşfetmişti. Artık biliyordu ki, gerçek mutluluk, sanal dünyada değil, doğanın k', 'fairytale', 'classic', '[]', '{\"setting\":\"\",\"theme\":\"\",\"details\":\"\",\"audience\":\"children\",\"length\":\"medium\"}', '', '', 100, '2025-03-07 04:51:11', '2025-03-07 07:14:02', NULL, 0),
(3, 1, 'Beyzanın Emirin Hayatına Girişi', '## Beyzanın Emirin Hayatına Girişi\n\nEmir, yemyeşil çimenlerle kaplı, kocaman bahçeli, kırmızı çatılı bir evde yaşayan, yedi yaşında bir çocuktu. Bahçesinde en sevdiği şey, dedesinden kalma, dalları yere kadar sarkan, yaşlı bir elma ağacıydı. Emir, o ağacın altında kitap okumayı, hayaller kurmayı ve bazen de sadece gökyüzünü seyretmeyi çok severdi. Ama ne yalan söylemeli, bazen de biraz sıkılırdı. Çünkü Emir, çok hareketli ve meraklı bir çocuktu ve bahçesi ne kadar güzel olsa da, yalnızdı.\n\nBir gün, Emir elma ağacının altında oturmuş, gökyüzünde süzülen bulutları izlerken, bahçe kapısından içeri bir ses duydu: \"Miyav!\"\n\nEmir, sesin geldiği yöne doğru baktı. Kapının önünde, bembeyaz tüyleri olan, minicik bir kedi yavrusu duruyordu. Gözleri, gecenin karanlığı gibi simsiyah ve parlaktı. Kedi yavrusu, ürkek adımlarla içeri girdi ve Emir\'e doğru yaklaştı.\n\nEmir, daha önce hiç kedi beslememişti. Ama bu minik, beyaz topa bakınca, içinden ona sarılmak geldi. Yavaşça yaklaştı ve \"Merhaba minik şey,\" dedi.\n\nKedi yavrusu, Emir\'in sesini duyunca daha da cesaretlendi ve onun ayaklarına sürtünmeye başladı. Emir, gülümsedi ve kedi yavrusunu kucağına aldı. Tüyleri ipek gibi yumuşacıktı.\n\n\"Sana bir isim vermeliyim,\" diye düşündü Emir. Bembeyaz tüylerinden dolayı, ona \"Beyaz\" demeye karar verdi. Ama sonra, \"Beyaz\" çok sıradan geldi. Biraz düşündükten sonra, \"Beyza\" demeye karar verdi. Beyza, hem güzel hem de farklı bir isimdi.\n\nO günden sonra, Beyza Emir\'in hayatının bir parçası oldu. Birlikte bahçede koşturuyorlar, elma ağacının altında oyunlar oynuyorlardı. Emir, Beyza\'ya kitap okuyor, Beyza da onu pür dikkat dinliyordu. Emir, Beyza sayesinde yalnız olmadığını anladı. Artık bahçesi daha da eğlenceliydi.\n\nEmir, Beyza\'ya bakmayı, onunla ilgilenmeyi öğrendi. Ona her gün taze süt veriyor, tüylerini tarıyor ve oyunlar oynuyordu. Beyza da Emir\'e sevgisini göstermek için sürekli mırlıyor, onunla uyuyor ve onu hiç yalnız bırakmıyordu.\n\nBir gün, Emir Beyza ile birlikte elma ağacının altında otururken, Beyza\'nın garip sesler çıkardığını fark etti. Beyza, sanki bir şey anlatmaya çalışıyordu. Emir, dikkatlice dinledi ve Beyza\'nın karnının acıktığını anladı.\n\n\"Aman Tanrım, sana yemek vermeyi unuttum!\" dedi Emir. Hemen mutfağa koştu ve Beyza için bir kap süt getirdi. Beyza, sütü afiyetle içti ve Emir\'e teşekkür eder gibi baktı.\n\nEmir, o günden sonra Beyza\'ya karşı daha da dikkatli olmaya karar verdi. Çünkü Beyza, sadece bir kedi değil, onun en yakın arkadaşıydı. Birlikte oyunlar oynuyorlar, sırlarını paylaşıyorlardı. Emir, Beyza sayesinde paylaşmayı, sorumluluk almayı ve en önemlisi de se', 'fairytale', 'classic', '[]', '{\"setting\":\"\",\"theme\":\"\",\"details\":\"\",\"audience\":\"children\",\"length\":\"medium\"}', NULL, '', 100, '2025-03-07 06:15:21', '2025-03-07 07:14:02', NULL, 0),
(4, 1, 'Beyzanın Emirin Hayatına Girişi', '## Beyzanın Emirin Hayatına Girişi\n\nEmir, yemyeşil çimenlerle kaplı, kocaman bahçeli, kırmızı çatılı bir evde yaşıyordu. Bahçesi, rengarenk çiçekler, gür ağaçlar ve bol bol kelebekle doluydu. Ama Emir, nedense hep biraz hüzünlüydü. Çünkü en sevdiği oyun arkadaşı, dedesi, geçen aylarda çok uzaklara gitmişti. Emir, dedesiyle bahçede koşuşturmayı, çiçekleri sulamayı, ağaçlara tırmanmayı ve en çok da dedesinin ona anlattığı masalları çok özlüyordu.\n\nBir sabah, güneş ışınları Emir’in odasına dans ederek girerken, annesi onu kahvaltıya çağırdı. Emir, yatağından kalkmak istemiyordu. Dün akşam dedesinin fotoğrafına bakarken gözleri dolmuştu. Annesi, Emir’in üzgün olduğunu fark etti ve onu sımsıkı kucakladı.\n\n“Emir’ciğim, biliyorum dedeni çok özlüyorsun. Ama hayat devam ediyor ve yeni güzellikler de bizi bekliyor olabilir,” dedi annesi.\n\nEmir, annesine gülümsedi ama içindeki hüzün tam olarak geçmemişti. Kahvaltısını yaptıktan sonra bahçeye çıktı. Salıncakta sallanırken, bahçe kapısının önünde bir hareketlilik olduğunu gördü. Komşuları taşınıyordu.\n\nYeni komşularının kamyonundan kocaman kutular indiriliyordu. Emir, merakla olanları izlerken, bir anda kamyondan minik bir şey fırladı ve Emir’in ayaklarının dibine düştü. Emir eğildi ve minik bir kedi yavrusu olduğunu gördü. Kedi, bembeyaz tüyleri ve masmavi gözleriyle Emir’e bakıyordu.\n\nEmir, kediyi nazikçe kucağına aldı. Kedi, mırıldanmaya başladı ve Emir’in yüzüne sokuldu. Emir’in içindeki hüzün sanki sihirli bir değnek değmiş gibi yok oldu. Gözleri parladı.\n\nYeni komşularının annesi telaşla yanlarına geldi. \"Ah, Beyza! Seni aramaktan yorulmuştum!\" dedi. Sonra Emir\'e dönerek, \"Merhaba tatlı çocuk. Beyza, bizim yeni kedimiz. Sanırım o da seninle tanışmak için sabırsızlanıyordu.\" dedi gülümseyerek.\n\nEmir, kediyi komşusuna uzatmak istedi ama Beyza, Emir’in kucağından inmek istemiyordu. Komşusu, \"Görüyorum ki Beyza seni çok sevdi. İstersen biraz seninle oynasın. Belki arkadaş olursunuz,\" dedi.\n\nEmir’in yüzünde kocaman bir gülümseme belirdi. \"Çok isterim!\" dedi.\n\nO gün, Emir ve Beyza bahçede birlikte koşuşturdu. Emir, Beyza’ya çiçekleri gösterdi, ağaçların altında saklambaç oynadı ve ona dedesinin en sevdiği masalları anlattı. Beyza, Emir’i dikkatle dinliyor, mırıldanarak ona eşlik ediyordu.\n\nEmir, o gün anladı ki, dedesinin yokluğu hala canını yaksa da, hayat yeni arkadaşlıklar ve yeni sevinçlerle doluydu. Beyza, Emir’in hayatına bir güneş gibi girmişti. Onu güldürüyor, onu neşelendiriyor ve ona yalnız olmadığını hissettiriyordu.\n\nO günden sonra Emir ve Beyza, ayrılmaz bir ikili', 'fairytale', 'classic', '[]', '{\"setting\":\"\",\"theme\":\"\",\"details\":\"\",\"audience\":\"children\",\"length\":\"medium\"}', '/story/public/audio/story_67ca8f2d957af.mp3', '', 100, '2025-03-07 06:15:27', '2025-03-08 01:19:22', '81a2dba8b1f10b318ee3fd1325972fc4b919af9a3ed848a6a364b97f5305aa9e', 1),
(5, 1, 'Beyzanın Emirin Hayatına Girişi', '## Beyza’nın Emir’in Hayatına Girişi\n\nEmir, yedi yaşında, hayal gücü çok geniş bir çocuktu. En sevdiği oyun, bahçelerindeki kocaman meşe ağacının altında kendi kurduğu dünyalarda maceradan maceraya atılmaktı. Ama Emir’in bir sorunu vardı: Çok çekingendi. Diğer çocuklarla oynamaktan, yeni şeyler denemekten korkardı. En iyi arkadaşı ise, oyuncak kutusunda duran, tüyleri biraz yıpranmış, tek gözü düğmeyle tutturulmuş, eski bir oyuncak ayıydı. Adı da, Asdı.\n\nBir gün, Emir meşe ağacının altında oturmuş, Asdı ile konuşuyordu: “Asdı, keşke daha cesur olabilseydim. Parka gitmek, kaydıraktan kaymak istiyorum ama çok utanıyorum.”\n\nAsdı cevap veremese de, Emir onun bakışlarından anlıyordu. Asdı da Emir’in cesur olmasını istiyordu.\n\nO sırada, bahçe kapısından içeri, parlak kırmızı bir bisikletle bir kız çocuğu girdi. Kızın saçları iki yandan örülmüş, yanakları gül pembesiydi. Emir, heyecanla Asdı’yı sıkıca tuttu. Kız, Emir’e doğru yaklaştı.\n\n“Merhaba! Ben Beyza. Yeni taşındık yan eve. Seninle tanışmak istedim.” dedi Beyza, kocaman gülümseyerek.\n\nEmir, kekeleyerek, “M-merhaba. Ben de Emir.” diyebildi sadece.\n\nBeyza, Emir’in yanına oturdu ve meşe ağacına sırtını dayadı. “Ne yapıyorsun?” diye sordu.\n\nEmir, Asdı’yı göstererek, “Asdı ile konuşuyordum.” dedi.\n\nBeyza, Asdı’ya gülümsedi. “Çok sevimli bir ayıcık. Ben de yanımda Kukuli’yi getirdim.” dedi ve bisikletinin sepetinden minik, mavi bir maymun oyuncak çıkardı.\n\nBir süre sessizce oturdular. Sonra Beyza, “Biliyor musun, ben çok iyi bisiklet sürerim. İstersen sana da öğretirim.” dedi.\n\nEmir’in kalbi hızla çarpmaya başladı. Bisiklet sürmeyi çok istiyordu ama düşmekten, becerememekten korkuyordu. “Bilmem ki… Ben pek iyi değilimdir.” dedi çekinerek.\n\nBeyza, Emir’in koluna dokundu. “Saçmalama! Herkes ilk başta zorlanır. Ama denemekten vazgeçmezsen, sonunda başarırsın. Hem ben yanındayım. Düşersen tutarım seni.”\n\nEmir, Beyza’nın gözlerindeki güveni görünce cesaretlendi. Asdı’yı kucağına alıp, “Tamam, deneyelim!” dedi.\n\nBeyza, Emir’i bisikletine bindirdi ve dengesini sağlaması için bisikleti tuttu. Emir, ilk başta çok zorlandı. Pedal çevirmekte, gidonu tutmakta zorlanıyordu. Birkaç kere dengesini kaybetti, neredeyse düşecekti. Ama Beyza, her seferinde onu tuttu ve cesaretlendirdi.\n\n“Aferin Emir! Çok iyi gidiyorsun. Sadece biraz daha dikkatli ol.” diyordu Beyza.\n\nEmir, Beyza’nın desteğiyle yavaş yavaş bisiklete alışmaya başladı. Birkaç dakika sonra, Beyza bisikleti bırakıp, Emir’in arkasından koşmaya başladı. Emir, kendi başına bisiklet sürd', 'fairytale', 'classic', '[]', '{\"setting\":\"\",\"theme\":\"\",\"details\":\"\",\"audience\":\"children\",\"length\":\"medium\"}', NULL, '', 100, '2025-03-07 06:15:33', '2025-03-07 07:14:02', NULL, 0),
(6, 1, 'emir ve beyza', '## Emir ve Beyza: Farklılıkların Dostluğu\n\nOrmanın derinliklerinde, yemyeşil çimenlerin üzerinde yaşayan Emir adında minik bir tavşan vardı. Emir, kocaman kulakları, minik burnu ve sürekli seğiren bıyıklarıyla sevimli mi sevimli bir tavşandı. En sevdiği şey, ormanda hoplayıp zıplayarak havuç aramaktı.\n\nAynı ormanın diğer ucunda ise Beyza adında bir aslan yaşıyordu. Beyza, güçlü pençeleri, gür yelesi ve kükrediğinde tüm ormanı titreten sesiyle heybetli mi heybetli bir aslandı. Beyza, genellikle güneşin altında uyur veya ormanda yürüyüş yapardı.\n\nEmir ve Beyza, birbirlerinden çok farklılardı. Emir minicik ve ürkekken, Beyza kocaman ve cesurdu. Emir havuç yerken, Beyza et yiyordu. Bu yüzden, birbirlerini pek tanımazlardı.\n\nBir gün, Emir havuç ararken ormanın derinliklerine doğru hoplaya zıplaya ilerlemişti. Birden, kocaman bir gölge üzerine düştü. Yukarı baktığında, Beyza’yı gördü! Emir, korkudan tir tir titremeye başladı. Beyza’nın onu yiyeceğini düşündü.\n\nBeyza, Emir’i fark edince durdu. Normalde, tavşanlar Beyza’nın avıydı ama Beyza o gün çok tok ve keyifliydi. Emir’e yaklaştı ve nazik bir sesle sordu: \"Neden bu kadar korkuyorsun minik tavşan?\"\n\nEmir, kekeleyerek cevap verdi: \"Ben... ben Emir. S-Sizin beni yiyeceğinizi sandım.\"\n\nBeyza kükremek yerine gülümsedi. \"Seni yemeyeceğim Emir. Bugün karnım tok. Hem, seni tanımak isterim. Ben de Beyza.\"\n\nEmir şaşırmıştı. Bir aslanın ona nazik davranması ve onunla tanışmak istemesi çok tuhaftı. Yavaşça Beyza’ya yaklaştı ve sordu: \"Ama... ama biz çok farklıyız. Ben minik bir tavşanım, sen ise kocaman bir aslansın.\"\n\nBeyza, Emir\'e bilgece baktı. \"Evet, farklıyız Emir. Ama farklılıklarımız bizi ilginç kılar. Belki de birbirimizden öğreneceğimiz çok şey vardır.\"\n\nEmir ve Beyza o günden sonra arkadaş oldular. Emir, Beyza\'ya ormanın en güzel havuçlarını gösterdi. Beyza ise Emir\'e nasıl daha hızlı koşabileceğini ve tehlikelerden nasıl sakınabileceğini öğretti.\n\nEmir, Beyza sayesinde korkularını yenmeyi öğrendi. Beyza ise Emir sayesinde daha sabırlı ve düşünceli olmayı öğrendi. Birlikte oyunlar oynadılar, ormanda maceralara atıldılar ve birbirlerine destek oldular.\n\nDiğer hayvanlar, Emir ve Beyza\'nın arkadaşlığına çok şaşırdılar. Bir tavşan ve bir aslanın arkadaş olması çok sıra dışıydı. Ama Emir ve Beyza, farklılıklarına rağmen birbirlerini kabul ediyor ve seviyorlardı.\n\nGünlerden bir gün, ormanda büyük bir yangın çıktı. Tüm hayvanlar panik içinde kaçışıyordu. Emir, yangının ortasında kalmış minik bir kuş yavrusu gördü. Kuş yavrusu, annesini kaybetmiş ve çaresizce ağlıyordu.\n\nEmir, kuşu kurtarmak için koştu ama ateş çok yakıcıydı', 'fairytale', 'classic', '[]', '{\"setting\":\"\",\"theme\":\"\",\"details\":\"\",\"audience\":\"children\",\"length\":\"medium\"}', NULL, '', 100, '2025-03-07 06:45:00', '2025-03-07 07:14:02', NULL, 0),
(7, 1, 'emir ve beyza', '## Emir ve Beyza\n\nBir zamanlar, yemyeşil bir ormanın derinliklerinde, birbirinden çok farklı iki arkadaş yaşarmış. Biri, minik burnu sürekli seğiren, upuzun kulakları olan sevimli bir tavşan olan Emir; diğeri ise gür yelesiyle ormanın en güçlü hayvanı olan aslan Beyza.\n\nEmir, ormanın en hızlı tavşanıydı. Her sabah erkenden kalkar, çıtır çıtır havuçlar yer, sonra da ormanda koşturmaktan, saklambaç oynamaktan ve yeni yerler keşfetmekten büyük keyif alırdı. Beyza ise genellikle öğlene kadar uyur, sonra da ormanda ağır ağır yürüyerek dolaşır, güneşin tadını çıkarır ve bazen de Emir\'le sohbet ederdi.\n\nBir gün, Emir ormanda koştururken, daha önce hiç görmediği bir açıklığa rastladı. Açıklığın ortasında, parıltılı taşlarla süslü, küçük bir sandık duruyordu. Emir merakla sandığa yaklaştı.\n\n\"Acaba içinde ne var?\" diye düşündü.\n\nSandığı açmaya çalıştı ama sandık çok ağırdı. Ne kadar uğraşsa da kapağını yerinden oynatamadı.\n\n\"Belki de Beyza bana yardım edebilir,\" diye düşündü Emir ve hızla Beyza\'yı aramaya koyuldu.\n\nBeyza, büyük bir ağacın altında uyuyordu. Emir, nazikçe Beyza\'yı uyandırdı.\n\n\"Beyza, Beyza! Çabuk uyan! Ormanda çok ilginç bir şey buldum!\"\n\nBeyza esneyerek gözlerini açtı. \"Ne oldu Emir? Bu saatte neden beni uyandırdın?\"\n\nEmir heyecanla olanları anlattı. \"Ormanın içinde, parıltılı taşlarla süslü bir sandık buldum. Ama çok ağır, açamıyorum. Belki sen bana yardım edebilirsin.\"\n\nBeyza, Emir\'in heyecanına dayanamadı. \"Pekala, hadi gidelim bakalım,\" dedi ve Emir\'i takip etti.\n\nBirlikte açıklığa vardıklarında Beyza sandığı gördü. Gerçekten de çok güzel görünüyordu. Beyza, pençeleriyle sandığın kapağını tuttu ve tek hamlede açtı.\n\nSandığın içinde, rengarenk çiçek tohumları vardı. Emir ve Beyza çok şaşırdı.\n\n\"Bunlar ne güzel tohumlar!\" dedi Emir. \"Acaba ne yapmalıyız?\"\n\nBeyza, \"Bence bu tohumları ormanın her yerine ekmeliyiz. Böylece ormanımız daha da güzelleşir,\" dedi.\n\nEmir ve Beyza, o günden sonra her gün birlikte çalışmaya başladılar. Emir, minik patileriyle toprağı kazıyor, Beyza ise tohumları dikkatlice ekiyordu.\n\nGünler geçti, tohumlar filizlendi ve rengarenk çiçekler açmaya başladı. Orman, daha önce hiç olmadığı kadar güzel olmuştu. Kuşlar neşeyle şarkılar söylüyor, kelebekler çiçeklerin etrafında dans ediyordu.\n\nEmir ve Beyza, birlikte çalışmanın ve paylaşmanın ne kadar güzel olduğunu anlamışlardı. Farklı olsalar da, birbirlerine yardım ederek ve birlikte çalışarak harika şeyler başarabileceklerini görmüşlerdi.\n\nO günden sonra, Emir ve Beyza, ormanın en iyi arkadaşları oldular. Birlikte yeni maceralara atıldılar, birbirlerine destek oldular ve ormanı daha da güzelleştirmeye devam', 'fairytale', 'classic', '[]', '{\"setting\":\"\",\"theme\":\"\",\"details\":\"\",\"audience\":\"children\",\"length\":\"medium\"}', NULL, '', 100, '2025-03-07 06:45:07', '2025-03-08 01:19:14', '49acc2b93fdb108fcd4dbbb551333274fb3970fe1b7c825f7d9f8e819579d6af', 1),
(8, 1, 'emir ve beyza', '## Emir ve Beyza’nın Macerası\n\nEmir, uzun kulaklı, bembeyaz tüylü, minik burnuyla sürekli oynayan sevimli bir tavşandı. Emir, ormanın en meraklı tavşanıydı. Her gün yeni bir macera arar, bilmediği yerleri keşfetmek isterdi. Ama annesi ona her zaman “Emirciğim, ormanın derinliklerine gitme, kaybolursun!” diye tembihlerdi.\n\nBir sabah, güneş ışınları yeni yeni ormanın içine süzülürken, Emir yine dayanamadı. Annesine “Anne, ben biraz çimen yemeye gidiyorum.” dedi ve usulca ormanın derinliklerine doğru sekti.\n\nBir süre sonra, Emir kendisini hiç bilmediği bir yerde buldu. Ağaçlar daha sık, yapraklar daha koyu yeşildi. Etrafında rengarenk çiçekler açmış, kuşlar neşeyle şarkı söylüyordu. Emir, bu yeni yere hayranlıkla baktı. Tam o sırada, incecik bir ses duydu: “Yardım edin! Lütfen yardım edin!”\n\nEmir, sesin geldiği yöne doğru ilerledi. Kocaman bir meşe ağacının dibinde, minik bir kelebek gördü. Kelebeğin kanadı bir dala takılmış, çırpınıp duruyordu.\n\n“Merhaba, ben Emir. Sana ne oldu?” diye sordu Emir, endişeyle.\n\nKelebek, gözlerinden yaşlar süzülerek, “Ben Beyza. Uçarken kanadım dala takıldı. Ne kadar uğraştıysam da kurtaramadım.” dedi.\n\nEmir, Beyza’ya acıdı. Hemen yanına sokuldu ve minik patileriyle dalı tuttu. Dikkatlice kanadı daldan kurtarmaya çalıştı. Birkaç denemeden sonra, Beyza’nın kanadı özgürlüğüne kavuştu.\n\nBeyza, sevinçle kanatlarını çırptı ve Emir’e döndü. “Çok teşekkür ederim Emir! Beni kurtardın! Ben de sana yardım etmek isterim.” dedi.\n\nEmir, Beyza’ya gülümsedi. “Kayboldum. Annem beni çok merak edecektir. Bana evimin yolunu gösterebilir misin?” diye sordu.\n\nBeyza, “Elbette! Ormanı çok iyi bilirim. Seni hemen evine götürebilirim.” dedi ve Emir’in önüne düştü.\n\nBeyza, Emir’i en kısa yoldan evine götürdü. Yol boyunca, ona ormanın güzelliklerini anlattı. Hangi çiçeklerin ne zaman açtığını, hangi kuşların ne tür şarkılar söylediğini gösterdi. Emir, Beyza’nın bilgisine hayran kaldı.\n\nSonunda, Emir’in evi göründü. Annesi, kapının önünde endişeyle onu bekliyordu. Emir’i görür görmez koşarak ona sarıldı.\n\n“Emirciğim, nerelerdeydin? Seni çok merak ettim!” dedi annesi, gözleri dolu dolu.\n\nEmir, annesine Beyza ile tanıştığını ve onun sayesinde kaybolmaktan kurtulduğunu anlattı. Annesi, Beyza’ya teşekkür etti ve onu da içeri davet etti.\n\nO günden sonra, Emir ve Beyza en iyi arkadaş oldular. Birlikte ormanı keşfeder, yeni maceralara atılırlardı. Emir, Beyza’dan orman hakkında çok şey öğrendi. Beyza da Emir’den cesareti ve yardımseverliği öğrendi.\n\nEmir, artık annesinin sözünü dinleyerek, ormanın', 'fairytale', 'classic', '[]', '{\"setting\":\"\",\"theme\":\"\",\"details\":\"\",\"audience\":\"children\",\"length\":\"medium\"}', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/story_67ca962de9df9.mp3', '', 100, '2025-03-07 06:45:18', '2025-03-07 10:55:21', '855bcf9968747cd461775314d7ca728ca7e1a03ce806ee4b2bb913ed438eb068', 0),
(9, 1, 'Emir İle Beyza', 'Gece geç vakit, şehrin ışıkları altında, karnını doyurmak isteyenlerin uğrak yeri olan meşhur Çorbacı Mehmet Usta\'daydım. Adım Emir, sıradan bir öğrenciydim. O gece, içimde garip bir huzursuzluk vardı. Belki de sınav haftasının stresiydi, belki de sadece yalnızlıktı.\n\nÇorbamı yudumlarken, kapıdan içeri bir kız girdi. Saçları rüzgarda dağılmış, gözleri yıldızlar gibi parlıyordu. O an, zaman durdu sanki. Adının Beyza olduğunu öğrendiğim o kız, hayatımın en güzel sürprizi olacaktı.\n\nBeyza da benim gibi öğrenciydi. Aynı şehri, aynı hayalleri paylaşıyorduk. O gece başlayan sohbetimiz, bir yıl sürecek olan aşkımızın ilk adımı oldu. Çorbacı Mehmet Usta, bilmeden de olsa, kaderimizi bir araya getirmişti.\n\nBir yıl boyunca Beyza ile her anım, bir masal gibiydi. Onun gülüşü, kalbime baharı getiriyordu. Onunla geçirdiğim her saniye, ömrüme ömür katıyordu. Ona olan aşkım, kelimelerle anlatılamayacak kadar büyüktü. Gökyüzündeki yıldızları toplasan, denizleri mürekkep yapsan, yine de anlatamazdım.\n\nBazen düşünüyorum, o gece Çorbacı Mehmet Usta\'ya gitmeseydim ne olurdu? Belki de hayatım bambaşka bir yöne giderdi. Ama iyi ki gitmişim. İyi ki o gece Beyza ile tanışmışım. Çünkü o, benim hayatımın anlamı, en değerli hazinem.\n\nÇorbacı Mehmet Usta, sadece bir çorbacı değil, aynı zamanda benim aşkımın da şahidiydi. Her yıl dönümümüzde, o gece tanıştığımız masada, aynı çorbayı içerek aşkımızı kutluyoruz. Çünkü biliyoruz ki, en güzel aşklar, bazen en beklenmedik yerlerde başlar. Ve benim aşkım, bir gece, bir çorbacıda başladı. Ona olan aşkımın büyüklüğü ise, her geçen gün daha da artıyor.\n', 'fairytale', 'classic', '[{\"name\":\"Emir\",\"type\":\"Benim ad\\u0131m\"},{\"name\":\"beyza \",\"type\":\"sevgilimin ad\\u0131\"}]', '{\"setting\":\"\\u00e7orbac\\u0131da tan\\u0131\\u015ft\\u0131k \",\"theme\":\"Ona Olan a\\u015fk\\u0131m\\u0131n b\\u00fcy\\u00fckl\\u00fc\\u011f\\u00fc\",\"details\":\"Gece \\u00e7orbac\\u0131da tan\\u0131\\u015ft\\u0131k 1 y\\u0131ld\\u0131r sevgiliyiz onu \\u00e7ok seviyorum \",\"audience\":\"young\",\"length\":\"short\"}', NULL, 'pending', 0, '2025-03-07 07:58:46', '2025-03-08 01:21:27', 'd7770b9b2550db0d8874f35cfda1ef927ccf3753e442472687cf2532aa3e909d', 0),
(10, 1, 'Emir İle Beyza', 'Gece geç vakit, şehrin neon ışıklarının altında parlayan mütevazı bir çorbacı, Emir\'in hayatının dönüm noktası olacağından habersizdi. İçeride, buğusu tüten çorbaların kokusu, yorgun ruhları ısıtırken, Emir de köşedeki masasına kurulmuş, yorgun argın bir şekilde çorbasını yudumluyordu. O an, kapıdan içeri, yüzünde yıldızlar kadar parlak bir gülümsemeyle Beyza girdi.\n\nBeyza, gece vardiyasından çıkmış, karnını doyurmak için çorbacıya uğramıştı. Gözleri, Emir\'in oturduğu köşeye takıldı. O da yorgundu ama gözlerinde bir hüzün vardı. Beyza, yanına yaklaşarak çekinerek sordu: \"Affedersiniz, masa boş mu?\"\n\nEmir, şaşkınlıkla başını kaldırdı. Göz göze geldiler. O an, sanki zaman durdu. Emir, kekeleyerek \"Evet, buyurun,\" diyebildi. Beyza, masaya oturdu. İkisi de bir süre sessizce çorbalarını içtiler. Sonra, Beyza dayanamadı ve Emir\'e \"Bir sorun mu var? Çok üzgün görünüyorsunuz,\" diye sordu.\n\nEmir, o gece hayatının en zor günlerinden birini geçirmişti. İşleri yolunda gitmemiş, hayalleri suya düşmüştü. Beyza\'nın samimiyeti karşısında duygulanarak içini döktü. Beyza, onu sabırla dinledi, teselli etti ve umut aşıladı. O geceden sonra, ikisi de çorbacıya daha sık uğramaya başladı. Her buluşmada birbirlerini daha iyi tanıdılar, birbirlerine destek oldular.\n\nAylar geçti. Emir, Beyza\'ya olan aşkının büyüklüğünü her geçen gün daha iyi anlıyordu. Beyza, onun sadece sevgilisi değil, aynı zamanda en yakın arkadaşı, sırdaşı, hayat arkadaşı olmuştu. Bir yıl sonra, aynı çorbacıda, aynı masada, Emir, Beyza\'ya evlenme teklif etti. Beyza\'nın gözleri mutluluktan doldu. \"Evet!\" dedi, hiç tereddüt etmeden.\n\nO gece, çorbacı, iki gencin aşkının en tatlı şahidi oldu. Onlar, gece çorbacıda tanışan, birbirlerine destek olarak büyüyen ve aşkın en güzel halini yaşayan iki gençti. Emir\'in Beyza\'ya olan aşkı, o gece başlayan ve hiç bitmeyecek bir masalın başlangıcıydı. Aşkları, çorbacıda tüten çorba gibi, daima sıcak ve taze kalacaktı.\n', 'fairytale', 'classic', '[{\"name\":\"Emir\",\"type\":\"Benim ad\\u0131m\"},{\"name\":\"beyza \",\"type\":\"sevgilimin ad\\u0131\"}]', '{\"setting\":\"\\u00e7orbac\\u0131da tan\\u0131\\u015ft\\u0131k \",\"theme\":\"Ona Olan a\\u015fk\\u0131m\\u0131n b\\u00fcy\\u00fckl\\u00fc\\u011f\\u00fc\",\"details\":\"Gece \\u00e7orbac\\u0131da tan\\u0131\\u015ft\\u0131k 1 y\\u0131ld\\u0131r sevgiliyiz onu \\u00e7ok seviyorum \",\"audience\":\"young\",\"length\":\"short\"}', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/audio_1741416239_67cbe72f6648c.mp3', 'pending', 0, '2025-03-07 07:59:06', '2025-03-08 06:44:00', '787198a6c9514585902c8132e12d422a0781750f46497bf09554e61596914936', 0),
(11, 1, 'Emir İle Beyza', 'Gece yarısı, şehrin neon ışıkları altında, Emir\'in yolu yine o meşhur çorbacıya düşmüştü. Soğuktan titreyen ellerini cebine sokmuş, buharı tüten bir kase mercimek çorbasının hayaliyle adımlarını hızlandırmıştı. Çorbacı, gece kuşlarının sığınağı, yalnızların dostuydu. Emir de o yalnızlardan biriydi, ya da öyle zannediyordu.\n\nÇorbacıya girdiğinde, tanıdık yüzler arasında bir siluet dikkatini çekti. Uzun, dalgalı saçları, kocaman, parıldayan gözleriyle bir kız, masanın bir köşesinde tek başına oturuyordu. Emir, o an kalbinin hızlandığını hissetti. Daha önce hiç görmediği bu kız, sanki uzun zamandır aradığı bir parçasıydı.\n\nÇorbasını sipariş ederken göz ucuyla kıza bakmaya devam etti. Kızın gözleri de Emir\'i buldu. Hafif bir tebessüm belirdi dudaklarında. Emir, cesaretini topladı ve yanına yaklaştı.\n\n\"Afedersiniz, rahatsız etmek istemem ama burası çok kalabalık. Eğer sakıncası yoksa yanınıza oturabilir miyim?\"\n\nKız, başını sallayarak nazikçe gülümsedi. \"Tabii ki, buyurun.\"\n\nEmir, karşısına oturduğunda heyecandan eli ayağına dolaşmıştı. Kendini tanıttı. \"Ben Emir.\"\n\n\"Ben de Beyza,\" diye cevapladı kız.\n\nO gece, çorbacıda başlayan sohbet, bir yıl sürecek olan bir aşkın ilk kıvılcımıydı. Emir ve Beyza, o gece sabaha kadar konuştular. Ortak noktaları, hayalleri, umutları... Sanki birbirlerini yıllardır tanıyorlardı.\n\nAradan bir yıl geçti. Emir, Beyza\'ya olan aşkının her geçen gün daha da büyüdüğünü hissediyordu. Beyza, Emir\'in hayatına güneş gibi doğmuş, karanlık günlerini aydınlatmıştı. Onunla gülüyor, onunla ağlıyor, onunla nefes alıyordu.\n\nBir gece, yine o meşhur çorbacıda, Emir, Beyza\'nın elini tuttu. Gözlerinin içine baktı ve kalbinin derinliklerinden gelen bir sesle fısıldadı: \"Beyza, seni ilk gördüğüm andan itibaren hayatım değişti. Sen benim en değerli hazinem, en büyük aşkımsın. Seni sonsuza kadar seveceğim.\"\n\nBeyza\'nın gözleri doldu. Emir\'in elini sımsıkı tuttu ve aynı aşkla karşılık verdi. \"Emir, sen de benim için aynısın. Seni tanıdığım için o kadar mutluyum ki... Seni ben de sonsuza kadar seveceğim.\"\n\nO gece, çorbacı, iki aşığın sonsuz aşkına şahitlik etti. Emir\'in Beyza\'ya olan aşkının büyüklüğü, yıldızlar kadar parlak, denizler kadar derin, sonsuzluk kadar uzundu. Ve bu aşk, bir kase çorba ile başlamış, hayatlarının en güzel hikayesi olmuştu.\n', 'fairytale', 'classic', '[{\"name\":\"Emir\",\"type\":\"Benim ad\\u0131m\"},{\"name\":\"beyza \",\"type\":\"sevgilimin ad\\u0131\"}]', '{\"setting\":\"\\u00e7orbac\\u0131da tan\\u0131\\u015ft\\u0131k \",\"theme\":\"Ona Olan a\\u015fk\\u0131m\\u0131n b\\u00fcy\\u00fckl\\u00fc\\u011f\\u00fc\",\"details\":\"Gece \\u00e7orbac\\u0131da tan\\u0131\\u015ft\\u0131k 1 y\\u0131ld\\u0131r sevgiliyiz onu \\u00e7ok seviyorum \",\"audience\":\"young\",\"length\":\"short\"}', '', 'pending', 0, '2025-03-07 08:10:00', '2025-03-08 06:25:50', '878e1f847a2c2533affdf55b050525875d4240a69e36973c24290d4bbaba6734', 1),
(12, 16, 'İrem ile Yiğit', 'Ortaçağ\'ın tozlu yolları, şatoların gölgesinde uzanan yemyeşil ormanlar ve kalelerin burçlarından yükselen bayrakların altında, Yiğit ve İrem\'in aşkı filizleniyordu. Yiğit, cesur ve güçlü bir aslandı, ancak kalbinde romantizme düşkün bir yanı vardı. İrem ise zarafeti ve güzelliğiyle dillere destan, asil bir dişi aslandı.\n\nİkisi de aynı soydan geliyor, aynı topraklarda büyümüşlerdi. Yiğit, İrem\'i ilk gördüğü andan itibaren ona hayran kalmıştı. İrem\'in gözlerindeki zekayı, yürüyüşündeki asaleti ve kalbindeki şefkati fark etmişti. Ancak İrem, Yiğit\'in ilgisine karşılık vermekte tereddüt ediyordu. Yiğit\'i cesur ve güçlü bulsa da, onun romantik tavırları İrem\'i biraz şaşırtıyordu. Ortaçağ\'ın acımasız dünyasında, romantizm lüks gibiydi. Hayatta kalmak, soylarını devam ettirmek her şeyden önemliydi.\n\nYiğit, İrem\'i etkilemek için her yolu deniyordu. Ona en güzel avları getiriyor, geceleri yıldızların altında serenatlar yapıyordu. İrem, Yiğit\'in bu çabalarına kayıtsız kalamıyordu. Onun kalbinin derinliklerindeki samimiyeti ve aşkı görmeye başlamıştı. Yiğit, sadece güçlü bir savaşçı değil, aynı zamanda şefkatli ve düşünceli bir eş olabilirdi.\n\nGünler geçtikçe İrem\'in kalbi Yiğit\'e doğru daha da kaydı. Bir gün, Yiğit İrem\'i ormanın en yüksek tepesine götürdü. Gün batımının kızıllığı, tüm ormanı altın rengine boyuyordu. Yiğit, diz çöktü ve İrem\'e evlenme teklif etti. \"İrem, benimle hayatını birleştirir misin? Seninle birlikte bu toprakları koruyacak, çocuklarımıza sevgiyle kol kanat gereceğiz.\"\n\nİrem\'in gözleri doldu. Yiğit\'in gözlerindeki aşkı ve samimiyeti görüyordu. Kalbi \"evet\" diye haykırıyordu. \"Evet, Yiğit. Seninle evlenmeyi çok istiyorum.\"\n\nDüğünleri tüm krallıkta yankılandı. Asil aslanlar, şatoların soylu sakinleri ve ormanın tüm canlıları bu mutlu güne şahitlik etti. Yiğit ve İrem, hayatlarını birleştirdiler ve birlikte uzun, mutlu bir hayat sürmeye söz verdiler.\n\nYıllar geçti ve Yiğit ile İrem\'in aşkı hiç solmadı. Birlikte güçlü bir krallık kurdular, topraklarını korudular ve soylarını devam ettirdiler. Onların aşkı, tüm krallıkta bir efsane olarak dilden dile dolaştı. Cesur bir aslanın romantik kalbi ve asil bir dişi aslanın şefkati, Ortaçağ\'ın karanlık günlerinde bile aşkın en parlak şekilde parlayabileceğini gösterdi. Onların aşkı, genç aslanlara örnek oldu ve kalplerinde aşkın tohumlarını yeşertti. Yiğit ve İrem, sadece birbirlerine değil, tüm krallıklarına ilham kaynağı oldular. Onların hikayesi, aşkın her zaman kazanacağına dair bir umut ışığı olarak parlamaya devam etti.\n', 'love', 'third_person', '[{\"name\":\"Yi\\u011fit\",\"type\":\"Romantik bir aslan\"},{\"name\":\"\\u0130rem\",\"type\":\"Di\\u015fi aslan\"}]', '{\"setting\":\"Orta\\u00e7a\\u011f \",\"theme\":\"A\\u015fk\",\"details\":\"Bu aslan \\u00e7iftinin birlikteli\\u011finden bahsetsin\",\"audience\":\"young\",\"length\":\"medium\"}', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/story_67cab793dbd4c.mp3', 'pending', 0, '2025-03-07 09:06:35', '2025-03-07 09:09:51', '2b559706b66a5ffe52efada4ee8990a067c1716ca8016de559294313e3fb9eb3', 1),
(13, 7, 'Yiğite mektup', 'Sevgili Yiğit,\n\nNasıl başlasam bilemiyorum. Çanakkale’den sana yazmak… Tuhaf bir duygu. Burası, dedelerimizin kanlarıyla suladığı topraklar. Her taşında bir hikaye, her rüzgarında bir fısıltı var. Belki de o yüzden, buradayken sevgi bambaşka bir anlam kazanıyor.\n\nDün Seyit Onbaşı Anıtı’nı gezerken, o koskoca top mermisini sırtlayıp ateşe atan adamın gücünü düşündüm. O güç, sadece kaslarından gelmiyordu. O güç, vatan sevgisinden, ailesine duyduğu özlemden, geleceğe dair umudundan geliyordu. O an, sevginin ne kadar büyük bir kuvvet olduğunu bir kez daha anladım.\n\nBurada, Eceabat’ta, denizin kenarında otururken martıların çığlıklarını dinliyorum. Güneş batarken gökyüzü öyle güzel renklerle boyanıyor ki, insanın içi umutla doluyor. Ama bu umut, kolay kazanılmamış bir umut. Bu umut, bedel ödenmiş bir umut.\n\nBiliyor musun Yiğit, buraya gelmeden önce sevginin sadece romantik bir şey olduğunu sanırdım. Aşk, ilgi, şefkat… Elbette bunlar da sevgi ama burası bana sevginin çok daha fazlası olduğunu öğretti. Sevgi, fedakarlık demekmiş. Sevgi, umut demekmiş. Sevgi, vatan demekmiş.\n\nDedem, Çanakkale Savaşı’na katılmış. Onun hikayelerini dinlerken hep gurur duyardım. Ama şimdi, o hikayelerin ne kadar zorlu şartlarda yazıldığını daha iyi anlıyorum. Onlar, sevdikleri için, gelecek nesiller için canlarını feda ettiler.\n\nBuradan sana sevgi dolu bir mektup gönderiyorum. Belki bu mektup sana ulaştığında sen de hayatına yeni bir anlam katarsın. Belki sen de sevdiklerin için, vatanın için, geleceğin için daha çok çabalarsın.\n\nUnutma Yiğit, sevgi her şeyin üstesinden gelir. Yeter ki kalbinde o ateşi hiç söndürme.\n\nKendine iyi bak.\n\nÇanakkale’den sevgilerimle,\n\n(Adın)\n', 'fairytale', 'letter', '\"[{\\\"name\\\":\\\"Yi\\\\u011fit\\\",\\\"type\\\":\\\"Mektubun yaz\\\\u0131ld\\\\u0131\\\\u011f\\\\u0131 ki\\\\u015fi\\\"}]\"', '\"{\\\"setting\\\":\\\"Yi\\\\u011fit\\\",\\\"theme\\\":\\\"Sevgi\\\",\\\"details\\\":\\\"Yi\\\\u011fite \\\\u00e7anakkaladen bir mektup yaz\\\",\\\"audience\\\":\\\"young\\\",\\\"length\\\":\\\"short\\\"}\"', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/story_67cade2457b10.mp3', 'pending', 0, '2025-03-07 11:52:32', '2025-03-07 11:53:27', '6602f61572c9772f0f5011dd9da569deae9c15548550ba3ee7449640110bc896', 1),
(14, 7, 'Yiğite mektup', 'Sevgili Yiğit,\n\nÇanakkale’den yazıyorum sana. Burası, tarihin fısıltılarının deniz kokusuyla karıştığı, insanın içini bir tuhaf eden bir yer. Hani hep derdin ya, “Biraz uzaklaşmak, yeni bir şeyler görmek lazım,” diye, işte tam da o moddayım şu an.\n\nBuraya gelmeden önce, hayatımın biraz karmaşıklaştığını hissediyordum. Sanki her şey birbirine girmiş, neyin önemli olduğunu unutmuştum. Sonra birden aklıma sen geldin. Senin o her şeye pozitif bakışın, her durumda bir umut ışığı bulabilmen... İşte o yüzden bu mektubu sana yazıyorum.\n\nBurada, savaşın izlerini taşıyan toprakları gezerken, insanların birbirleri için neler yapabileceğini, sevginin ne kadar güçlü bir bağ olduğunu daha iyi anladım. Sanki atalarımızın ruhları fısıldıyor, “Birbirinize sahip çıkın, sevmeyi unutmayın,” diye.\n\nBelki biraz garip gelecek ama, burada, senin o kocaman kalbini, insanlara duyduğun sevgiyi daha iyi anladım. Seninle tartıştığımız, anlaşamadığımız zamanlar oldu elbet. Ama ne olursa olsun, biliyorum ki sen hep yanımda oldun, olacaksın.\n\nÇanakkale’nin rüzgarı yüzüme vurdukça, içimdeki karmaşanın dağıldığını hissediyorum. Burası bana, hayatın aslında ne kadar basit ve güzel olduğunu hatırlattı. Ve en önemlisi, sevginin her şeyin üstesinden gelebileceğini.\n\nSana bu mektubu yazarken, içimden bir şey kopup sana doğru uçuyor sanki. Buraya gelmek iyi geldi, Yiğit. Kendime geldim, sana geldim.\n\nEn kısa zamanda görüşmek dileğiyle, kendine iyi bak.\n\nSevgilerimle,\n\nEmir.\n', 'fairytale', 'letter', '\"[{\\\"name\\\":\\\"Yi\\\\u011fit\\\",\\\"type\\\":\\\"Mektubun yaz\\\\u0131ld\\\\u0131\\\\u011f\\\\u0131 ki\\\\u015fi\\\"},{\\\"name\\\":\\\"Emir\\\",\\\"type\\\":\\\"Ben\\\"}]\"', '\"{\\\"setting\\\":\\\"Yi\\\\u011fit\\\",\\\"theme\\\":\\\"Sevgi\\\",\\\"details\\\":\\\"Yi\\\\u011fite \\\\u00e7anakkaladen bir mektup yaz\\\",\\\"audience\\\":\\\"young\\\",\\\"length\\\":\\\"short\\\"}\"', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/story_67cadec34fea1.mp3', 'pending', 0, '2025-03-07 11:55:12', '2025-03-08 03:05:19', '5ab135bf0f32c7a56a81af57f603a8d2416dc8b6c269df3dbe5e3058c5a10f3e', 1),
(15, 20, 'Beyzos ve Emirin Hikayesi', 'Isparta’nın o sıcak yaz günlerinden birinde, hayatımın akışını değiştirecek bir olay yaşayacağımı bilmiyordum. Üniversiteye yeni başlamıştım ve şehir, benim için keşfedilmeyi bekleyen bir labirent gibiydi. Bir arkadaşımın ısrarıyla bir kafede buluşmaya karar verdik. İşte o gün, Emir ile yollarımız kesişti.\n\nEmir, arkadaşımın arkadaşıydı. İlk bakışta beni etkileyen bir şey yoktu. Hatta arabasına bindiğimde içimden “Büyük ihtimalle bir daha görüşmeyiz,” diye geçirdim. O günkü sohbetimiz sıradan, hatta biraz da mesafeliydi. Emir kibar ve nazikti, ama bende herhangi bir kıvılcım uyandırmamıştı.\n\nAncak hayat bazen beklenmedik sürprizlerle doludur. Birkaç gün sonra Emir’den bir mesaj aldım. Kahve içmeye davet ediyordu. İlk başta tereddüt ettim, ama içimdeki merak duygusu ağır bastı. Kabul ettim.\n\nO kahve, hayatımın dönüm noktası oldu. Emir, o gün bana kendinden bahsetti, hayallerini anlattı, içtenlikle güldü. O güne kadar göremediğim bir şey gördüm onda: Samimiyet. Beni etkileyen, peşimden koşması, vazgeçmemesiydi. Her gün aradı, her gün bir bahane bulup beni görmeye geldi. İlk başta anlam veremedim, ama zamanla onun bu ısrarlı çabası kalbimi yumuşattı.\n\nGünler haftaları, haftalar ayları kovaladı. Emir’in sabrı, sevgisi ve içtenliği beni derinden etkiledi. Onunla geçirdiğim her an, içimde büyüyen bir çiçeğe su veriyordu sanki. Isparta’nın o sıcak yaz günleri, yerini sonbaharın renklerine, kışın beyaz örtüsüne ve nihayetinde ilkbaharın yeniden doğuşuna bıraktı. Ve ben, o süreçte Emir’e aşık oldum.\n\nŞimdi, birlikte birinci yılımızı dolduruyoruz. O ilk tanışmamızdaki mesafeli kızdan eser yok. Emir’in sabrı ve sevgisiyle yoğrulmuş, bambaşka bir Beyzoss var karşısında. Isparta, artık sadece bir şehir değil, bizim aşkımızın filizlendiği topraklar. Ve ben, o ilk gün arabasına bindiğimde bir daha görüşmeyeceğimi düşündüğüm o adama, şimdi tüm kalbimle aşığım. Hayatın sürprizlerine ve aşkın mucizesine inanıyorum. Çünkü aşk, bazen en beklenmedik anda, en umulmadık yerde karşımıza çıkabiliyor.\n', 'memory', 'classic', '\"[{\\\"name\\\":\\\"Beyzoss\\\",\\\"type\\\":\\\"Ben(k\\\\u0131z)\\\"},{\\\"name\\\":\\\"Emir\\\",\\\"type\\\":\\\"Erkek arkada\\\\u015f\\\\u0131m\\\"}]\"', '\"{\\\"setting\\\":\\\"Isparta\\\",\\\"theme\\\":\\\"A\\\\u015fk\\\",\\\"details\\\":\\\"\\\\u0130lk tan\\\\u0131\\\\u015fmam\\\\u0131zda arabad\\\\u0131na bindim, birdaha g\\\\u00f6r\\\\u00fc\\\\u015fmem diye d\\\\u00fc\\\\u015f\\\\u00fcnd\\\\u00fcm, emir pe\\\\u015fimden ko\\\\u015ftu vazge\\\\u00e7medi ve sonras\\\\u0131nda a\\\\u015f\\\\u0131k oldum. \\\\u015eu an birlikte birinci y\\\\u0131l\\\\u0131m\\\\u0131z\\\\u0131 doldurduk.\\\",\\\"audience\\\":\\\"young\\\",\\\"length\\\":\\\"short\\\"}\"', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/story_67cb700797cee.mp3', 'pending', 0, '2025-03-07 22:14:32', '2025-03-07 22:15:36', 'a72b781435310763b20ee5ffbb95e26fb4ab050985477922a33937f488f6bd47', 0),
(16, 21, 'AŞK', 'İstanbul’un karmaşası içindeyken, kalbimde bambaşka bir karmaşa yaşıyordum. Veli, hayatımın yarısı, yuvamın direğiydi. Ama Nurten… Ah, Nurten! Onunla her karşılaşmam, içimde bir bahar fırtınası estiriyordu.\n\nVeli’yle ilk tanıştığımızda, lise son sınıftaydık. O, okulun en popüler çocuğu, ben ise sessiz, kitap kurdu bir kız. Bir proje ödevi sayesinde yollarımız kesişti ve o andan itibaren hayatım değişti. Birlikte ders çalıştığımız o saatler, sinemaya gittiğimiz ilk akşam, el ele tutuştuğumuz o ilk an… Hepsi zihnime kazınmıştı. Veli, bana dünyayı sevdirmişti. Evlendik, küçük bir ev aldık, hayatımız sakin ve huzurluydu.\n\nSonra Nurten girdi hayatıma. Bir kitap kafede tanıştık. O da benim gibi edebiyat aşığıydı. Saatlerce kitaplar, yazarlar üzerine konuşuyorduk. Onunla her konuştuğumda, içimde bir şeyler kıpır kıpır oluyordu. Nurten, bana kendimi yeniden keşfetme fırsatı vermişti. Onunla birlikte, unuttuğum hayallerimi hatırladım.\n\nİstanbul’un en güzel manzarasına sahip bir tepede, el ele oturduğumuz o günü hiç unutamam. Güneş batarken, Nurten bana döndü ve gözlerimin içine bakarak “Seni seviyorum,” dedi. O an, hayatımın en zor anıydı. Kalbim ikiye bölünmüştü. Bir tarafında Veli’ye duyduğum minnet ve sevgi, diğer tarafında Nurten’e duyduğum tutku vardı.\n\nVeli’ye ihanet etmek istemiyordum. Ama Nurten’den de vazgeçemiyordum. İçimde büyük bir savaş vardı. Geceleri uyuyamıyor, gündüzleri kendime yabancılaşıyordum. İstanbul’un kalabalığı içinde kaybolmuş gibiydim.\n\nBir gün, Veli bana bir sürpriz yaptı. Beni ilk tanıştığımız o kafeye götürdü. Masamızda, o günkü gibi iki bardak çay ve bir dilim pasta vardı. Veli, gözlerimin içine baktı ve “Seni ne kadar çok sevdiğimi biliyorsun değil mi?” dedi. O an, kararımı verdim.\n\nNurten’e her şeyi anlattım. Gözyaşları içinde beni dinledi. Sonra, sessizce kalktı ve gitti. Ardında, kırık bir kalp ve pişmanlık dolu bir ben bıraktı.\n\nİstanbul, bana aşkın en karmaşık halini yaşatmıştı. Belki de aşk, sadece tek bir kişiye ait olmak değil, kalbinin bir kısmını başkalarına da açabilmekti. Ama bazı seçimler, hayatımızı sonsuza dek değiştirirdi. Ve ben, seçimimi yapmıştım. Veli’yle olan yuvamıza dönmüştüm. Ama kalbimde, Nurten’in de bir parçası hep kalacaktı.\n', 'love', 'first_person', '\"[{\\\"name\\\":\\\"Veli\\\",\\\"type\\\":\\\"E\\\\u015f\\\"},{\\\"name\\\":\\\"Nurten\\\",\\\"type\\\":\\\"Sevgilim\\\"}]\"', '\"{\\\"setting\\\":\\\"\\\\u0130stanbul\\\",\\\"theme\\\":\\\"A\\\\u015fk\\\",\\\"details\\\":\\\"An\\\\u0131lar\\\",\\\"audience\\\":\\\"young\\\",\\\"length\\\":\\\"short\\\"}\"', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/story_67cb81f20fe53.mp3', 'pending', 0, '2025-03-07 23:28:20', '2025-03-07 23:34:18', 'ea705560d65affb0146ffd12069eedcf380046aa88652ef6c173ed9ea0d70d72', 1),
(17, 7, 'test', 'Test', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"test\\\",\\\"type\\\":\\\"test\\\"}]\"', '\"{\\\"setting\\\":\\\"\\\",\\\"theme\\\":\\\"\\\",\\\"details\\\":\\\"\\\",\\\"audience\\\":\\\"children\\\",\\\"length\\\":\\\"short\\\"}\"', NULL, 'pending', 0, '2025-03-08 03:04:38', NULL, '63a0f43698878b571781260c5e62db5c551edceea045fceaa953e36688d528e7', 0),
(18, 7, 'Test2', 'Tamamdır, isteğiniz doğrultusunda bir masal yazıyorum:\n\n**Fkfk\'nin Işığı**\n\nÇok uzaklarda, Teydxyxy adında, yemyeşil vadilerle çevrili bir köy vardı. Bu köyde yaşayan Test adında küçük bir kız, kalbi Fkfk sevgisiyle dolu, meraklı ve cesur bir çocuktu. Teydxyxy\'nin en büyük sorunu, her yıl belirli bir dönemde köyü karanlığa gömen, adına \"Gölge Zamanı\" dedikleri bir olaydı. Güneş günlerce kaybolur, köy halkı korku ve umutsuzluğa kapılırdı.\n\nTest, Gölge Zamanı\'nın nedenini ve çözümünü bulmaya kararlıydı. Köyün yaşlı bilgesi, Test\'e Kfkfkr\'nin efsanesini anlattı. Efsaneye göre, Kfkfkr adında sihirli bir çiçek, Gölge Zamanı\'nı engelleyebilecek kadar parlak bir ışık yayıyordu. Ancak bu çiçek, ulaşılması çok zor olan, Yüksek Dağlar\'ın zirvesinde yetişiyordu.\n\nTest, korkusuna rağmen, Kfkfkr\'yi bulmaya karar verdi. Yanına sadece küçük bir sırt çantası, bir parça ekmek ve en sevdiği oyuncak ayısını aldı. Yüksek Dağlar\'a doğru yola koyuldu. Yolculuk zorluydu. Dik yamaçları tırmandı, derin vadilerden geçti, buz gibi rüzgarlara göğüs gerdi. Ormanda yaşayan türlü türlü hayvanla karşılaştı. Bazıları ona yardım etti, bazıları ise yolunu kesmeye çalıştı.\n\nGünler süren yolculuktan sonra, Test sonunda Yüksek Dağlar\'ın zirvesine ulaştı. Orada, karla kaplı kayalıkların arasında, göz kamaştırıcı bir şekilde parlayan Kfkfkr çiçeğini buldu. Çiçeğin ışığı, etrafı aydınlatıyordu. Test, çiçeği dikkatlice toprağından çıkardı ve köyüne doğru koşmaya başladı.\n\nKöyüne vardığında Gölge Zamanı çoktan başlamıştı. Her yer karanlıktı, insanlar evlerine kapanmış, umutsuz bir şekilde bekliyorlardı. Test, Kfkfkr\'yi köy meydanına dikti. Çiçeğin ışığı, karanlığı bir anda dağıttı. Köy yeniden aydınlandı, insanlar sevinçle dışarı çıktılar.\n\nO günden sonra, Kfkfkr çiçeği her yıl Gölge Zamanı başladığında ışığını yayarak Teydxyxy köyünü karanlıktan kurtardı. Test ise, cesareti ve Fkfk sevgisi sayesinde, köyünün kahramanı oldu. Ve böylece, Teydxyxy halkı, Fkfk\'nin ışığıyla aydınlanmaya devam etti.\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"Test\\\",\\\"type\\\":\\\"Test\\\"}]\"', '\"{\\\"setting\\\":\\\"Teydxyxy\\\",\\\"theme\\\":\\\"Fkfk\\\",\\\"details\\\":\\\"Kfkfkr\\\",\\\"audience\\\":\\\"young\\\",\\\"length\\\":\\\"short\\\"}\"', NULL, 'pending', 0, '2025-03-08 03:37:10', '2025-03-08 20:02:34', 'a364ba70fe56448b8952da972129064ed589c82995eeb01ea956098ffc7798c0', 1),
(19, 1, 'test323', 'Uzak diyarlarda, Test323 adında yemyeşil bir vadide, Test323 isimli sevimli bir köy yaşarmış. Bu köyün en dikkat çekici özelliği, her yıl baharın ilk gününde açan, gökkuşağı renklerindeki Test323 çiçekleriydi. Köy halkı, bu çiçeklerin bereketi getirdiğine ve Test323\'ü koruduğuna inanırdı.\n\nTest323 köyünde yaşayan, yine Test323 adında, meraklı ve cesur bir kız çocuğu vardı. Test323, köyün en yaşlı bilgesi Baykuş Dede\'nin anlattığı efsaneleri dinlemeye bayılırdı. Baykuş Dede, Test323 çiçeklerinin aslında birer dilek çiçeği olduğunu, kalbi temiz olanların bu çiçeklere fısıldadığı dileklerin gerçekleştiğini söylerdi.\n\nBir gün, Test323 çiçeklerinin açma zamanı yaklaştığında, vadide garip bir kuraklık baş gösterdi. Nehirler kurumuş, toprak çatlamış ve Test323 çiçeklerinin tomurcukları solmaya başlamıştı. Köy halkı endişelenmeye başlamıştı.\n\nTest323, bu duruma çok üzülmüştü. Baykuş Dede\'ye danışarak, çiçekleri kurtarmanın bir yolunu aramaya karar verdi. Baykuş Dede, ona uzaklardaki Kristal Dağ\'ın zirvesinde bulunan Gizemli Kaynak\'tan su getirmesi gerektiğini söyledi. Bu suyun, Test323 çiçeklerini canlandırabileceğine inanıyordu.\n\nTest323, hiç tereddüt etmeden yola koyuldu. Uzun ve zorlu bir yolculuk onu bekliyordu. Ormanlardan geçti, tepeleri aştı ve derelerden atladı. Yol boyunca karşılaştığı hayvanlara yardım etti, onlara su ve yiyecek verdi.\n\nSonunda Kristal Dağ\'ın zirvesine ulaştı. Gizemli Kaynak\'tan aldığı suyu, özenle Test323 çiçeklerinin solmuş tomurcuklarına döktü. Bir mucize gerçekleşti! Çiçekler canlandı, gökkuşağı renkleriyle parlamaya başladı ve vadiye yeniden bereket geldi.\n\nTest323, köyüne döndüğünde büyük bir sevinçle karşılandı. Herkes ona teşekkür etti ve cesaretini kutladı. O günden sonra, Test323 çiçeği sadece bereketi değil, aynı zamanda cesareti ve iyiliği de temsil etti. Test323 köyü, sonsuza dek mutlu ve huzurlu yaşadı.\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"test323\\\",\\\"type\\\":\\\"test323\\\"}]\"', '\"{\\\"setting\\\":\\\"test323\\\",\\\"theme\\\":\\\"test323\\\",\\\"details\\\":\\\"test323\\\",\\\"audience\\\":\\\"young\\\",\\\"length\\\":\\\"short\\\"}\"', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/audio_1741417171_67cbead350fce.mp3', 'pending', 0, '2025-03-08 03:46:43', '2025-03-08 06:59:33', '113d467c10500c7d0ea1300d1f84efe3e5b56e07e5be22cae101525c14404287', 1);
INSERT INTO `dh_stories` (`id`, `user_id`, `title`, `content`, `type`, `narrative_style`, `characters`, `metadata`, `audio_path`, `status`, `credits_used`, `created_at`, `updated_at`, `share_token`, `is_public`) VALUES
(20, 1, 'testtbu', 'test deneme bu', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"testtbu\\\",\\\"type\\\":\\\"testtbu\\\"}]\"', '\"{\\\"setting\\\":\\\"testtbu\\\",\\\"theme\\\":\\\"testtbu\\\",\\\"details\\\":\\\"testtbu\\\",\\\"audience\\\":\\\"young\\\",\\\"length\\\":\\\"short\\\"}\"', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/story_67cbf7dc7725a.mp3', 'pending', 0, '2025-03-08 06:51:45', '2025-03-08 07:55:08', '5b8e1ef4713b06f102e9e61c4ef1ae0278c65ccfd9b25402c37ad3e209980ce6', 1),
(21, 1, 'testtbu', 'Gökyüzünün pamuk tarlası gibi bembeyaz bulutlarla süslendiği, güneşin altın rengi ışıklarını cömertçe serptiği bir diyarda, Testtbu adında şirin bir köy vardı. Bu köy, diğerlerinden farklı olarak, her köşesinde neşe ve kahkaha yankılanan, insanların yüzünden gülücüklerin eksik olmadığı bir yerdi. Bunun en büyük sebebi ise, köyün adını taşıyan Testtbu isimli küçük bir kızdı.\n\nTesttbu, minik bedeni ve kocaman yüreğiyle, köydeki herkesin sevgilisiydi. Saçları güneşin ilk ışıkları gibi parıldar, gözleri ise gökyüzünün en parlak yıldızları gibi ışıldardı. Ama onu bu kadar özel kılan sadece güzelliği değil, kalbinin iyiliğiydi. Testtbu, her sabah erkenden kalkar, köydeki yaşlılara yardım eder, hayvanları besler, çocuklarla oyunlar oynardı. Onun dokunduğu her şey güzelleşir, onun olduğu her yer neşeyle dolardı.\n\nBir gün, Testtbu köyün en yaşlı ağacının altında otururken, gökyüzünden bir kuşun kanadından düşen parlak bir tüy buldu. Tüy, gökkuşağının tüm renklerini taşıyordu ve Testtbu onu eline aldığında içinden bir fısıltı duydu: \"Bu tüy, sana sihirli bir güç verecek. Bu güçle, Testtbu köyünü sonsuza dek mutlu edebilirsin.\"\n\nTesttbu, bu sihirli tüyü ne yapacağını düşündü. Kendisi için bir şey istemek yerine, köyü için en iyisini yapmaya karar verdi. Tüyü havaya fırlattı ve tüm kalbiyle diledi: \"Testtbu köyünde hiç kimse üzülmesin, herkes mutlu ve huzurlu yaşasın!\"\n\nO andan itibaren, Testtbu köyünde mucizeler yaşanmaya başladı. Tarlalar daha bereketli oldu, hayvanlar daha sağlıklı, insanlar daha neşeli. Testtbu\'nun kalbinin iyiliği ve sihirli tüyün gücüyle, köy sonsuza dek mutlu ve huzurlu bir yer olarak kaldı. Ve Testtbu, herkesin kalbinde yaşayan, iyilik timsali bir kahraman olarak anıldı.\n\nO günden sonra, Testtbu köyüne yolu düşen herkes, Testtbu\'nun hikayesini dinler ve onun gibi iyi kalpli olmaya çalışırdı. Çünkü biliyorlardı ki, en büyük sihir, iyilik yapmaktan ve başkalarını mutlu etmekten geçiyordu.\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"testtbu\\\",\\\"type\\\":\\\"testtbu\\\"}]\"', '\"{\\\"setting\\\":\\\"testtbu\\\",\\\"theme\\\":\\\"testtbu\\\",\\\"details\\\":\\\"testtbu\\\",\\\"audience\\\":\\\"young\\\",\\\"length\\\":\\\"short\\\"}\"', NULL, 'pending', 0, '2025-03-08 07:14:14', NULL, '95a30ddefc3c72246346bc4125d17fcffdd40d88662c4d3860db2908a3e34c52', 1),
(22, 1, 'dsff', 'sdfsdf', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"dsfsdf\\\",\\\"type\\\":\\\"sdfsd\\\"}]\"', '\"{\\\"setting\\\":\\\"\\\",\\\"theme\\\":\\\"\\\",\\\"details\\\":\\\"\\\",\\\"audience\\\":\\\"children\\\",\\\"length\\\":\\\"short\\\"}\"', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/story_67cd9d1e7bcff.mp3', 'pending', 0, '2025-03-08 07:41:31', '2025-03-09 13:52:31', 'b548cc60e52c5c8638491d67cfdb3f0866bd659ab434b096a8e3d1dc75d798a9', 1),
(23, 16, 'Yiğitin Macera Dolu Hayatı', 'Çölün kavurucu güneşi altında, Yiğit adında genç bir savaşçı, kum tepelerinin üzerinde bir hayalet gibi süzülüyordu. Gözleri, ufukta beliren her hareketi yakalamaya hazırdı. Yiğit, sadece yirmi bahar görmüştü ama savaş meydanlarında geçirdiği zaman, onu yaşıtlarından çok daha olgunlaştırmıştı. Güçlü omuzları, sırtındaki kılıcı taşırken hiç yorulmazdı. Güneşte bronzlaşmış teni, çölün zorlu şartlarına meydan okuyan bir zırh gibiydi.\n\nYiğit’in babası, ona kılıç kullanmayı öğretirken, her vuruşun bir dans olduğunu söylerdi. \"Kılıcınla dans et, Yiğit. Düşmanının hareketlerini hisset ve ona karşı bir melodi yarat,\" derdi. Yiğit, babasının bu sözlerini hiç unutmadı. Savaşırken, kılıcıyla adeta dans eder, düşmanlarını şaşırtan ve alt eden hareketler sergilerdi.\n\nBir zamanlar, Yiğit’in yaşadığı vaha köyü, zalim bir hükümdarın ordusu tarafından kuşatılmıştı. Hükümdar, köyün tüm kaynaklarını ele geçirmek ve halkını köleleştirmek istiyordu. Köyün yaşlıları, çaresizlik içinde ne yapacaklarını bilemezken, Yiğit öne atıldı. \"Köyümüzü savunacağım!\" diye haykırdı.\n\nYiğit, köyün genç savaşçılarını topladı ve onlara taktikler öğretti. Kendi yeteneklerini ve cesaretini onlara aşıladı. Gece çöktüğünde, Yiğit ve savaşçıları, düşman kampına sızdı. Sessizce ilerleyerek, nöbetçileri etkisiz hale getirdiler ve hükümdarın çadırına doğru ilerlediler.\n\nHükümdarın çadırına ulaştıklarında, Yiğit öne çıktı ve kapıyı tekmeleyerek içeri girdi. Hükümdar, yatağında oturmuş, şaşkınlıkla Yiğit’e bakıyordu. \"Sen kimsin?\" diye sordu öfkeyle.\n\n\"Ben, bu köyün bir savaşçısıyım. Seni ve ordunu köyümüzden defetmeye geldim!\" diye cevapladı Yiğit.\n\nHükümdar kahkaha attı. \"Küçük bir savaşçı beni durdurabileceğini mi sanıyorsun?\" dedi alaycı bir şekilde.\n\nYiğit, kılıcını çekti ve hükümdara saldırdı. Kılıçlar çarpıştı, kıvılcımlar saçıldı. Yiğit, hükümdarın saldırılarını ustalıkla savuşturdu ve ona karşı hamleler yaptı. Hükümdar, Yiğit’in yeteneği karşısında şaşkına dönmüştü.\n\nUzun ve çetin bir mücadelenin ardından, Yiğit, hükümdarı yere serdi. Hükümdarın ordusu, liderlerini kaybettiklerini görünce, panik içinde kaçmaya başladı. Yiğit ve savaşçıları, onları köyün sınırlarına kadar kovaladılar.\n\nKöy halkı, Yiğit’i bir kahraman gibi karşıladı. Onu omuzlarına aldılar ve sevinç çığlıkları attılar. Yiğit, köyünü kurtarmış ve halkının özgürlüğünü sağlamıştı.\n\nO günden sonra, Yiğit’in ünü tüm Ortadoğu’ya yayıldı. İnsanlar, onun cesaretini, gücünü ve adalet duygusunu konuşuyordu. Yiğit, bir efsane olmuştu. Ama Yiğit, ünvanlara ve övgülere aldırış etmedi. O, sadece köyünü ve halkını korumak için savaşmaya devam etti. Çünkü Yiğit biliyordu ki, gerçek kahramanlık, başkaları için fedakarlık yapmaktır. Ve Yiğit, bu fedakarlığı yapmaya her zaman hazırdı. Onun hikayesi, genç nesillere cesaret ve umut vermeye devam ediyordu. Çünkü Yiğit, sadece bir savaşçı değil, aynı zamanda bir umut sembolüydü.\n', 'fairytale', 'third_person', '\"[{\\\"name\\\":\\\"Yi\\\\u011fit\\\",\\\"type\\\":\\\"g\\\\u00fc\\\\u00e7l\\\\u00fc ve cesur sava\\\\u015fc\\\\u0131\\\"}]\"', '\"{\\\"setting\\\":\\\"ortado\\\\u011fu\\\",\\\"theme\\\":\\\"macera\\\",\\\"details\\\":\\\"yi\\\\u011fitin g\\\\u00fcc\\\\u00fcn\\\\u00fc ve sava\\\\u015f hayat\\\\u0131n\\\\u0131 anlatan masal\\\",\\\"audience\\\":\\\"young\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/story_67cc131bb4970.mp3', 'pending', 0, '2025-03-08 09:49:14', '2025-03-08 09:51:25', 'b4bde49d5108ef61da6e656aefe7227283765a787a4fc37773c66c920ec78055', 1),
(24, 1, 'test', '**Kaybolan Gül Bahçesi ve Minik Serçe Çiço**\n\nEvvel zaman içinde, uzak diyarlarda, yemyeşil vadilerin ve masmavi gökyüzünün kucaklaştığı bir krallıkta, Gül Bahçesi adında dillere destan bir yer vardı. Bu bahçe, adeta cennetten bir köşeydi. Her renkten güllerin açtığı, bülbüllerin şakıdığı, kelebeklerin dans ettiği bu bahçe, krallığın neşe kaynağıydı. Ancak bir gün, ansızın bir felaket yaşandı. Kötü kalpli bir cadı, kıskançlık nöbetine tutularak, Gül Bahçesi\'ni bir sis perdesiyle örttü. Güller soldu, bülbüller sustu, kelebekler kayboldu. Bahçe, eski neşesini yitirdi ve krallık büyük bir üzüntüye boğuldu.\n\nBu krallıkta yaşayan minik serçe Çiço, diğer serçelerden farklıydı. O, cesur ve meraklı bir serçeydi. Güllerin solduğunu, insanların üzüntüsünü gören Çiço, bu duruma çok üzüldü. \"Gül Bahçesi\'ni eski haline getirmeliyim!\" diye düşündü. Annesi ve babası ona tehlikeli olduğunu, cadının çok güçlü olduğunu söyledilerse de, Çiço kararından dönmedi.\n\nÇiço, kanatlarını çırparak uzun bir yolculuğa çıktı. Ormanları aştı, dağları geçti, denizleri dolandı. Yolculuğu sırasında bilge bir baykuşla karşılaştı. Baykuş, Çiço\'nun niyetini öğrenince ona yardım etmeye karar verdi. \"Cadının zayıf noktası, kalbinin derinliklerinde sakladığı bir korkudur. Bu korkuyu ortaya çıkarırsan, sis perdesi dağılır ve Gül Bahçesi eski haline döner,\" dedi. Baykuş, Çiço\'ya sihirli bir tüy verdi ve \"Bu tüyü cadının uyurken yastığının altına koyarsan, korkusu rüyalarına girecek ve onu zayıflatacaktır,\" diye ekledi.\n\nÇiço, baykuşun sözlerini dinleyerek cadının yaşadığı karanlık kaleye doğru uçtu. Kale, ürkütücü ve kasvetliydi. Çiço, cesaretini topladı ve kaleye gizlice girdi. Cadı, derin bir uykudaydı. Çiço, sihirli tüyü cadının yastığının altına koydu. O anda, cadının rüyalarında korkunç yaratıklar belirmeye başladı. Cadı, ter içinde uyandı ve büyük bir korkuya kapıldı. Kalbi hızla çarpıyordu.\n\nCadı, korkusunun etkisiyle zayıfladı. Sis perdesi yavaş yavaş dağılmaya başladı. Güneş, yeniden Gül Bahçesi\'ne doğdu. Güller yeniden açtı, bülbüller yeniden şakıdı, kelebekler yeniden dans etti. Krallık, yeniden neşeye kavuştu.\n\nÇiço, kahramanlığıyla tüm krallıkta ünlendi. İnsanlar, ona minnettar kaldılar. Çiço, Gül Bahçesi\'nin en güzel gülüne konarak, o günden sonra hep orada yaşadı. Çocuklar, Çiço\'nun cesaretini ve iyiliğini örnek alarak büyüdüler.\n\nBu masal da burada bitti. Unutmayın çocuklar, cesaret ve iyilik her zaman kazanır. Tıpkı minik serçe Çiço gibi, siz de kalbinizdeki iyiliği takip edin ve dünyayı daha güzel bir yer yapmaya çalışın.\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"sdfsd\\\",\\\"type\\\":\\\"sdfsfd\\\"}]\"', '\"{\\\"setting\\\":\\\"sfd\\\",\\\"theme\\\":\\\"dsfsdf\\\",\\\"details\\\":\\\"sdfsdf\\\",\\\"audience\\\":\\\"children\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', NULL, 'pending', 0, '2025-03-09 07:48:07', NULL, 'f2ff3fecb9eea758c2f6cabaf878cafe812fe145c6ff458eaa913b4c72497a2c', 1),
(25, 1, 'asd', '**Altın Kalpli Oduncu ve Kayıp Yıldız Tozu**\n\nÇok uzaklarda, Adsad ülkesinin yemyeşil ormanlarının derinliklerinde, Adsad adında mütevazı bir köy vardı. Bu köyde, kalbi altın kadar saf, ruhu ise bahar meltemi kadar nazik bir oduncu yaşarmış. Adı da Oduncu Ali’ydi (Sadad). Ali, her sabah erkenden kalkar, baltasını omzuna atar ve ormana doğru yol alırdı. Ormanın derinliklerinde, hem köyüne yakacak odun temin eder, hem de ormanın gizemli güzelliklerini seyre dalardı.\n\nAli, diğer oduncular gibi sadece ağaçlara odaklanmazdı. Ormanın her canlısına saygı duyar, kuşların cıvıltısını dinler, sincapların oyunlarını seyrederdi. Hatta, ormanın yaşlı ağaçlarına, onların hikayelerini dinlermiş gibi saygıyla yaklaşırdı. Köydeki diğer oduncular onu bu yüzden biraz garipserlerdi ama Ali, kalbinin sesini dinlemekten asla vazgeçmezdi.\n\nBir gün, Ali ormanda dolaşırken, daha önce hiç görmediği bir şeyle karşılaştı. Yaşlı bir meşe ağacının dibinde, ışıl ışıl parlayan bir toz yığını vardı. Bu toz, sanki gökyüzünden düşmüş gibiydi ve etrafına büyülü bir aura yayıyordu. Ali, bu tozun ne olduğunu merak etti. Eğilip yakından baktığında, tozun içinden minik yıldızlar gibi parıltılar yükseldiğini gördü.\n\nTam o sırada, bir fısıltı duydu. \"Yıldız tozu... Kayboldu...\" Ali, etrafına bakındı ama kimseyi göremedi. Fısıltı tekrar duyuldu: \"Yıldız tozu... Yıldızları parlatır... Kayboldu... Karanlık çökecek...\"\n\nAli, bu fısıltının kimden geldiğini anlamaya çalışırken, tozun kaybolmasıyla yıldızların söneceği fikri onu çok endişelendirdi. Adsad ülkesi, yıldızların ışıltısıyla aydınlanırdı. Yıldızlar sönse, ülke karanlığa gömülecekti. İşte o an, Ali, asdas olan iyiliği ve yardımlaşmayı temsil eden bir görev üstlendiğine karar verdi. Kayıp yıldız tozunu bulmak ve ülkesini karanlıktan kurtarmak zorundaydı.\n\nAli, köyüne döndü ve durumu köyün en yaşlı bilge kişisi olan Ayşe Nine’ye anlattı. Ayşe Nine, Ali’nin anlattıklarını dikkatle dinledikten sonra, “Ali oğlum, bu yıldız tozu çok özel bir şey. Söylentilere göre, yıldızlar gökyüzünden düşerken, en saf kalpli insanların kalbine düşen bir parça yıldız tozundan oluşur. Bu toz, yıldızların ışıltısını korur ve evrene denge sağlar. Eğer bu toz kaybolursa, yıldızlar söner ve karanlık çöker.” dedi.\n\nAyşe Nine, Ali’ye, yıldız tozunu bulmak için dasas olan eski bir harita verdi. Bu harita, Adsad ülkesinin en gizli yerlerini gösteriyordu ve yıldız tozunun nerede olabileceğine dair ipuçları içeriyordu. Ali, haritayı dikkatle inceledi ve hemen yola koyuldu.\n\nYolculuğu boyunca, Ali birçok zorlukla karşılaştı. Ormanın derinliklerinde kayboldu, vahşi hayvanlarla mücadele etti ve sarp dağları aştı. Ama asla pes etmedi. Çünkü kalbinde, ülkesini karanlıktan kurtarma arzusu vardı.\n\nSonunda, haritanın gösterdiği yere ulaştı. Burası, Adsad ülkesinin en yüksek dağı olan Yıldıztepe’ydi. Dağın zirvesinde, küçük bir mağara vardı. Ali, mağaraya girdiğinde, gözlerine inanamadı. Mağaranın içinde, kayıp yıldız tozu, daha da parlak bir şekilde ışıldıyordu.\n\nAli, tozu dikkatlice aldı ve köyüne geri döndü. Yıldız tozunu Ayşe Nine’ye teslim etti. Ayşe Nine, tozu özel bir kaba koydu ve gökyüzüne doğru kaldırdı. O anda, yıldızlar yeniden parlamaya başladı ve Adsad ülkesi, yeniden ışıl ışıl oldu.\n\nAli, o günden sonra, köyünde kahraman olarak anıldı. Ama o, sadece kalbinin sesini dinleyen, iyilik yapmaktan mutluluk duyan mütevazı bir oduncu olarak kaldı. Ve Adsad ülkesi, sonsuza dek yıldızların ışıltısıyla aydınlanmaya devam etti.\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"adsad\\\",\\\"type\\\":\\\"sadad\\\"}]\"', '\"{\\\"setting\\\":\\\"adsad\\\",\\\"theme\\\":\\\"asdas\\\",\\\"details\\\":\\\"dasas\\\",\\\"audience\\\":\\\"young\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', NULL, 'pending', 0, '2025-03-09 13:38:51', NULL, 'ee4d7b9e61d5da7bc8ac6b6170af5a1002f50c5b16815e28a156e031bd315509', 1),
(26, 1, 'asd', '**Unutulmuş Şehir Adsad ve Kayıp Yıldızın Hikayesi**\n\nÇok çok eski zamanlarda, gökyüzünün sonsuz maviliğinin yeryüzüyle kucaklaştığı yerde, Adsad adında kadim bir şehir vardı. Bu şehir, etrafını saran yemyeşil vadiler ve dorukları bulutlara değen heybetli dağlarla çevrili, saklı bir cennetti adeta. Adsad’ın kalbinde, yüzyıllardır hiç sönmeden parlayan, şehrin koruyucu ruhu olduğuna inanılan devasa bir kristal yıldız vardı. Bu yıldız, şehre bolluk, bereket ve neşe getirirdi.\n\nAncak bir gün, kara bir büyücünün laneti Adsad’ın üzerine çöktü. Büyücü, kıskançlığın ve açgözlülüğün karanlık girdabında kaybolmuş, yıldızın ışıltısını çalmak ve şehri sonsuz bir karanlığa mahkum etmek istiyordu. Gece yarısının sessizliğinde, gizlice şehre sızdı ve yıldızı çalmayı başardı. Yıldızın kaybolmasıyla birlikte, Adsad’ın üzerine bir hüzün perdesi indi. Çiçekler soldu, nehirler kurudu ve insanların yüzlerinden gülümseme kayboldu.\n\nŞehrin umudu, genç ve cesur bir kız olan Elara’ya bağlıydı. Elara, babası Adsad’ın en bilge şifacısı olan Sadad’ın kızıydı. Babası ona, yıldızın kaybolmasının şehrin ruhunu nasıl yaraladığını ve onu geri getirmenin tek çare olduğunu anlatmıştı. Elara, babasının sözlerini yüreğine kazıdı ve yıldızı bulmak için uzun ve tehlikeli bir yolculuğa çıkmaya karar verdi.\n\nYolculuğu sırasında Elara, konuşan bir kurt olan Gölge ve gizemli bir orman perisi olan Işık ile karşılaştı. Gölge, Elara’yı tehlikelerden koruyacak cesarete ve güce sahipti. Işık ise, ormanın gizli yollarını ve büyülü sırlarını biliyordu. Birlikte, kara büyücünün izini sürmeye başladılar.\n\nYol boyunca, Elara ve arkadaşları birçok zorlukla karşılaştılar. Karanlık ormanlarda kayboldular, devasa canavarlarla savaştılar ve karmaşık bulmacaları çözmek zorunda kaldılar. Ancak, Elara’nın cesareti, Gölge’nin gücü ve Işık’ın bilgeliği sayesinde, tüm engelleri aşmayı başardılar.\n\nSonunda, kara büyücünün saklandığı karanlık kaleye ulaştılar. Kale, ürkütücü bir atmosfere sahipti ve etrafı keskin dikenli tellerle çevriliydi. Elara ve arkadaşları, kaleye gizlice girmeyi başardılar ve büyücünün taht odasına ulaştılar.\n\nBüyücü, tahtında oturmuş, çaldığı yıldızın ışıltısından güç alıyordu. Elara, büyücüye meydan okudu ve yıldızı geri vermesini istedi. Büyücü, kahkahalarla karşılık verdi ve Elara’ya saldırdı. Uzun ve zorlu bir mücadele başladı. Elara, Gölge ve Işık, büyücünün karanlık büyülerine karşı koymak için tüm güçlerini kullandılar.\n\nSonunda, Elara, babasından öğrendiği bir şifalı büyüyü kullanarak büyücünün gücünü zayıflatmayı başardı. Büyücü sersemlediğinde, Elara yıldızı kaptı ve hızla oradan uzaklaştı.\n\nYıldızı Adsad’a geri getirdiğinde, şehir yeniden canlandı. Çiçekler yeniden açtı, nehirler yeniden aktı ve insanların yüzlerine yeniden gülümseme geldi. Adsad, yeniden bolluk, bereket ve neşe dolu bir şehir oldu.\n\nElara, şehrin kahramanı ilan edildi ve Adsad’ın koruyucusu olarak onurlandırıldı. Elara, Gölge ve Işık ile birlikte, Adsad’ı ve çevresini her türlü tehlikeye karşı korumaya devam etti. Ve böylece, Adsad’ın unutulmuş hikayesi, nesilden nesile aktarılarak, genç kalplerde cesaretin, dostluğun ve iyiliğin tohumlarını yeşertmeye devam etti. Dasas olarak bilinen bu olaylar, Adsad\'ın tarihinde unutulmaz bir yer edindi.\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"adsad\\\",\\\"type\\\":\\\"sadad\\\"}]\"', '\"{\\\"setting\\\":\\\"adsad\\\",\\\"theme\\\":\\\"asdas\\\",\\\"details\\\":\\\"dasas\\\",\\\"audience\\\":\\\"young\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', NULL, 'pending', 0, '2025-03-09 13:39:03', NULL, '61e6f2066625892a2039bec4b7563409609ad9419fe86e84bd238519e39542b8', 1),
(27, 1, 'zxcsc', 'Eski zamanlarda, Cxvx adlı uzak bir diyarda, her şeyin büyülü ve gizemli olduğu bir dönemde, genç kalplerde umut ve cesaretin yeşerdiği bir hikaye başlar. Bu topraklarda, Xcvxcvc, yani hayatın gerçek anlamını keşfetme arayışı, insanların kalplerinde yanan sönmez bir ateşti.\n\nCxvcxv adında genç bir kız vardı. Gözleri gökyüzü kadar berrak, kalbi ise bir bahar sabahı kadar taze olan bu kız, Xcvxcv adlı küçük bir köyde yaşıyordu. Cxvcxv, diğer çocuklardan farklıydı. Onun içinde, dünyayı keşfetme, bilinmeyeni öğrenme ve hayatın sırlarını çözme arzusu vardı. Köyün en yaşlı bilge kişisi, ona her zaman \"Kalbinin sesini dinle Cxvcxv, o seni doğru yola götürecektir,\" derdi.\n\nGünlerden bir gün, köy meydanında bir xxcvxcv belirdi. Bu, daha önce kimsenin görmediği, parıldayan taşlarla süslü, gizemli bir sandıktı. Köylüler merakla sandığın etrafında toplandılar. Sandığın üzerinde, eski bir dilde yazılmış bir not vardı: \"Bu sandık, sadece saf bir kalbe sahip olan tarafından açılabilir ve içindeki sır, Xcvxcvc\'ye giden yolu gösterecektir.\"\n\nBirçok kişi sandığı açmayı denedi ama nafile. Güçlü savaşçılar, zeki bilginler, hatta köyün en zengin tüccarı bile başarısız olmuştu. Sonunda, Cxvcxv, kalbi heyecanla çarparak sandığa yaklaştı. Derin bir nefes aldı ve ellerini sandığın üzerine koydu. O anda, sandık kendiliğinden açıldı ve içinden parlak bir ışık yükseldi.\n\nIşığın içinde, küçük bir tohum vardı. Bu tohum, \"Umut Tohumu\" olarak biliniyordu ve efsaneye göre, onu eken kişi, Xcvxcvc\'nin gerçek anlamını anlayacaktı. Cxvcxv, Umut Tohumu\'nu aldı ve köyün dışındaki en yüksek tepeye tırmandı. Orada, güneşin ilk ışıklarının vurduğu bir yere tohumu ekti.\n\nGünler geçti, haftalar geçti. Cxvcxv, her gün tohumu suladı, ona şarkılar söyledi ve ona umutla baktı. Bir gün, tohum çatladı ve küçük bir filiz belirdi. Filiz, günden güne büyüdü ve sonunda, daha önce hiç görülmemiş güzellikte bir ağaca dönüştü. Ağacın dallarında, parlak meyveler vardı ve bu meyveler, Xcvxcvc\'nin farklı yönlerini temsil ediyordu: Sevgi, Cesaret, Merhamet, Bilgelik ve Hoşgörü.\n\nCxvcxv, ağacın meyvelerinden birini yedi ve o anda, kalbi bir anda aydınlandı. Xcvxcvc\'nin sadece bir hedef değil, aynı zamanda bir yolculuk olduğunu anladı. Hayatın gerçek anlamı, sevdiklerimize değer vermek, zorlukların üstesinden gelmek, başkalarına yardım etmek, öğrenmekten asla vazgeçmemek ve farklılıklara saygı duymaktı.\n\nCxvcxv, köyüne geri döndü ve ağacın meyvelerinden herkese dağıttı. Köylüler de meyveleri yiyince, Xcvxcvc\'nin anlamını anladılar ve hayatlarını daha iyi bir şekilde yaşamaya başladılar. Cxvx diyarı, o günden sonra, Xcvxcvc\'nin ışığıyla aydınlandı ve insanlar, her zaman kalplerindeki umudu takip ederek, hayatın gerçek anlamını aramaya devam ettiler.\n\nVe böylece, Cxvcxv\'nin hikayesi, genç kalplere umut ve cesaret aşılamaya devam etti. Unutmayın çocuklar, Xcvxcvc\'yi bulmak için uzaklara gitmenize gerek yok. O, kalbinizin derinliklerinde saklıdır. Sadece ona kulak verin ve onu keşfetmek için cesur olun.\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"cxvcxv\\\",\\\"type\\\":\\\"xcvcxv\\\"}]\"', '\"{\\\"setting\\\":\\\"cxvx\\\",\\\"theme\\\":\\\"xcvxcvc\\\",\\\"details\\\":\\\"xxcvxcv\\\",\\\"audience\\\":\\\"young\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', NULL, 'pending', 0, '2025-03-09 14:01:18', NULL, '8a9691127d1930cf9b666c61bedc199309a7747cc48cfda02ac7a7c146641313', 1),
(28, 1, 'x', 'Bir zamanlar, uzak diyarlarda, masalsı güzellikteki Xcvcx Krallığı\'nda, kalpleri sevgi ve neşeyle dolu insanlar yaşarmış. Bu krallığın en belirgin özelliği, her mevsimde açan, gökkuşağının tüm renklerini barındıran eşsiz çiçek bahçeleriydi. Bu çiçekler, sadece güzellikleriyle değil, yaydıkları huzur ve mutlulukla da Xcvcx\'in en değerli hazinesiydi. Hikayemizin ana teması, **Vxcvcx**, yani \"Gönül Bağı\"dır. Bu, Xcvcx halkının birbirine duyduğu derin sevgi, saygı ve dayanışmayı simgeler.\n\nHikayemizin kahramanları ise, Krallığın en sevilen sakinleri olan Cxv ailesidir. Anne Çiçek, babası Orman ve minik kızları Güneş\'ten oluşan bu aile, doğayla iç içe, sade ve mutlu bir hayat sürerdi. Anne Çiçek, adından da anlaşılacağı gibi, krallığın en güzel çiçeklerini yetiştiren yetenekli bir bahçıvandı. Babası Orman ise, bilgeliği ve sakinliğiyle tanınan, krallığın en eski ormanında yaşayan hayvanlarla dostluğuyla bilinen bir ormancıydı. Minik Güneş ise, adeta bir enerji demeti gibi, her yere neşe saçan, meraklı ve sevimli bir çocuktu.\n\nVxcv, yani Gönül Bağı, Cxv ailesinin hayatında da önemli bir yer tutardı. Anne Çiçek, çiçeklerini yetiştirirken onlara sevgiyle dokunur, onlarla konuşurdu. Babası Orman, ormanda yaşayan hayvanlara yardım eder, onların ihtiyaçlarını karşılardı. Minik Güneş ise, herkese gülümser, onlara sevgiyle yaklaşırdı.\n\nBir gün, Xcvcx Krallığı\'nın üzerine kara bulutlar çöktü. Krallığın en değerli çiçek bahçeleri, aniden solmaya başladı. Çiçeklerin yaprakları sarardı, renkleri soldu ve güzellikleri kayboldu. Bu durum, Xcvcx halkını derinden üzdü. Çünkü çiçeklerin solması, sadece güzelliğin kaybı değil, aynı zamanda Gönül Bağı\'nın da zayıflaması anlamına geliyordu.\n\nAnne Çiçek, çiçeklerin neden solduğunu anlamak için günlerce bahçede dolaştı. Babası Orman, ormanda yaşayan hayvanlara danıştı. Minik Güneş ise, her gün çiçeklere su verdi, onlara şarkılar söyledi. Ancak, tüm çabalara rağmen, çiçeklerin solmasına bir çare bulamadılar.\n\nSonunda, yaşlı bir bilge, Cxv ailesine bir ipucu verdi. Bilge, \"Çiçeklerin solmasının nedeni, kalplerdeki sevginin azalmasıdır. Gönül Bağı zayıfladığında, çiçekler de solar. Çiçekleri yeniden canlandırmak için, kalplerdeki sevgiyi yeniden alevlendirmeniz gerekir\" dedi.\n\nCxv ailesi, bilgenin sözlerini dikkatle dinledi. Anne Çiçek, en güzel çiçeklerinden bir demet hazırladı ve krallığın meydanına gitti. Orada, tüm halkı topladı ve onlara çiçeklerin anlamını anlattı. Babası Orman, ormanda yaşayan hayvanları da yanına alarak, halka dayanışmanın önemini vurguladı. Minik Güneş ise, tüm çocuklara gülümsedi ve onlara sevgi dolu sözler söyledi.\n\nCxv ailesinin bu çabaları, Xcvcx halkının kalplerini ısıttı. İnsanlar, birbirlerine yeniden sevgiyle bakmaya başladı. Komşular, birbirlerine yardım etti. Dostlar, birbirlerine destek oldu. Ve en önemlisi, herkes, Gönül Bağı\'nın ne kadar değerli olduğunu anladı.\n\nKalplerdeki sevgi yeniden alevlenince, çiçekler de yeniden canlanmaya başladı. Yapraklar yeniden yeşerdi, renkler yeniden parladı ve güzellikleri geri geldi. Xcvcx Krallığı, yeniden neşe ve mutlulukla doldu.\n\nBöylece, Cxv ailesi sayesinde, Xcvcx halkı, Gönül Bağı\'nın ne kadar önemli olduğunu bir kez daha anlamış oldu. Ve o günden sonra, Xcvcx Krallığı\'nda, sevgi, saygı ve dayanışma hiç eksik olmadı. Çünkü onlar biliyorlardı ki, Gönül Bağı ne kadar güçlüyse, hayat da o kadar güzeldi.\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"cxv\\\",\\\"type\\\":\\\"xcvcx\\\"}]\"', '\"{\\\"setting\\\":\\\"xcvcx\\\",\\\"theme\\\":\\\"vxcvcx\\\",\\\"details\\\":\\\"vxcv\\\",\\\"audience\\\":\\\"children\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', NULL, 'pending', 0, '2025-03-09 14:06:51', NULL, 'ef334ce3b6f16fbb9ab4e1735719f31817458768a5ca9633204fae06f299380c', 1),
(29, 1, 'sdfs', '**Zehirli Fısıltılar Vadisi\'nin Laneti**\n\nEfsaneler, sonsuz kum denizinin ardında, ıssız ve unutulmuş bir diyar olan Sdfds\'den bahsederdi. Burası, bir zamanlar bereketli ve zengin bir vaha iken, şimdi sadece kırık taşların, kemiklerin ve zehirli rüzgarların uğultusunun duyulduğu lanetli bir topraktı. Hikayeler, burayı terk etmeyenlerin akıbetinin korkunç olduğunu fısıldardı; deliliğin pençesine düşmek, ruhlarını kaybetmek ya da daha da kötüsü…\n\nSdf (Sdfsdfs), genç ve hırslı bir arkeologdu. Sdfds\'nin lanetine inanmıyor, aksine, buranın geçmişine dair önemli sırlar barındırdığına inanıyordu. Diğer bilim adamlarının aksine, Sdf, efsanelerin ardındaki gerçeği ortaya çıkarmaya kararlıydı. Yanına, cesur ve yetenekli bir rehber olan Leyla’yı aldı. Leyla, çölün dilini bilen, yıldızları okuyabilen ve kumun fısıltılarını anlayan bir kadındı.\n\nSdf ve Leyla, Sdfds\'ye doğru tehlikeli bir yolculuğa çıktılar. Günler süren zorlu yolculuğun ardından, nihayet lanetli vadiye ulaştılar. Gördükleri manzara, tüyler ürperticiydi. Bir zamanlar görkemli bir şehir olan Sdfds, şimdi rüzgarın savurduğu kum tepelerinin altında, hayalet bir siluet gibi duruyordu. Yıkık tapınaklar, kırık sütunlar ve insan kemikleri her yere saçılmıştı.\n\nİlk keşifleri sırasında, Sdf ve Leyla, gizli bir yeraltı mezarına rastladılar. Mezarda, karmaşık oymalarla süslenmiş bir lahit bulunuyordu. Lahdi açtıklarında, içinden bir kadının mumyalanmış cesedi çıktı. Kadının boynunda, yılan şeklinde bir kolye vardı. Sdf, kolyeyi incelemeye başladı. Kolye, garip bir şekilde ısınıyordu.\n\nO gece, Sdf garip rüyalar görmeye başladı. Rüyalarında, kadim tanrıların fısıltılarını duyuyordu. Tanrılar, Sdf\'ye, Sdfds\'nin lanetinin sırrını fısıldıyorlardı. Lanet, açgözlülük ve ihanet sonucu ortaya çıkmıştı. Sdfds\'nin halkı, tanrıların gazabına uğramış ve lanetlenmişti.\n\nSdf, uykusundan ter içinde uyandı. Rüyalarının gerçek olup olmadığını merak ediyordu. Leyla\'ya rüyalarını anlattı. Leyla, Sdf\'nin rüyalarının, Sdfds\'nin lanetinin bir parçası olabileceğini söyledi. Leyla, Sdf\'yi uyardı. Sdf, kolyeyi bırakmalıydı. Kolye, lanetin kaynağıydı.\n\nSdf, Leyla\'yı dinlemedi. Kolye, Sdf\'yi büyülemişti. Sdf, kolyenin gücünü keşfetmek istiyordu. Günler geçtikçe, Sdf daha da tuhaflaşmaya başladı. Gözleri kararıyor, davranışları değişiyordu. Sdf, Leyla\'ya karşı öfke duymaya başlamıştı.\n\nBir gün, Sdf, Leyla\'ya saldırdı. Leyla, kendini savunmak zorunda kaldı. Mücadele sırasında, kolye Sdf\'nin elinden düştü. Leyla, kolyeyi aldı ve ateşe attı. Kolye, alevler içinde eridi.\n\nKolye eridiğinde, Sdf\'nin üzerindeki büyü bozuldu. Sdf, Leyla\'ya yaptıklarından dolayı pişmanlık duydu. Sdf ve Leyla, Sdfds\'den ayrılmaya karar verdiler. Lanetli vadide daha fazla kalmak istemiyorlardı.\n\nSdf ve Leyla, Sdfds\'den ayrıldılar. Geriye, sadece kumun fısıltıları ve lanetli vadinin laneti kaldı. Sdf, Sdfds\'de yaşadıklarından sonra, artık efsanelere inanıyordu. Bazı sırlar, keşfedilmemeliydi.\n\n(Sdfs), bu hikayede, insan hırsının ve açgözlülüğünün yıkıcı sonuçlarını temsil ediyor. Sdf, bilime olan tutkusuyla, lanetli bir diyarın sırlarını açığa çıkarmaya çalışırken, kendi ruhunu tehlikeye atıyor. Leyla ise, doğanın ve kadim bilgeliğin sembolü olarak, Sdf\'yi karanlıktan kurtarmaya çalışıyor. Hikaye, yetişkin okuyuculara, hırsın ve açgözlülüğün tehlikeleri hakkında bir uyarı niteliği taşıyor. Sdfs, aynı zamanda, geçmişin sırlarının, bazen en iyi şekilde unutulmuş olarak kalması gerektiğini vurguluyor.\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"sdf\\\",\\\"type\\\":\\\"sdfsdfs\\\"}]\"', '\"{\\\"setting\\\":\\\"sdfds\\\",\\\"theme\\\":\\\"sdfdsf\\\",\\\"details\\\":\\\"sdfs\\\",\\\"audience\\\":\\\"adult\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', NULL, 'pending', 0, '2025-03-09 14:07:57', NULL, 'c760a5be5387a90840f27f84ef65c5b706e81db3c257c6e8dca123e93c7be259', 1),
(30, 1, 'sdfs', 'Elbette, işte istediğin özelliklere uygun bir masal:\n\n**Kara Orman\'ın Fısıltısı**\n\nÇok çok eski zamanlarda, adının \"Sefahat Diyarı\" anlamına gelen \"Sdfds\" adlı bir ülke vardı. Bu ülke, göz alabildiğine uzanan üzüm bağları, her mevsim meyve veren ağaçları ve şaraptan akan nehirleriyle dillere destandı. Ancak Sdfds\'nin bu debdebeli hayatının ardında, Kara Orman\'ın derinliklerinde gizlenen bir lanet vardı. Bu lanetin teması, \"aşırıya kaçmanın bedeli\" idi.\n\nSdfds\'nin yöneticisi Kral Oberon, güzelliği dillere destan Kraliçe Titania ile evliydi. Ancak Kral Oberon\'un kalbi, ülkesinin zenginliği ve Kraliçe Titania\'nın güzelliğiyle yetinmiyordu. Her gün daha fazlasını istiyor, daha büyük ziyafetler düzenliyor, daha pahalı şaraplar içiyor ve halkını daha çok çalıştırıyordu. Halk, Kral Oberon\'un bu doyumsuzluğundan bıkmış usanmıştı ama seslerini çıkaramıyorlardı. Çünkü Kral Oberon\'un acımasızlığı, ülkenin refahı kadar meşhurdu.\n\nKara Orman\'da yaşayan yaşlı bir bilge olan Eldrin (sdfsdfs), Kral Oberon\'un bu sefahat düşkünlüğünün ülkeyi felakete sürükleyeceğini biliyordu. Eldrin, ormanın derinliklerinde, kadim bilgilerle dolu bir kulübede yaşardı. Yüzü kırışıklıklarla dolu, gözleri ise yıldızlar gibi parlıyordu. Eldrin, Kral Oberon\'u uyarmaya karar verdi.\n\nBir gün, Eldrin elinde asasıyla saraya geldi. Kral Oberon, şölen sofrasında keyifle şarap yudumlarken Eldrin\'i huzuruna kabul etti. Eldrin, Kral Oberon\'a \"Ey Kral, bu sefahat düşkünlüğün ülkeyi felakete sürükleyecek. Aşırıya kaçmanın bedeli ağırdır. Kara Orman\'ın fısıltılarını dinle, yoksa çok geç olacak!\" dedi.\n\nKral Oberon, Eldrin\'in sözlerine kahkahalarla karşılık verdi. \"Sen kimsin ki bana akıl veriyorsun? Git kendi ormanında fısıltılarını dinle!\" diyerek Eldrin\'i sarayından kovdu.\n\nEldrin, üzgün bir şekilde Kara Orman\'a geri döndü. Kral Oberon ise sefahat hayatına kaldığı yerden devam etti. Günler günleri kovaladı ve Kral Oberon\'un sefahat düşkünlüğü giderek arttı. Halk, açlık ve sefalet içinde kıvranırken Kral Oberon, sarayında lüks içinde yaşıyordu.\n\nBir gece, Kara Orman\'dan uğursuz bir fısıltı yükseldi. Fısıltı, Sdfds\'nin üzerine kara bir bulut gibi çöktü. O gece, ülkenin şarap nehirleri kurudu, üzüm bağları soldu ve meyve ağaçları yapraklarını döktü. Sdfds, bir anda çorak bir toprağa dönüştü.\n\nKral Oberon, bu felaketin ardından Eldrin\'i aradı. Eldrin\'i bulduğunda, dizlerinin üzerine çökerek af diledi. Eldrin, Kral Oberon\'a \"Aşırıya kaçmanın bedeli budur. Sefahat düşkünlüğün, ülkeni felakete sürükledi. Şimdi, halkının refahı için çalışmak ve bu laneti kaldırmak zorundasın\" dedi.\n\nKral Oberon, Eldrin\'in sözlerini dinledi ve halkının refahı için çalışmaya başladı. Yıllar süren çabaların ardından, Sdfds yeniden yeşermeye başladı. Şarap nehirleri yeniden aktı, üzüm bağları yeniden canlandı ve meyve ağaçları yeniden meyve verdi. Kral Oberon, sefahat düşkünlüğünden ders çıkarmış ve ülkesini yeniden refaha kavuşturmuştu. Ancak Sdfds, Kara Orman\'ın fısıltısını asla unutmadı. Çünkü aşırıya kaçmanın bedeli, her zaman bir yerlerde gizliydi.\n\n**Özel Detaylar:** Hikaye, Kral Oberon\'un Kraliçe Titania\'yı ihmal etmesi, ziyafetlerdeki aşırılıklar ve halkın çektiği acılar gibi detaylarla zenginleştirilebilir. Ayrıca, Eldrin\'in kulübesindeki kadim bilgiler ve Kara Orman\'ın uğursuz atmosferi de hikayeye derinlik katabilir.\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"sdf\\\",\\\"type\\\":\\\"sdfsdfs\\\"}]\"', '\"{\\\"setting\\\":\\\"sdfds\\\",\\\"theme\\\":\\\"sdfdsf\\\",\\\"details\\\":\\\"sdfs\\\",\\\"audience\\\":\\\"adult\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', NULL, 'pending', 0, '2025-03-09 14:08:16', NULL, 'd23fbd8bc8ab466cb206d75e57d1a999055ab2b465e1d61e60ac8464795dc5c6', 1),
(31, 1, 'asd', '**Karanlık Ormanın Kalbinde Bir Fısıltı**\n\nÇok uzak diyarlarda, gökyüzünün griye çaldığı, güneşin yüzünü nadiren gösterdiği bir memleket vardı: Asd. Burası, kadim ormanların derinliklerine saklanmış, gizem ve karanlığın hüküm sürdüğü bir yerdi. İnsanlar, hayatlarını toprağı işleyerek, avlanarak ve birbirlerine tutunarak geçirirlerdi. Ancak Asd\'nin üzerinde, amansız bir lanet asılıydı: Umutsuzluğun ve çaresizliğin pençesinde kıvranmak. Temel tema, bu amansız umutsuzluk ve bunun insan ruhu üzerindeki yıkıcı etkileriydi.\n\nAsd\'nin kalbinde, küçük bir köyde, Asdsa adında genç bir kadın yaşardı. Gözleri, gecenin en karanlık anında bile parlayan bir yıldız gibiydi. Kalbi ise, köyünün üzerinde çöken karanlığa rağmen, umutla doluydu. Asdsa, köyün bilge kadını Dasda\'nın torunuydu. Dasda, hayatını köyüne adamış, şifalı otları bilen, yıldızları okuyan ve kaderin fısıltılarını duyan bir kadındı. Ancak yaşlılık, Dasda\'nın bedenini yormuş, onu yatağa düşürmüştü.\n\nDasda, Asdsa\'yı yanına çağırdı. \"Kızım,\" dedi titrek bir sesle, \"Asd\'nin üzerine çöken bu lanet, uzun zamandır ruhumuzu kemiriyor. Umutsuzluk, toprağımızı kurutuyor, kalplerimizi karartıyor. Bu laneti kırmak için, Karanlık Orman\'ın derinliklerine inmen gerekiyor.\"\n\nAsdsa, büyükannesinin sözlerini dikkatle dinledi. Karanlık Orman, adını bile duymanın insanı titrettiği, efsanelere konu olan bir yerdi. Ormanın derinliklerinde, kadim kötülüklerin uyuduğuna, yoldan çıkanların ruhlarını ele geçirdiğine inanılırdı.\n\n\"Ama büyük anne,\" dedi Asdsa, \"Karanlık Orman\'a giden hiç kimse geri dönmedi.\"\n\nDasda, Asdsa\'nın elini sımsıkı tuttu. \"Kızım, Asd\'nin kaderi senin ellerinde. Karanlık Orman\'da, Gümüş Çiçek adında bir bitki var. Bu çiçeğin yaprakları, laneti kıracak güce sahip. Ancak bu çiçeği bulmak için, kendi korkularını yenmen, karanlığın fısıltılarına karşı koyman gerekecek.\"\n\nAsdsa, büyükannesinin sözleri üzerine, karanlık ormanın derinliklerine doğru bir yolculuğa çıkmaya karar verdi. Yanına, büyükannesinin verdiği kadim bir bıçağı ve bir parça kuru ekmeği aldı. Karanlık Orman\'a adım attığı anda, üzerine bir ağırlık çöktü. Ağaçlar, devasa pençeler gibi uzanıyor, gökyüzünü kapatıyordu. Ormanın içinde, tuhaf sesler yankılanıyordu: Kısık fısıltılar, ürkütücü kahkahalar ve acı dolu iniltiler.\n\nAsdsa, günlerce ormanın içinde yol aldı. Yorgunluktan bitap düşmüş, açlıktan halsiz kalmıştı. Ancak büyükannesinin sözleri, ona güç veriyordu. Bir gün, ormanın derinliklerinde, küçük bir açıklık buldu. Açıklığın ortasında, gümüş rengi yaprakları olan bir bitki parlıyordu: Gümüş Çiçek.\n\nAsdsa, çiçeğe doğru yaklaştı. Ancak tam o sırada, gölgelerin içinden bir figür belirdi. Figür, karanlık ve ürkütücüydü. Gözleri, kor alevleri gibi yanıyordu.\n\n\"Bu çiçeği almaya mı geldin?\" dedi figür, boğuk bir sesle. \"Bu çiçek, umutsuzluğun çiçeğidir. Onu alırsan, Asd sonsuza kadar karanlıkta kalacak.\"\n\nAsdsa, korkuyla titredi. Ancak kalbinin derinliklerinde, bir umut kıvılcımı parladı. \"Hayır,\" dedi Asdsa, kararlı bir sesle. \"Bu çiçek, umudun çiçeğidir. Ben, Asd\'nin karanlığını aydınlatmaya geldim.\"\n\nAsdsa, kadim bıçağını çekti ve figüre saldırdı. Uzun ve zorlu bir mücadele başladı. Asdsa, korkularıyla yüzleşti, karanlığın fısıltılarına karşı koydu. Sonunda, figürü yenmeyi başardı.\n\nGümüş Çiçeği alarak köyüne geri döndü. Çiçeğin yapraklarını, köyün meydanında yaktı. O anda, Asd\'nin üzerinde çöken karanlık dağılmaya başladı. Güneş, uzun bir aradan sonra ilk kez yüzünü gösterdi. İnsanların kalpleri umutla doldu.\n\nAsdsa, köyünün kahramanı olmuştu. Ancak o, sadece görevini yapmıştı. Asd\'nin umudu, kendi kalbinde saklıydı. Ve o, bu umudu, karanlığa karşı korumuştu.\n\n**Özel Detaylar:** Dasdad, köydeki insanların birbirlerine olan bağlılığı ve doğayla olan derin ilişkileri, umutsuzluğa karşı direnmelerinde önemli bir rol oynar.\n\n**Hedef Kitle:** Yetişkinler. Hikaye, umutsuzluk, umut, cesaret ve fedakarlık gibi temaları ele alarak, yetişkin okuyucuların düşündürmesi ve duygusal bir bağ kurması hedeflenmektedir.\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"asdsa\\\",\\\"type\\\":\\\"dasda\\\"}]\"', '\"{\\\"setting\\\":\\\"asd\\\",\\\"theme\\\":\\\"asdasdas\\\",\\\"details\\\":\\\"dasdad\\\",\\\"audience\\\":\\\"adult\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', NULL, 'pending', 0, '2025-03-09 14:13:47', NULL, 'e89d89e03842c15f6f0e1cc3caa78e02a6c8058cdc74fda25a3523f2a66f9ef1', 1),
(32, 1, 'asdasd', '**Gökkuşağı Köyü\'nün Kayıp Neşesi**\n\nBir zamanlar, uzak diyarlarda, yemyeşil vadilerin ve şırıl şırıl akan derelerin süslediği Gökkuşağı Köyü adında şirin bir yer vardı. Bu köyde her şey rengârenkti; evlerin çatısı kırmızı, duvarları mavi, bahçelerdeki çiçekler ise gökkuşağının tüm renklerini taşırdı. Köyün sakinleri, sevimli mi sevimli tavşanlar, sincaplar ve kirpilerden oluşan neşeli bir topluluktu. Onların en büyük eğlencesi, bahar geldiğinde düzenlenen Gökkuşağı Festivali\'ydi. Bu festivalde, köyün en yaşlı ve bilge tavşanı Bay Uzunkulak, çocuklara masallar anlatır, hep birlikte şarkılar söylenir ve dans edilirdi.\n\nAncak bu yıl, Gökkuşağı Köyü\'nde bir şeyler ters gitmişti. Köyün neşesi, sanki sihirli bir değnek değmiş gibi kaybolmuştu. Tavşanlar artık zıplamıyor, sincaplar fındıklarını paylaşmıyor ve kirpiler dikenlerini saklamadan somurtuyorlardı. Gökkuşağı Festivali\'ne günler kalmış olmasına rağmen, köyde hazırlık namına hiçbir şey yapılmıyordu. Herkesin yüzünde bir hüzün, kalbinde bir ağırlık vardı.\n\nBu durumdan en çok etkilenen, küçük ve meraklı bir tavşan olan Zıpzıp\'tı (adasds). Zıpzıp, her zamanki gibi neşeli ve enerjik olmasına rağmen, köydeki bu garip sessizliğe bir anlam veremiyordu. Bir gün, Bay Uzunkulak\'ı ziyaret etmeye karar verdi. Bay Uzunkulak, köyün en yüksek tepesinde bulunan, kırmızı çatılı, mavi duvarlı küçük evinde yaşıyordu.\n\nZıpzıp, kapıyı çaldı ve içeri girdi. Bay Uzunkulak, büyük gözlüklerinin ardından Zıpzıp\'a baktı ve nazikçe gülümsedi. \"Hoş geldin Zıpzıp. Seni buralarda görmek ne güzel,\" dedi.\n\nZıpzıp, çekinerek sordu: \"Bay Uzunkulak, köyümüzde neler oluyor? Neden herkes bu kadar üzgün?\"\n\nBay Uzunkulak, derin bir iç çekti. \"Ah Zıpzıp, köyümüzün neşesi kayboldu. Biliyor musun, Gökkuşağı Köyü\'nün neşesi, Gökkuşağı Çiçeği adlı özel bir çiçeğin varlığına bağlıdır (dasd). Bu çiçek, köyümüzün tam ortasında, Güneş Tepesi\'nde açar ve tüm köyü neşelendirir. Ancak bu yıl, Gökkuşağı Çiçeği açmadı. Kimse nedenini bilmiyor.\"\n\nZıpzıp\'ın gözleri parladı. \"Belki de çiçeği bulup, tekrar açmasını sağlayabiliriz!\" dedi heyecanla.\n\nBay Uzunkulak, şaşkınlıkla Zıpzıp\'a baktı. \"Bu çok zor Zıpzıp. Güneş Tepesi\'ne giden yol tehlikelerle dolu. Ama senin cesaretine hayran kaldım. Yanına arkadaşlarınızı al ve dikkatli olun.\"\n\nZıpzıp, hemen en yakın arkadaşları olan Cikcik adında bir sincap ve Diken adında bir kirpiyi yanına çağırdı. Onlara durumu anlattı ve birlikte Güneş Tepesi\'ne gitmeye karar verdiler.\n\nZıpzıp, Cikcik ve Diken, uzun ve zorlu bir yolculuğa çıktılar. Ormanlardan geçtiler, dereleri aştılar ve yüksek tepeleri tırmandılar. Yol boyunca karşılarına çıkan engelleri, birlikte çalışarak ve birbirlerine destek olarak aştılar.\n\nSonunda Güneş Tepesi\'ne ulaştılar. Tepenin ortasında, kurumuş ve solmuş bir Gökkuşağı Çiçeği vardı. Zıpzıp, çiçeğe yaklaştı ve yapraklarını okşadı. \"Neden açmıyorsun?\" diye sordu.\n\nO anda, Cikcik bir ses duydu. Ağacın dalında oturan yaşlı bir baykuş, onlara bakıyordu. \"Gökkuşağı Çiçeği, sadece sevgi, dostluk ve yardımlaşma ile açar,\" dedi baykuş. \"Köyünüzde bunlar kaybolduğu için çiçek de soldu.\"\n\nZıpzıp, Cikcik ve Diken, birbirlerine baktılar. Anladılar ki, köydeki neşeyi geri getirmek için, önce kendileri sevgi, dostluk ve yardımlaşmayı yeniden canlandırmalıydılar (sdasdas).\n\nHemen köye geri döndüler. Köy meydanında toplandılar ve herkese Gökkuşağı Çiçeği\'nin durumunu anlattılar. Herkes, yaptığı hataları anladı ve birbirlerinden özür diledi. Birlikte çalışarak, köyü yeniden güzelleştirmeye başladılar. Tavşanlar tekrar zıplamaya, sincaplar fındıklarını paylaşmaya ve kirpiler dikenlerini saklayarak gülümsemeye başladılar.\n\nVe mucize gerçekleşti! Gökkuşağı Çiçeği, Güneş Tepesi\'nde yeniden açtı. Köy, eski neşesine kavuştu ve Gökkuşağı Festivali, her zamankinden daha coşkulu bir şekilde kutlandı. Zıpzıp, Cikcik ve Diken ise, köyün kahramanları oldular. Onlar, Gökkuşağı Köyü\'ne neşeyi geri getirmenin en önemli şeyin sevgi, dostluk ve yardımlaşma olduğunu öğretmişlerdi.\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"asd\\\",\\\"type\\\":\\\"adasds\\\"}]\"', '\"{\\\"setting\\\":\\\"asda\\\",\\\"theme\\\":\\\"sdasdas\\\",\\\"details\\\":\\\"dasd\\\",\\\"audience\\\":\\\"children\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', NULL, 'pending', 0, '2025-03-09 14:14:50', NULL, '05e49f770dd3456a03c76fd1441be27784d4fb6dd5ba89eca46de5c51205a938', 1),
(33, 1, 'asdasd', 'Elbette, istediğiniz özelliklere uygun bir masal yazabilirim. İşte Asda\'da geçen, \"sdasdas\" temasını işleyen, \"asd (adasds)\" karakterlerini içeren, \"dasd\" detaylarını barındıran, çocuklar için yazılmış klasik anlatım tarzında bir masal:\n\n**Asda\'nın Gizemli Rafı**\n\nEvvel zaman içinde, Asda adında kocaman bir süpermarket vardı. Bu süpermarkette her türlü yiyecek, oyuncak ve eşya bulunurdu. Ama Asda\'yı diğerlerinden ayıran bir şey vardı: Gizemli bir raf. Bu raf, diğerlerinden farklı olarak hep aynı ürünleri barındırmazdı. Bazen rengarenk şekerlemeler, bazen de parıldayan oyuncak arabalarla dolardı.\n\nBir gün, Asda\'da çalışan küçük bir kız vardı. Adı Ada\'ydı (adasds). Ada, diğer çocuklar gibi oyun oynamayı ve şeker yemeyi çok severdi. Ama en çok sevdiği şey, Gizemli Raf\'ı gözlemlemekti. Her gün rafa yaklaşır, yeni ne olduğunu merakla incelerdi.\n\nBir sabah, Ada her zamanki gibi rafa yaklaştığında, gördüğü manzara karşısında şaşkınlığa uğradı. Raf, altın rengi parıldayan küçük tohumlarla doluydu. Tohumların yanında, minik bir not vardı: \"Bu tohumlar, hayallerin gerçekleşmesini sağlar. Onları sevgiyle sulayın ve sabırla bekleyin.\"\n\nAda, notu okuduktan sonra çok heyecanlandı. Bir avuç tohum aldı ve cebine koydu. O gün işten çıktıktan sonra, eve koştu ve bahçesine gitti. Tohumları özenle toprağa ekti ve her gün sevgiyle suladı.\n\nGünler geçti, haftalar geçti. Ada, her gün tohumları sularken, onlara hayallerini anlatıyordu. En büyük hayali, bütün çocukların mutlu olmasıydı. Onların gülüşlerini görmek, Ada\'yı çok mutlu ediyordu.\n\nBir sabah, Ada bahçeye geldiğinde, gördüğü manzara karşısında nutku tutuldu. Tohumların ekildiği yerden, kocaman bir ağaç filizlenmişti. Ağacın dallarında, rengarenk meyveler asılıydı. Bu meyveler, sıradan meyveler değildi. Her biri, bir çocuğun hayalini temsil ediyordu. Kırmızı meyve, bir çocuğun oyuncak arabası hayalini, sarı meyve, bir çocuğun yeni bir bisiklet hayalini, mavi meyve ise, bir çocuğun tatile gitme hayalini temsil ediyordu.\n\nAda, ağacın meyvelerini topladı ve Asda\'ya geri döndü. Meyveleri, süpermarketteki bütün çocuklara dağıttı. Her çocuk, kendi hayalini temsil eden meyveyi yedi ve o anda, hayalleri gerçek oldu. Oyuncak arabaları olan çocuklar, sevinçten havalara uçtu. Bisikletleri olan çocuklar, sokaklarda neşeyle dolaştı. Tatile giden çocuklar ise, deniz kenarında kumdan kaleler yaptı.\n\nAda, bütün çocukların mutlu olduğunu görünce, kalbi sevinçle doldu. O günden sonra, Gizemli Raf\'ın sırrını çözmüştü. Raf, sadece eşyalarla değil, aynı zamanda hayallerle de doluydu. Ve bu hayaller, sevgi ve sabırla sulandığında, gerçek oluyordu.\n\nAsda\'daki herkes, Ada\'nın bu iyiliğini asla unutmadı. Ada, süpermarketteki en sevilen kişi oldu ve Gizemli Raf, onun sayesinde daha da meşhurlaştı. Çocuklar, her gün Asda\'ya gelir, Gizemli Raf\'ı ziyaret eder ve hayallerini fısıldardı. Çünkü biliyorlardı ki, hayaller sadece hayal etmekle kalmaz, aynı zamanda gerçekleşmeyi de bekler.\n\nVe böylece, Asda sadece bir süpermarket değil, aynı zamanda hayallerin gerçekleştiği bir yer haline geldi. Ada\'nın iyiliği ve Gizemli Raf\'ın sırrı, nesilden nesile aktarıldı. Her çocuk, Asda\'ya geldiğinde, hayallerini asla unutmamayı öğrendi. Çünkü biliyorlardı ki, en güzel şeyler, en beklenmedik anlarda, en beklenmedik yerlerde ortaya çıkardı. Tıpkı Asda\'nın Gizemli Rafı gibi...\n', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"asd\\\",\\\"type\\\":\\\"adasds\\\"}]\"', '\"{\\\"setting\\\":\\\"asda\\\",\\\"theme\\\":\\\"sdasdas\\\",\\\"details\\\":\\\"dasd\\\",\\\"audience\\\":\\\"children\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', NULL, 'pending', 0, '2025-03-09 14:15:32', NULL, 'a7b446f427390b3cfc362e4bae04ab50ef4d24e5faa37b96b919fa2c02c16678', 1),
(34, 1, 'beyzosum da beyzosum', 'beyzosum da beyzosum', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"beyzosum da beyzosum\\\",\\\"type\\\":\\\"beyzosum da beyzosum\\\"}]\"', '\"{\\\"setting\\\":\\\"beyzosum da beyzosum\\\",\\\"theme\\\":\\\"beyzosum da beyzosum\\\",\\\"details\\\":\\\"\\\",\\\"audience\\\":\\\"children\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/story_67cda438aac3e.mp3', 'pending', 0, '2025-03-09 14:22:01', '2025-03-09 14:22:49', 'd870b73b567d4060eece9ba3f42daa7b8510cc56cce360fe8021b14b0aea5455', 1),
(35, 1, 'beyzosum da beyzosum', '## beyzos kare kare beyzos', 'fairytale', 'classic', '\"[{\\\"name\\\":\\\"beyzosum da beyzosum\\\",\\\"type\\\":\\\"beyzosum da beyzosum\\\"}]\"', '\"{\\\"setting\\\":\\\"beyzosum da beyzosum\\\",\\\"theme\\\":\\\"beyzosum da beyzosum\\\",\\\"details\\\":\\\"\\\",\\\"audience\\\":\\\"children\\\",\\\"length\\\":\\\"500 kelime\\\"}\"', 'https://s3.us-east-005.backblazeb2.com/dijitalhediye/audio/story_67cdac55cf256.mp3', 'pending', 0, '2025-03-09 14:23:29', '2025-03-09 18:16:28', 'ad96759709050294c8986fac983828955cd849fd98d9b90c1a6b9098aa76316a', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dh_story_characters`
--

CREATE TABLE `dh_story_characters` (
  `id` int(11) NOT NULL,
  `story_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `dh_story_characters`
--

INSERT INTO `dh_story_characters` (`id`, `story_id`, `name`, `type`, `description`, `created_at`) VALUES
(1, 1, 'dfgdf', 'gfdg', NULL, '2025-03-07 04:46:07'),
(2, 2, 'Emir', 'erkek', NULL, '2025-03-07 04:51:11'),
(3, 2, 'beyza', 'Kadın', NULL, '2025-03-07 04:51:11'),
(4, 3, 'Emir', 'erkek', NULL, '2025-03-07 06:15:21'),
(5, 4, 'Emir', 'erkek', NULL, '2025-03-07 06:15:27'),
(6, 5, 'Emir', 'erkek', NULL, '2025-03-07 06:15:33'),
(7, 5, 'asd', 'asd', NULL, '2025-03-07 06:15:33'),
(8, 6, 'emir', 'tavşan', NULL, '2025-03-07 06:45:00'),
(9, 6, 'beyza', 'aslan', NULL, '2025-03-07 06:45:00'),
(10, 7, 'emir', 'tavşan', NULL, '2025-03-07 06:45:07'),
(11, 7, 'beyza', 'aslan', NULL, '2025-03-07 06:45:07'),
(12, 8, 'emir', 'tavşan', NULL, '2025-03-07 06:45:18');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dh_transactions`
--

CREATE TABLE `dh_transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `credits` int(11) NOT NULL,
  `payment_method` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending' COMMENT 'pending,approved,failed,rejected',
  `transaction_id` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `dh_transactions`
--

INSERT INTO `dh_transactions` (`id`, `user_id`, `amount`, `credits`, `payment_method`, `status`, `transaction_id`, `created_at`, `updated_at`) VALUES
(1, 1, 450.00, 500, 'credit_card', 'approved', '17412912891700', '2025-03-06 20:01:29', '2025-03-06 20:01:36'),
(2, 1, 800.00, 1000, 'credit_card', 'approved', '17412913102504', '2025-03-06 20:01:50', '2025-03-06 20:01:56'),
(3, 1, 450.00, 500, 'credit_card', 'pending', '17412924827853', '2025-03-06 20:21:22', NULL),
(4, 1, 450.00, 500, 'credit_card', 'approved', '17412944143179', '2025-03-06 20:53:34', '2025-03-06 20:53:44'),
(5, 7, 450.00, 500, 'credit_card', 'pending', '17412997981066', '2025-03-06 22:23:18', NULL),
(6, 7, 200.00, 200, 'credit_card', 'pending', '17412998023682', '2025-03-06 22:23:22', NULL),
(7, 1, 450.00, 500, 'credit_card', 'pending', '17413001364657', '2025-03-06 22:28:56', NULL),
(8, 1, 200.00, 200, 'credit_card', 'pending', '17413053823570', '2025-03-06 23:56:22', NULL),
(9, 1, 788.00, 788, 'bank_transfer', 'pending', '17413054966099', '2025-03-06 23:58:16', NULL),
(10, 1, 75.00, 75, 'bank_transfer', 'pending', '17413055843884', '2025-03-06 23:59:44', NULL),
(11, 1, 456.00, 456, 'bank_transfer', 'pending', '17413056032224', '2025-03-07 00:00:03', NULL),
(12, 1, 90.00, 90, 'bank_transfer', 'pending', '17413061341325', '2025-03-07 00:08:54', NULL),
(13, 1, 54654.00, 54654, 'bank_transfer', 'pending', '17413067896054', '2025-03-07 00:19:49', NULL),
(14, 1, 34534.00, 34534, 'bank_transfer', 'pending', '17413068193756', '2025-03-07 00:20:19', NULL),
(15, 1, 450.00, 500, 'credit_card', 'pending', '17413068276043', '2025-03-07 00:20:27', NULL),
(16, 1, 200.00, 200, 'credit_card', 'pending', '17413069046202', '2025-03-07 00:21:44', NULL),
(17, 1, 450.00, 500, 'credit_card', 'pending', '17413088204667', '2025-03-07 00:53:40', NULL),
(18, 1, 450.00, 450, 'bank_transfer', 'pending', '17413088249374', '2025-03-07 00:53:44', NULL),
(19, 1, 234.00, 234, 'bank_transfer', 'pending', '17413088346432', '2025-03-07 00:53:54', NULL),
(20, 1, 450.00, 500, 'credit_card', 'pending', '17413088649759', '2025-03-07 00:54:24', NULL),
(21, 1, 450.00, 450, 'bank_transfer', 'pending', '17413089073826', '2025-03-07 00:55:07', NULL),
(22, 1, 324.00, 324, 'credit_card', 'approved', '17413093185883', '2025-03-07 01:01:58', '2025-03-07 01:02:07'),
(23, 1, 450.00, 500, 'credit_card', 'pending', '17413308831165', '2025-03-07 07:01:23', NULL),
(24, 1, 450.00, 450, 'bank_transfer', 'pending', '17413393496113', '2025-03-07 09:22:29', NULL),
(25, 7, 200.00, 200, 'credit_card', 'approved', '17413483362181', '2025-03-07 11:52:16', '2025-03-07 11:52:24'),
(26, 20, 200.00, 200, 'credit_card', 'approved', '17413852944824', '2025-03-07 22:08:14', '2025-03-07 22:08:29'),
(27, 21, 800.00, 1000, 'credit_card', 'pending', '17413899546928', '2025-03-07 23:25:54', NULL),
(28, 21, 450.00, 500, 'credit_card', 'approved', '17413899839474', '2025-03-07 23:26:23', '2025-03-07 23:26:29'),
(29, 7, 200.00, 200, 'credit_card', 'approved', '17414030431780', '2025-03-08 03:04:03', '2025-03-08 03:04:10'),
(30, 7, 200.00, 200, 'credit_card', 'approved', '17414271438026', '2025-03-08 09:45:43', '2025-03-08 09:45:50'),
(31, 16, 1400.00, 2000, 'credit_card', 'approved', '17414272161074', '2025-03-08 09:46:56', '2025-03-08 09:47:04'),
(32, 1, 200.00, 200, 'credit_card', 'approved', '17415262958141', '2025-03-09 13:18:15', '2025-03-09 13:18:21'),
(33, 1, 1400.00, 2000, 'credit_card', 'approved', '17415266409045', '2025-03-09 13:24:00', '2025-03-09 13:24:09');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dh_users`
--

CREATE TABLE `dh_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `credits` int(11) DEFAULT 0,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `puzzle_token` varchar(64) DEFAULT NULL,
  `puzzle_token_expires` timestamp NULL DEFAULT NULL,
  `last_session_data` text DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `dh_users`
--

INSERT INTO `dh_users` (`id`, `username`, `email`, `password_hash`, `credits`, `is_admin`, `is_active`, `created_at`, `updated_at`, `puzzle_token`, `puzzle_token_expires`, `last_session_data`, `phone`) VALUES
(1, 'test3243', 'test324@gmail.com', '$2y$10$dnZkvAAPf9ygR5U/qOd0eunN/1Vc2AYA03O/Pn8KwIs3EobycBofm', 2007, 1, 1, '2025-03-05 07:02:13', '2025-03-09 14:57:26', NULL, NULL, NULL, '05423300807'),
(2, 'test32423', 'test32423@gmail.com', '$2y$10$US106usP/BP/wRPCRu9Yyue3NAXf1jbk/TW0IdNdBS1vSC4Xh54HK', 1000, 0, 1, '2025-03-05 09:28:19', '2025-03-06 01:46:30', NULL, NULL, NULL, NULL),
(3, 'test7677', 'test@gmail.com', '$2y$10$IcoYsR0fGaPjoF3z3IbzhuDp5HnRo/MVPnlJ/jYEQP2/SzxmJLOgW', 0, 1, 1, '2025-03-05 11:53:57', '2025-03-06 06:02:36', NULL, NULL, NULL, NULL),
(4, 'test324324', 'test324324s@gmail.com', '$2y$10$R5YjQw4pwEUHHUJI/xTkX.xsxqyiyE.tdsg85GDEccBJnTHCzx76a', 12, 0, 1, '2025-03-05 23:51:33', '2025-03-06 01:59:19', NULL, NULL, NULL, NULL),
(5, 'test88', 'Panel1563@gmail.com', '$2y$10$a7yzOn8cQUpKBQWj7uZRB.1ZgigAZbh7RaTlol0wjylLsySN.qAMm', 0, 0, 1, '2025-03-06 04:52:42', '2025-03-06 04:52:42', NULL, NULL, NULL, NULL),
(7, 'test76777', 'test7677@gmail.com', '$2y$10$DXVGNxX0a7tOkPM/u6CNueVIImawd4TIuI9ocVkbVwd1lZj30MtLq', 200, 0, 1, '2025-03-06 04:55:00', '2025-03-08 09:45:50', NULL, NULL, NULL, '05423300805'),
(8, 'test324123', 'test3243423@gmail.com', '$2y$10$RJ/YZEaa9qfGZawSNQP/W.N/B/DOOsd8S3wplT2qrTvTmJkJYQ1N2', 0, 0, 1, '2025-03-06 05:33:04', '2025-03-06 05:33:04', NULL, NULL, NULL, NULL),
(9, 'emrsadasd', 'akgulemir734444444@gmail.com', '$2y$10$JY7r7NRh7PABL/pSNitVFO1taJkjG9z0ID2N.1Thl3y5gk5.m0dTK', 0, 0, 1, '2025-03-06 05:39:43', '2025-03-06 05:39:43', NULL, NULL, NULL, NULL),
(10, 'test324123tes', 'test333332423@gmail.com', '$2y$10$ZbuXWuWVoKHj0tI5AGieU.assniDH2V0oj9acfMtkjqrQ6zfKFUzW', 0, 0, 1, '2025-03-06 05:40:03', '2025-03-06 05:40:03', NULL, NULL, NULL, NULL),
(11, 'test324123s', 'asdkj@gmail.com', '$2y$10$4cJZs.iqS7uZ3ZVh4MyKDOo6AX14n2rEYnK.hlic1ieA0K9ce.85S', 0, 0, 1, '2025-03-06 05:45:49', '2025-03-06 05:45:49', NULL, NULL, NULL, NULL),
(13, 'test3241230', 'akgulemir73444@gmail.com', '$2y$10$LfKdmwuHSoPKqdSa22OMt.CbhznAQM0SiQdi9GMFLi1IwtBzN8P9e', 0, 0, 1, '2025-03-06 05:46:29', '2025-03-06 05:46:29', NULL, NULL, NULL, NULL),
(15, 'test32412312', 'test324253@gmail.com', '$2y$10$nilZd0VW20FeIDgj7cPtD.gHrbp77rAAHjtd/OOpdEfhVh/HsZiCi', 0, 0, 1, '2025-03-06 05:58:03', '2025-03-06 05:58:03', NULL, NULL, NULL, '5423300808'),
(16, 'yigitdmrly', 'mustafayigitd04@gmail.com', '$2y$10$vhDIgQaJRmVhliWPtthnUOHctuaxRLvYw3ghshY8t0J40DMv5qaXO', 1800, 1, 1, '2025-03-06 06:03:23', '2025-03-08 09:51:25', NULL, NULL, NULL, '5050980632'),
(17, 'dCGIPvtWqZ', 'khodgea31@gmail.com', '$2y$10$wP8ArHbwOb3WoZrIHOOWK.Q0yuDGkI8CEY1RGDEj/Fa137R78h7y2', 0, 0, 1, '2025-03-06 06:47:19', '2025-03-06 06:47:19', NULL, NULL, NULL, '3809384297'),
(18, 'test32', 'test3233@gmail.com', '$2y$10$/hw81HZiC5rQ5/wz2EgCnO4sZZukMGgC2MNAhT6/Kv5y0sKNE/I5S', 0, 0, 1, '2025-03-07 08:17:52', '2025-03-07 08:17:52', NULL, NULL, NULL, '05423300803'),
(19, 'EaYAduHuBttN', 'mattiodonnellc@gmail.com', '$2y$10$vPDnOEdObn48mIow7QpD4OSzyD10xH/YibtQnMJvX36PO18Rj7pWO', 0, 0, 1, '2025-03-07 12:49:58', '2025-03-07 12:49:58', NULL, NULL, NULL, '4228305134'),
(20, 'Beyzos', 'byznu0@gmail.com', '$2y$10$PJmT91OlUqCZxUb2Gyo2N.RB.JPGVu1nrYbkt4x51HWvPSg8LEdzO', 100, 0, 1, '2025-03-07 22:07:48', '2025-03-07 22:14:32', NULL, NULL, NULL, '5524576015'),
(21, 'Velizz', 'vmcccc74@gmail.com', '$2y$10$Ogo5dLNwG0hG/vojeNwPQOj2yDEzRzcXnQUn2P00DYLPaDK6OdzmK', 400, 0, 1, '2025-03-07 23:25:00', '2025-03-07 23:28:20', NULL, NULL, NULL, '5333312032'),
(22, 'GUSYcdyoq', 'mannikswalker@gmail.com', '$2y$10$vq4SneWO8meXn379M/T6oewWPMF00fFFIzwdvTI1m2hNOtrq0mKwq', 0, 0, 1, '2025-03-08 08:43:36', '2025-03-08 08:43:36', NULL, NULL, NULL, '8785360562'),
(23, 'nhsZoYNIFiBIXi', 'bryahykk@gmail.com', '$2y$10$IQS6F.oy38pmdN65EofU/OvJYrZJsgsQwOD1mkLz7XBPLODfX79CC', 0, 0, 1, '2025-03-09 06:23:42', '2025-03-09 06:23:42', NULL, NULL, NULL, '2953537138');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `dh_voices`
--

CREATE TABLE `dh_voices` (
  `id` int(11) NOT NULL,
  `voice_id` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `demo_url` varchar(255) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `dh_voices`
--

INSERT INTO `dh_voices` (`id`, `voice_id`, `name`, `description`, `gender`, `demo_url`, `icon`, `is_active`, `created_at`) VALUES
(1, 'gyxPK6bLXQAkBSCeAKvk', 'Sultan', 'Büyüleyici, Baştan Çıkarıcı Anlatıcı', 'female', '/audio/Dijital+Hediye+-+Sultan.mp3', 'fa-female', 1, '2025-03-08 08:08:26'),
(2, 'EJGs6dWlD5VrB3llhBqB', 'Çiçek', 'Neşeli, Dinamik Hikaye Anlatıcısı', 'female', '/audio/Dijital+Hediye+-+Çiçek.mp3', 'fa-male', 1, '2025-03-08 08:08:26'),
(3, 'D1xRw7f8ZHedI7xJgfvz', 'Cem', 'Enerjik ve genç erkek sesi', 'male', '/audio/Dijital+Hediye+-+Cem.mp3', 'fa-male', 1, '2025-03-08 08:08:26'),
(4, 'NNn9dv8zq2kUo7d3JSGG', 'Derya', 'Dinamik ve arkadaş canlısı kadın sesi - hikaye anlatımı için uygun. ', 'female', '/audio/Dijital+Hediye+-+Derya.mp3', 'fa-female', 1, '2025-03-08 08:08:26');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `puzzles`
--

CREATE TABLE `puzzles` (
  `id` int(11) NOT NULL,
  `access_token` varchar(64) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `difficulty` enum('easy','medium','hard','insane') NOT NULL,
  `completion_time` int(11) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `elapsed_time` int(11) DEFAULT 0,
  `completion_message` varchar(255) DEFAULT 'Tebrikler! Puzzle''i tamamladiniz!',
  `visibility` enum('public','private') DEFAULT 'public',
  `created_by` int(11) NOT NULL DEFAULT 1,
  `is_paused` tinyint(1) DEFAULT 0,
  `reset_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL,
  `is_completed` tinyint(1) DEFAULT 0,
  `youtube_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `puzzles`
--

INSERT INTO `puzzles` (`id`, `access_token`, `image_path`, `difficulty`, `completion_time`, `score`, `created_at`, `elapsed_time`, `completion_message`, `visibility`, `created_by`, `is_paused`, `reset_timestamp`, `user_id`, `is_completed`, `youtube_url`) VALUES
(1, 'b16a443269bb7b99bea127de9f015b09a3939447937d40fd90027cd2256ac337', '/uploads/6a0d1cf70f9a2926ca33b30d526686dd.jpg', 'easy', NULL, NULL, '2025-03-05 07:40:55', 5, 'Tebrikler! Puzzle\'i tamamladiniz!', 'public', 1, 0, '2025-03-05 07:40:55', 1, 0, ''),
(2, '42b50674f32fb480e4c4d8461978b2c40f84b58208d7514265b07eeac2232445', '/uploads/c43949608151bde7d47ebdb7d741c7aa.jpg', 'easy', NULL, NULL, '2025-03-05 07:50:48', 0, 'Tebrikler! Puzzle\'i tamamladiniz!', 'public', 1, 0, '2025-03-05 07:50:48', 1, 0, ''),
(3, '476d2e720e7046af2d3701a26ccd464e0c785f9697580ace34991a5c51542a00', '/uploads/013340b7404992ea90e701311103d3ea.jpg', 'easy', NULL, NULL, '2025-03-05 08:25:17', 0, 'Tebrikler! Puzzle\'? tamamlajvd?n?z!', 'public', 1, 0, '2025-03-05 08:25:17', 1, 0, ''),
(4, 'f15cc370e42e2f21a4fb1162f4dffb329917cec7b3da65ff08c35054426c8662', '/uploads/f3580eff8b103267c1ab311a41702760.jpg', 'easy', NULL, NULL, '2025-03-05 08:34:41', 236, 'Tebrikler! Puzzle\'? tamamlad?n?z!v', 'public', 1, 0, '2025-03-05 09:24:57', 1, 0, ''),
(5, '0edce2a391a251394a6aab0b64e34a5c65ec0fce52b999b143d3fbec27349a65', '/uploads/0ddae6ed4ce368d0018a9d4bd7e72daa.jpg', 'easy', NULL, NULL, '2025-03-05 09:29:17', 281, 'Tebrikler! Puzzle\'i tamamladiniz!', 'public', 1, 0, '2025-03-05 18:52:11', 1, 0, 'Sdw7eaCSzhg'),
(6, '8f98dece788270f8a8c54c4afddec08bf87d8e3771bca3fcb58b4c3d78df4a86', '/uploads/2ce90251b9f901f3249b4141f8b0a921.jpg', 'easy', 319, NULL, '2025-03-05 18:52:52', 319, 'Tebrikler! Puzzle\'I tamamlad?n?z!', 'private', 1, 0, '2025-03-05 18:52:52', 1, 1, '1ZCbjmLOEO0'),
(8, 'd4660d9bee937d3da33ae6e38037ef089ab50a482ca2a65c599b9c0f5beea46c', '/uploads/868bb1d9bf7155023b506d521b85c5dc.jpg', 'easy', 136, NULL, '2025-03-06 07:10:14', 136, 'Tebrikler! Puzzle\'i tamamladiniz!', 'public', 1, 0, '2025-03-06 20:40:55', 1, 1, ''),
(9, '333c21fe1018b7e2bd52c52f9bd7287ab120d406ad0993555c378cfd0e7d579e', '/uploads/e0940b6998222fa5fd82019e5a73e574.jpg', 'easy', 109, NULL, '2025-03-07 11:06:07', 109, 'Tebrikler! Puzzle\'i tamamladiniz!', 'public', 1, 0, '2025-03-07 11:06:07', 1, 1, ''),
(10, '43d031f46245ebf9c80ef237db202fa18c66edabb032a4843decd19469269b90', '/uploads/fa9f94f410b84c27e748eb610e6abbbb.jpg', 'easy', NULL, NULL, '2025-03-09 07:37:45', 0, 'Tebrikler! Puzzle\'i tamamladiniz!', 'public', 1, 0, '2025-03-09 07:37:45', 1, 0, ''),
(11, 'ef4b0840f8bef70fec32ef008d22bfde702d5efe394c35e18711f1beaa13a3f6', '/uploads/0c04d25716f9ead3d553b81d0111d984.jpg', 'easy', NULL, NULL, '2025-03-09 08:41:21', 0, 'Tebrikler! Puzzle\'i tamamladiniz!', 'public', 1, 0, '2025-03-09 08:41:21', 1, 0, ''),
(12, '58b1e382893fe4d2bb61228b7372037c0289783112dd0629a0688fc2a37436ee', '/uploads/545be65c9ee25b682d97e32914b0c712.jpg', 'easy', NULL, NULL, '2025-03-09 09:51:56', 10, 'Tebrikler! Puzzle\'i tamamladiniz!', 'public', 1, 0, '2025-03-09 09:51:56', 1, 0, ''),
(13, '396884a0881f166f7d5e5e8d2816955af19e93965a01b3e5c126c05e9a94da03', '/uploads/93fb1f7b3c5d51a3efec3f051a353b15.jpg', 'easy', NULL, NULL, '2025-03-09 13:23:39', 35, 'Tebrikler! Puzzle\'? tamamlad?n?z!', 'public', 1, 0, '2025-03-09 13:23:39', 1, 0, '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `puzzle_moves`
--

CREATE TABLE `puzzle_moves` (
  `id` int(11) NOT NULL,
  `puzzle_id` int(11) DEFAULT NULL,
  `piece_id` varchar(10) DEFAULT NULL,
  `slot_id` varchar(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_return` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `puzzle_moves`
--

INSERT INTO `puzzle_moves` (`id`, `puzzle_id`, `piece_id`, `slot_id`, `created_at`, `is_return`, `is_active`) VALUES
(2, 4, '0_0', '3', '2025-03-05 09:25:07', 0, 0),
(3, 4, '0_0', '2', '2025-03-05 09:25:07', 0, 0),
(4, 4, '0_0', '6', '2025-03-05 09:25:08', 0, 1),
(5, 1, '2_0', '3', '2025-03-05 10:18:37', 0, 0),
(6, 1, '2_0', 'pieces-are', '2025-03-05 10:18:38', 1, 1),
(563, 13, '3_3', '2', '2025-03-09 15:09:18', 0, 0),
(564, 13, '3_3', '3', '2025-03-09 15:09:19', 0, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `puzzle_scores`
--

CREATE TABLE `puzzle_scores` (
  `id` int(11) NOT NULL,
  `puzzle_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `completion_time` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Tablo döküm verisi `puzzle_scores`
--

INSERT INTO `puzzle_scores` (`id`, `puzzle_id`, `user_id`, `score`, `completion_time`, `created_at`) VALUES
(23, 6, 1, 0, 319, '2025-03-06 20:52:30'),
(24, 6, 1, 0, 319, '2025-03-06 20:52:31'),
(25, 9, 1, 0, 108, '2025-03-08 02:20:16'),
(26, 9, 1, 0, 108, '2025-03-08 02:20:17'),
(27, 9, 1, 0, 109, '2025-03-08 02:20:17');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `dh_bank_accounts`
--
ALTER TABLE `dh_bank_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `dh_credit_packages`
--
ALTER TABLE `dh_credit_packages`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `dh_credit_transactions`
--
ALTER TABLE `dh_credit_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Tablo için indeksler `dh_credit_usage`
--
ALTER TABLE `dh_credit_usage`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Tablo için indeksler `dh_games`
--
ALTER TABLE `dh_games`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `dh_payment_notifications`
--
ALTER TABLE `dh_payment_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `bank_account_id` (`bank_account_id`);

--
-- Tablo için indeksler `dh_stories`
--
ALTER TABLE `dh_stories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `share_token` (`share_token`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `share_token_2` (`share_token`);

--
-- Tablo için indeksler `dh_story_characters`
--
ALTER TABLE `dh_story_characters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `story_id` (`story_id`);

--
-- Tablo için indeksler `dh_transactions`
--
ALTER TABLE `dh_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_transaction_id` (`transaction_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Tablo için indeksler `dh_users`
--
ALTER TABLE `dh_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_puzzle_token` (`puzzle_token`),
  ADD KEY `idx_phone` (`phone`);

--
-- Tablo için indeksler `dh_voices`
--
ALTER TABLE `dh_voices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `voice_id` (`voice_id`);

--
-- Tablo için indeksler `puzzles`
--
ALTER TABLE `puzzles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_puzzle_user` (`user_id`),
  ADD KEY `idx_puzzle_token` (`access_token`);

--
-- Tablo için indeksler `puzzle_moves`
--
ALTER TABLE `puzzle_moves`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_moves_puzzle` (`puzzle_id`);

--
-- Tablo için indeksler `puzzle_scores`
--
ALTER TABLE `puzzle_scores`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_scores_puzzle` (`puzzle_id`),
  ADD KEY `idx_scores_user` (`user_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `dh_bank_accounts`
--
ALTER TABLE `dh_bank_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `dh_credit_packages`
--
ALTER TABLE `dh_credit_packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `dh_credit_transactions`
--
ALTER TABLE `dh_credit_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Tablo için AUTO_INCREMENT değeri `dh_credit_usage`
--
ALTER TABLE `dh_credit_usage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `dh_games`
--
ALTER TABLE `dh_games`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Tablo için AUTO_INCREMENT değeri `dh_payment_notifications`
--
ALTER TABLE `dh_payment_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Tablo için AUTO_INCREMENT değeri `dh_stories`
--
ALTER TABLE `dh_stories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Tablo için AUTO_INCREMENT değeri `dh_story_characters`
--
ALTER TABLE `dh_story_characters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Tablo için AUTO_INCREMENT değeri `dh_transactions`
--
ALTER TABLE `dh_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- Tablo için AUTO_INCREMENT değeri `dh_users`
--
ALTER TABLE `dh_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Tablo için AUTO_INCREMENT değeri `dh_voices`
--
ALTER TABLE `dh_voices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `puzzles`
--
ALTER TABLE `puzzles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Tablo için AUTO_INCREMENT değeri `puzzle_moves`
--
ALTER TABLE `puzzle_moves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=565;

--
-- Tablo için AUTO_INCREMENT değeri `puzzle_scores`
--
ALTER TABLE `puzzle_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `dh_credit_usage`
--
ALTER TABLE `dh_credit_usage`
  ADD CONSTRAINT `dh_credit_usage_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `dh_users` (`id`);

--
-- Tablo kısıtlamaları `dh_payment_notifications`
--
ALTER TABLE `dh_payment_notifications`
  ADD CONSTRAINT `dh_payment_notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `dh_users` (`id`),
  ADD CONSTRAINT `dh_payment_notifications_ibfk_2` FOREIGN KEY (`bank_account_id`) REFERENCES `dh_bank_accounts` (`id`);

--
-- Tablo kısıtlamaları `dh_stories`
--
ALTER TABLE `dh_stories`
  ADD CONSTRAINT `dh_stories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `dh_users` (`id`);

--
-- Tablo kısıtlamaları `dh_story_characters`
--
ALTER TABLE `dh_story_characters`
  ADD CONSTRAINT `dh_story_characters_ibfk_1` FOREIGN KEY (`story_id`) REFERENCES `dh_stories` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `dh_transactions`
--
ALTER TABLE `dh_transactions`
  ADD CONSTRAINT `dh_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `dh_users` (`id`);

--
-- Tablo kısıtlamaları `puzzles`
--
ALTER TABLE `puzzles`
  ADD CONSTRAINT `puzzles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `dh_users` (`id`);

--
-- Tablo kısıtlamaları `puzzle_moves`
--
ALTER TABLE `puzzle_moves`
  ADD CONSTRAINT `puzzle_moves_ibfk_1` FOREIGN KEY (`puzzle_id`) REFERENCES `puzzles` (`id`);

--
-- Tablo kısıtlamaları `puzzle_scores`
--
ALTER TABLE `puzzle_scores`
  ADD CONSTRAINT `puzzle_scores_ibfk_1` FOREIGN KEY (`puzzle_id`) REFERENCES `puzzles` (`id`),
  ADD CONSTRAINT `puzzle_scores_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `dh_users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
