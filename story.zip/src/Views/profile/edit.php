<?php require_once 'includes/header.php'; ?>

<div class="main-content">
    <div class="container">
        <div class="profile-edit-container">
            <div class="section-header">
                <h2>Profil Düzenle</h2>
            </div>

            <div class="notifications-container">
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="notification error" id="errorNotification">
                        <div class="notification-content">
                            <i class="fas fa-exclamation-circle"></i>
                            <span><?= $_SESSION['error'] ?></span>
                        </div>
                        <button class="notification-close" onclick="closeNotification('errorNotification')">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                <?php unset($_SESSION['error']); endif; ?>

                <?php if (isset($_SESSION['success'])): ?>
                    <div class="notification success" id="successNotification">
                        <div class="notification-content">
                            <i class="fas fa-check-circle"></i>
                            <span><?= $_SESSION['success'] ?></span>
                        </div>
                        <button class="notification-close" onclick="closeNotification('successNotification')">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                <?php unset($_SESSION['success']); endif; ?>
            </div>

            <div class="card">
                <form action="/profile/update" method="POST" class="profile-form">
                    <div class="form-group">
                        <label for="username">Kullanıcı Adı</label>
                        <input type="text" id="username" name="username" 
                               value="<?= htmlspecialchars($user['username']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="email">E-posta</label>
                        <input type="email" id="email" name="email" 
                               value="<?= htmlspecialchars($user['email']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Telefon Numarası</label>
                        <input type="tel" id="phone" name="phone" 
                               value="<?= htmlspecialchars($user['phone'] ?? '') ?>" 
                               pattern="[0-9]{10,11}" 
                               placeholder="05xxxxxxxxx">
                    </div>

                    <div class="form-group">
                        <label for="new_password">Yeni Şifre (Değiştirmek istemiyorsanız boş bırakın)</label>
                        <input type="password" id="new_password" name="new_password">
                    </div>

                    <div class="form-group">
                        <label for="confirm_password">Yeni Şifre Tekrar</label>
                        <input type="password" id="confirm_password" name="confirm_password">
                    </div>

                    <div class="form-group">
                        <label for="current_password">Mevcut Şifre (Değişiklikleri onaylamak için gerekli)</label>
                        <input type="password" id="current_password" name="current_password" required>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Değişiklikleri Kaydet</button>
                        <a href="/" class="btn btn-secondary">İptal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
/* Genel stiller */
.main-content {
    padding-top: 80px; /* Header yüksekliği kadar padding */
}

.profile-edit-container {
    max-width: 800px;
    margin: 1rem auto;
    padding: 0 15px; /* Mobilde kenar boşluğu */
}

.card {
    background: var(--card-bg);
    border-radius: var(--border-radius);
    padding: 1.5rem;
    box-shadow: var(--card-shadow);
}

/* Mobil için düzenlemeler */
@media (max-width: 768px) {
    .main-content {
        padding-top: 60px; /* Mobilde daha az padding */
    }

    .profile-edit-container {
        margin: 0.5rem auto;
    }

    .card {
        padding: 1rem;
    }

    .form-group {
        margin-bottom: 0.75rem;
    }

    .form-group input {
        padding: 0.5rem;
    }

    .form-actions {
        flex-direction: column;
        gap: 0.5rem;
    }

    .form-actions button,
    .form-actions a {
        width: 100%;
        text-align: center;
    }

    .section-header h2 {
        font-size: 1.5rem;
        margin: 0.5rem 0;
    }
}

/* Diğer stiller aynı kalacak */
.profile-form {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: var(--text-color);
}

.form-group input {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid var(--border-color);
    border-radius: var(--border-radius);
    font-size: 1rem;
    background: var(--input-bg);
    color: var(--text-color);
}

.form-actions {
    display: flex;
    gap: 1rem;
    margin-top: 2rem;
}

.section-header {
    margin-bottom: 2rem;
    text-align: center;
}

.section-header h2 {
    color: var(--heading-color);
    font-size: 1.75rem;
}

.alert {
    margin-bottom: 1rem;
    padding: 1rem;
    border-radius: var(--border-radius);
}

.alert-danger {
    background: var(--danger-bg);
    color: var(--danger-color);
    border: 1px solid var(--danger-border);
}

.alert-success {
    background: var(--success-bg);
    color: var(--success-color);
    border: 1px solid var(--success-border);
}

/* Notification Styles */
.notifications-container {
    position: fixed;
    top: 80px; /* Header'ın altında */
    right: 20px;
    z-index: 1000;
    display: flex;
    flex-direction: column;
    gap: 10px;
    max-width: 400px;
    width: calc(100% - 40px);
}

.notification {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    animation: slideIn 0.3s ease-out;
    background: white;
}

.notification.error {
    border-left: 4px solid #dc3545;
}

.notification.success {
    border-left: 4px solid #28a745;
}

.notification-content {
    display: flex;
    align-items: center;
    gap: 12px;
}

.notification i {
    font-size: 20px;
}

.notification.error i {
    color: #dc3545;
}

.notification.success i {
    color: #28a745;
}

.notification span {
    color: #333;
    font-size: 14px;
}

.notification-close {
    background: none;
    border: none;
    color: #666;
    cursor: pointer;
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: color 0.2s;
}

.notification-close:hover {
    color: #333;
}

@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes fadeOut {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(100%);
        opacity: 0;
    }
}

/* Mobil için düzenlemeler */
@media (max-width: 768px) {
    .notifications-container {
        top: 60px;
        right: 10px;
        width: calc(100% - 20px);
    }

    .notification {
        padding: 12px;
    }

    .notification span {
        font-size: 13px;
    }
}
</style>

<script>
document.querySelector('.profile-form').addEventListener('submit', function(e) {
    const newPassword = document.getElementById('new_password').value;
    const confirmPassword = document.getElementById('confirm_password').value;

    if (newPassword && newPassword !== confirmPassword) {
        e.preventDefault();
        alert('Yeni şifreler eşleşmiyor!');
    }
});

function closeNotification(id) {
    const notification = document.getElementById(id);
    notification.style.animation = 'fadeOut 0.3s ease-out forwards';
    setTimeout(() => {
        notification.remove();
    }, 300);
}

document.addEventListener('DOMContentLoaded', function() {
    const notifications = document.querySelectorAll('.notification');
    notifications.forEach(notification => {
        setTimeout(() => {
            if (notification && notification.parentNode) {
                notification.style.animation = 'fadeOut 0.3s ease-out forwards';
                setTimeout(() => {
                    notification.remove();
                }, 300);
            }
        }, 5000); // 5 saniye sonra otomatik kapanır
    });
});
</script>

<?php require_once 'includes/footer.php'; ?> 