<?php
// ElevenLabs API ayarları
define('TTS_API_KEY', 'sk_2b10467edf68f3cf8beb8e4da05d285ae84e42dedda656c2');
define('TTS_API_URL', 'https://api.elevenlabs.io/v1');
// Ses Ayarları
define('TTS_VOICE_LANGUAGE', 'tr-TR');
define('TTS_VOICE_NAME', 'tr-TR-Standard-A');
define('TTS_AUDIO_ENCODING', 'MP3');
define('TTS_SPEAKING_RATE', 0.9);
define('TTS_PITCH', 0);
