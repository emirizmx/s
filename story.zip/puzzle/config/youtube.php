<?php
define('YOUTUBE_API_KEY', 'AIzaSyAoEPhz4gIAyw4pPxeMUM6AdieVwkYOabY'); 