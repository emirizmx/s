<?php
// Gemini API Yapılandırması
define('GEMINI_API_KEY', 'AIzaSyBVGlizf_w1118bvB7Psalgf2VYPAyxBwM');
define('GEMINI_API_URL', 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent');

// Prompt Ayarları
define('GEMINI_MAX_TOKENS', 1000);
define('GEMINI_TEMPERATURE', 0.7);
define('GEMINI_TOP_P', 0.9);