<?php
// Helper sınıfları
require_once 'src/Helpers/LogHelper.php';
// Diğer helper sınıfları...

// Model sınıfları
require_once 'src/Models/User.php';
require_once 'src/Models/Credit.php';
// Diğer model sınıfları...

// Sistem kütüphaneleri ve yapılandırmaları
// ... diğer gerekli dosyaları dahil et 