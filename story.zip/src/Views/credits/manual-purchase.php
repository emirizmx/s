<?php require 'includes/header.php'; ?>

<div class="container" style="margin-top: var(--header-height); padding-top: 2rem;">
    <div class="manual-payment-section" style="max-width: 900px; margin: 0 auto;">
        <!-- Başlık -->
        <h1 style="text-align: center; margin-bottom: 2rem; color: var(--text-color);">
            Banka Havalesi ile Ödeme
        </h1>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error" style="
                background: #fee2e2;
                border: 1px solid #ef4444;
                color: #991b1b;
                padding: 1rem;
                border-radius: 10px;
                margin-bottom: 1.5rem;
            ">
                <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <!-- Banka Hesapları -->
        <div class="bank-accounts-section" style="
            background: var(--surface-color);
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--card-shadow);
        ">
            <h2 style="
                color: var(--text-color);
                font-size: 1.5rem;
                margin-bottom: 1.5rem;
                text-align: center;
            ">Banka Hesaplarımız</h2>

            <div class="bank-accounts-grid" style="
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
                gap: 1.5rem;
            ">
                <?php foreach ($bankAccounts as $account): ?>
                    <div class="bank-account-card" style="
                        background: white;
                        border-radius: 12px;
                        padding: 1.5rem;
                        border: 1px solid var(--border-color);
                        transition: all 0.3s ease;
                    ">
                        <h3 style="
                            color: var(--primary-color);
                            font-size: 1.2rem;
                            margin-bottom: 1rem;
                        "><?php echo htmlspecialchars($account['bank_name']); ?></h3>
                        
                        <div style="margin-bottom: 0.8rem;">
                            <label style="
                                display: block;
                                color: var(--text-light);
                                font-size: 0.9rem;
                                margin-bottom: 0.3rem;
                            ">Hesap Sahibi</label>
                            <strong style="color: var(--text-color);">
                                <?php echo htmlspecialchars($account['account_holder']); ?>
                            </strong>
                        </div>

                        <div style="margin-bottom: 1rem;">
                            <label style="
                                display: block;
                                color: var(--text-light);
                                font-size: 0.9rem;
                                margin-bottom: 0.3rem;
                            ">IBAN</label>
                            <div style="
                                display: flex;
                                align-items: center;
                                gap: 0.5rem;
                            ">
                                <code style="
                                    background: #f3f4f6;
                                    padding: 0.5rem;
                                    border-radius: 6px;
                                    font-size: 0.9rem;
                                    flex: 1;
                                "><?php echo htmlspecialchars($account['iban']); ?></code>
                                <button class="copy-iban" 
                                        data-iban="<?php echo htmlspecialchars($account['iban']); ?>"
                                        style="
                                            background: var(--primary-color);
                                            color: white;
                                            border: none;
                                            padding: 0.5rem 1rem;
                                            border-radius: 6px;
                                            cursor: pointer;
                                            font-size: 0.9rem;
                                            transition: all 0.3s ease;
                                        ">
                                    Kopyala
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Ödeme Bildirim Formu -->
        <div class="payment-form-section" style="
            background: var(--surface-color);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: var(--card-shadow);
        ">
            <h2 style="
                color: var(--text-color);
                font-size: 1.5rem;
                margin-bottom: 1.5rem;
                text-align: center;
            ">Ödeme Bildirimi</h2>

            <form method="POST" action="/credits/notify-payment" style="max-width: 600px; margin: 0 auto;">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <input type="hidden" name="transaction_id" value="<?php echo $transaction['transaction_id']; ?>">

                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; margin-bottom: 0.5rem; color: var(--text-color);">
                        Gönderilen Tutar
                    </label>
                    <input type="number" 
                           name="amount" 
                           value="<?php echo htmlspecialchars($transaction['amount']); ?>" 
                           readonly
                           style="
                               width: 100%;
                               padding: 0.8rem;
                               border: 1px solid var(--border-color);
                               border-radius: 10px;
                               font-size: 1rem;
                               background: #f3f4f6;
                           ">
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; margin-bottom: 0.5rem; color: var(--text-color);">
                        Gönderen Ad Soyad
                    </label>
                    <input type="text" 
                           name="sender_name" 
                           required
                           style="
                               width: 100%;
                               padding: 0.8rem;
                               border: 1px solid var(--border-color);
                               border-radius: 10px;
                               font-size: 1rem;
                           ">
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; margin-bottom: 0.5rem; color: var(--text-color);">
                        Gönderilen Banka
                    </label>
                    <select name="bank_account_id" 
                            required
                            style="
                                width: 100%;
                                padding: 0.8rem;
                                border: 1px solid var(--border-color);
                                border-radius: 10px;
                                font-size: 1rem;
                                background-color: white;
                            ">
                        <option value="">Banka Seçin</option>
                        <?php foreach ($bankAccounts as $account): ?>
                            <option value="<?php echo $account['id']; ?>">
                                <?php echo htmlspecialchars($account['bank_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 1rem;
                    margin-bottom: 1.5rem;
                ">
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; color: var(--text-color);">
                            Transfer Tarihi
                        </label>
                        <input type="date" 
                               name="transfer_date" 
                               required
                               max="<?php echo date('Y-m-d'); ?>"
                               style="
                                   width: 100%;
                                   padding: 0.8rem;
                                   border: 1px solid var(--border-color);
                                   border-radius: 10px;
                                   font-size: 1rem;
                               ">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; color: var(--text-color);">
                            Transfer Saati
                        </label>
                        <input type="time" 
                               name="transfer_time" 
                               required
                               style="
                                   width: 100%;
                                   padding: 0.8rem;
                                   border: 1px solid var(--border-color);
                                   border-radius: 10px;
                                   font-size: 1rem;
                               ">
                    </div>
                </div>

                <div style="margin-bottom: 1.5rem;">
                    <label style="display: block; margin-bottom: 0.5rem; color: var(--text-color);">
                        Referans/Dekont No
                    </label>
                    <input type="text" 
                           name="reference_number"
                           style="
                               width: 100%;
                               padding: 0.8rem;
                               border: 1px solid var(--border-color);
                               border-radius: 10px;
                               font-size: 1rem;
                           ">
                </div>

                <div style="margin-bottom: 2rem;">
                    <label style="display: block; margin-bottom: 0.5rem; color: var(--text-color);">
                        Not (İsteğe Bağlı)
                    </label>
                    <textarea name="note" 
                              rows="3"
                              style="
                                  width: 100%;
                                  padding: 0.8rem;
                                  border: 1px solid var(--border-color);
                                  border-radius: 10px;
                                  font-size: 1rem;
                                  resize: vertical;
                              "></textarea>
                </div>

                <button type="submit" style="
                    width: 100%;
                    padding: 1rem;
                    background: var(--primary-color);
                    color: white;
                    border: none;
                    border-radius: 10px;
                    font-size: 1.1rem;
                    cursor: pointer;
                    transition: all 0.3s ease;
                ">
                    Ödeme Bildir
                </button>
            </form>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.copy-iban').forEach(button => {
    button.addEventListener('click', function() {
        const iban = this.dataset.iban;
        navigator.clipboard.writeText(iban).then(() => {
            this.textContent = 'Kopyalandı!';
            this.style.background = '#059669';
            setTimeout(() => {
                this.textContent = 'Kopyala';
                this.style.background = 'var(--primary-color)';
            }, 2000);
        });
    });
});

// Hover efektleri
document.querySelectorAll('.bank-account-card').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-5px)';
        this.style.boxShadow = '0 10px 20px rgba(0,0,0,0.1)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
        this.style.boxShadow = 'none';
    });
});
</script>

<?php require 'includes/footer.php'; ?> 