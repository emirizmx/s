<?php
class Credit {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function getPackages() {
        $stmt = $this->db->prepare("
            SELECT * FROM dh_credit_packages 
            WHERE is_active = 1 
            ORDER BY credits ASC
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function createTransaction($userId, $amount, $credits, $paymentMethod) {
        $stmt = $this->db->prepare("
            INSERT INTO dh_transactions (
                user_id, amount, credits, payment_method, status
            ) VALUES (
                :user_id, :amount, :credits, :payment_method, 'pending'
            )
        ");
        
        $stmt->execute([
            ':user_id' => $userId,
            ':amount' => $amount,
            ':credits' => $credits,
            ':payment_method' => $paymentMethod
        ]);
        
        return $this->db->lastInsertId();
    }
    
    public function completeTransaction($transactionId, $paytrResponse) {
        try {
            $this->db->beginTransaction();
            
            // İşlemi güncelle
            $stmt = $this->db->prepare("
                UPDATE dh_transactions 
                SET status = 'completed',
                    transaction_id = :paytr_id
                WHERE id = :id
            ");
            
            $stmt->execute([
                ':paytr_id' => $paytrResponse['merchantoid'],
                ':id' => $transactionId
            ]);
            
            // Krediyi kullanıcıya ekle
            $stmt = $this->db->prepare("
                UPDATE dh_users u
                JOIN dh_transactions t ON t.user_id = u.id
                SET u.credits = u.credits + t.credits
                WHERE t.id = :transaction_id
            ");
            
            $stmt->execute([':transaction_id' => $transactionId]);
            
            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
} 