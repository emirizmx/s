<?php require 'includes/header.php'; ?>

<main class="main">
    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Sevdiklerinize Özel Dijital Hediyeler</h1>
                <p>Romantik puzzle'lar ve daha fazlası ile sevdiklerinize unutulmaz anlar yaşatın.</p>
                <?php if (!isset($_SESSION['user_id'])): ?>
                    <div class="hero-buttons">
                        <a href="/register" class="btn btn-primary">Hemen Başla</a>
                        <a href="/login" class="btn btn-secondary">Giriş Yap</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Games Section -->
    <section class="games">
        <div class="container">
            <div class="section-header">
                <h2>Mevcut Oyunlar</h2>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="user-credits">
                        <i class="fas fa-coins"></i>
                        <span><?php echo number_format($userCredits); ?> Kredi</span>
                        <a href="/credits" class="btn btn-sm btn-primary">Kredi Yükle</a>
                    </div>
                <?php endif; ?>
            </div>

            <div class="games-grid">
                <?php foreach ($games as $game): ?>
                    <div class="game-card">
                        <div class="game-image">
                            <img src="<?php echo htmlspecialchars($game['image_path'] ?? '/assets/images/default-game.png'); ?>" 
                                 alt="<?php echo htmlspecialchars($game['name']); ?>"
                                 class="game-img">
                        </div>
                        <div class="game-info">
                            <h3 class="game-title"><?php echo htmlspecialchars($game['name']); ?></h3>
                            <p class="game-description"><?php echo htmlspecialchars($game['description']); ?></p>
                            <div class="game-footer">
                                <div class="game-credits">
                                    <span class="game-price"><?php echo number_format($game['credits']); ?> Kredi</span>
                                    <?php if ($game['route'] === 'story/list' && $game['voice_credits'] > 0): ?>
                                        <span class="voice-price">
                                            Ses Oluşturma: <?php echo number_format($game['voice_credits']); ?> Kredi
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <?php if ($game['is_active']): ?>
                                    <a href="/<?php echo $game['route']; ?>" class="btn btn-primary">Oyna</a>
                                <?php else: ?>
                                    <button class="btn btn-secondary" disabled>Yakında</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features">
        <div class="container">
            <h2>Neden Dijital Hediye?</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <i class="fas fa-heart"></i>
                    <h3>Romantik</h3>
                    <p>Sevdiğiniz kişiye özel hazırlanmış dijital hediyeler</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-bolt"></i>
                    <h3>Hızlı</h3>
                    <p>Anında oluşturun ve paylaşın</p>
                </div>
                <div class="feature-card">
                    <i class="fas fa-lock"></i>
                    <h3>Güvenli</h3>
                    <p>Güvenli ödeme ve kişisel bilgi koruması</p>
                </div>
            </div>
        </div>
    </section>
</main>

<?php require 'includes/footer.php'; ?> 